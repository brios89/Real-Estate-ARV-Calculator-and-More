import React, { useState, useMemo, useEffect, useRef } from "react";
import { Calculator, Building2, Layers, Banknote, RefreshCw, AlertTriangle, CheckCircle2, MinusCircle, Info, Zap, Loader2, MapPin, ExternalLink, TrendingDown, Search, Play, FileDown, X, HelpCircle, Phone, ChevronRight, ChevronLeft, Lightbulb, Minus } from "lucide-react";

// Where the proxies live. Same-origin by default on Vercel.
const RENT_API = "/api/rent";
const SOLD_API = "/api/sold";
const SOLID_TARGET = 4; // the sold-comp ARV median runs on the best N solid sales when available
const MIN_SOLID = 2;    // fewer than this many solid sales in the median trips the thin-comps warning (per B, Aug 5)
const AUTOCOMPLETE_API = "/api/autocomplete";

// Google web search link for any address string
const gsearch = (addr) => `https://www.google.com/search?q=${encodeURIComponent(addr)}`;

// Format property details into a readable line: "Single Family · 1 Bed · 1 Bath · Built 1920"
const propLine = (info) => {
  if (!info) return "";
  const parts = [];
  if (info.propertyType) parts.push(info.propertyType);
  if (info.beds != null && info.beds !== "") parts.push(`${info.beds} Bed${Number(info.beds) === 1 ? "" : "s"}`);
  if (info.baths != null && info.baths !== "") parts.push(`${info.baths} Bath${Number(info.baths) === 1 ? "" : "s"}`);
  if (info.yearBuilt) parts.push(`Built ${info.yearBuilt}`);
  return parts.join(" · ");
};

// Junk-comp check (flag-only): compare a comp to the subject and return reasons it may be a weak comp.
// Tolerances: >1 bed, >1 bath, >15 yrs build age, >250 sq ft, or >1 mi away.
// Build-type classifier: collapses architecture/property-type strings into families that actually
// price differently. Style differences (ranch vs colonial) do NOT flag — attached vs detached does.
const archClass = (arch, ptype) => {
  const t = `${arch || ""} ${ptype || ""}`.toLowerCase();
  if (/town\s?house|town\s?home|row\s?house|rowhome|attached/.test(t)) return "attached";
  if (/condo/.test(t)) return "condo";
  if (/manufactured|mobile|modular/.test(t)) return "manufactured";
  if (/duplex|triplex|fourplex|multi/.test(t)) return "multi";
  return "detached";
};

const compFlags = (c, subj, subjSqft) => {
  const flags = [];
  if (!c) return flags;
  const nOr = (v) => (v == null || v === "" ? null : Number(v));
  const cb = nOr(c.beds), sb = nOr(subj?.beds);
  if (cb != null && sb != null && Math.abs(cb - sb) > 1) flags.push(`${Math.abs(cb - sb)} bd off`);
  const cba = nOr(c.baths), sba = nOr(subj?.baths);
  if (cba != null && sba != null && Math.abs(cba - sba) > 1) flags.push(`${Math.abs(cba - sba)} ba off`);
  const cy = nOr(c.yearBuilt), sy = nOr(subj?.yearBuilt);
  if (cy && sy && Math.abs(cy - sy) > 15) flags.push(`built ${Math.abs(cy - sy)} yrs apart`);
  const cs = nOr(c.sqft), ss = subjSqft;
  if (cs && ss && Math.abs(cs - ss) > 250) flags.push(`${Math.abs(cs - ss).toLocaleString()} sf off`);
  const cd = nOr(c.distance);
  if (cd != null && cd > 1.0) flags.push(`${cd.toFixed(1)} mi away`); // 1 mi = normal appraiser reach in suburban markets (per B, Aug 5)
  // different build type = different market — a townhouse can't price a detached house
  if ((c.architecture || c.propertyType) && (subj?.architecture || subj?.propertyType)) {
    const ca = archClass(c.architecture, c.propertyType), sa = archClass(subj.architecture, subj.propertyType);
    if (ca !== sa) flags.push(`${ca} vs ${sa} build`);
  }
  return flags;
};

// Median of a list of positive numbers (used for the group's typical $/sf and the auto size-adjust rate).
const cleanMedian = (vals) => {
  const v = vals.filter((x) => x > 0).sort((a, b) => a - b);
  if (!v.length) return 0;
  const m = Math.floor(v.length / 2);
  return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2;
};

// Group-level price sanity, shared by both comp sections — now tail-aware and run on SIZE-ADJUSTED $/sf
// (items = [{ appsf, flags }]). Needs 3+ structurally-clean comps so a junk reference median can't flag
// good comps. LOW tail reads like a distressed sale (bank sale / big fixer / family deal) — leave out.
// HIGH tail reads like a renovated resale — which is literally what "after repair" means, so the label
// coaches: verify on Google, and include it if it's truly remodeled.
const PRICE_OUTLIER_PCT = 0.25;
const flagPriceOutliers = (items) => {
  const clean = items.filter((c) => c.flags.length === 0 && c.appsf > 0).map((c) => c.appsf).sort((a, b) => a - b);
  if (clean.length < 3) return;
  const m = Math.floor(clean.length / 2);
  const mid = clean.length % 2 ? clean[m] : (clean[m - 1] + clean[m]) / 2;
  items.forEach((c) => {
    if (!(c.appsf > 0)) return;
    const dev = (c.appsf - mid) / mid;
    if (dev < -PRICE_OUTLIER_PCT) c.flags.push(`possible distressed sale · $${Math.round(c.appsf)} vs $${Math.round(mid)}/sf`);
    else if (dev > PRICE_OUTLIER_PCT) c.flags.push(`possible renovated resale (flip) · $${Math.round(c.appsf)} vs $${Math.round(mid)}/sf`);
  });
};
// All RentCast dates are midnight-UTC ISO strings ("2026-01-22T00:00:00.000Z"). Every formatter pins
// timeZone: "UTC" — otherwise Eastern time rolls the display back a day (Jan 22 shows as Jan 21).
const shortDate = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return "";
  return d.toLocaleDateString("en-US", { month: "short", year: "2-digit", timeZone: "UTC" });
};
// Full date like "11/18/2024"
const fullDate = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return "";
  return d.toLocaleDateString("en-US", { timeZone: "UTC" });
};
// Clear readable date like "Jan 22, 2026" — used on the sold-comp cards
const mediumDate = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" });
};
// Subject's true last-sale line
const lastSoldLine = (info) => {
  if (!info || !info.lastSalePrice) return "";
  const when = fullDate(info.lastSaleDate);
  return `Last sold ${usd(info.lastSalePrice)}${when ? ` on ${when}` : ""}`;
};
// ---------- helpers ----------
const num = (v) => {
  const n = parseFloat(String(v).replace(/[^0-9.\-]/g, ""));
  return isNaN(n) ? 0 : n;
};
const usd = (n) =>
  isFinite(n) ? n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }) : "—";
const pct = (n) => (isFinite(n) ? `${n.toFixed(1)}%` : "—");

const pmt = (principal, annualRatePct, years) => {
  const n = years * 12;
  if (n <= 0 || principal <= 0) return 0;
  const r = annualRatePct / 100 / 12;
  if (r === 0) return principal / n;
  return (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
};
const balanceAt = (principal, annualRatePct, years, atYear) => {
  if (principal <= 0) return 0;
  const r = annualRatePct / 100 / 12;
  const k = Math.max(0, atYear) * 12;
  const M = pmt(principal, annualRatePct, years);
  if (r === 0) return Math.max(0, principal - M * k);
  return Math.max(0, principal * Math.pow(1 + r, k) - (M * (Math.pow(1 + r, k) - 1)) / r);
};
// Present value (today's dollars) of the monthly payment savings a below-market loan throws off,
// discounted at the market rate over the remaining term. This is what a cheap assumed loan is "worth"
// — it grows as the deal rate drops below market.
const pvSavings = (loan, ratePct, mktPct, years) => {
  const n = years * 12;
  if (loan <= 0 || n <= 0) return 0;
  const mo = pmt(loan, mktPct, years) - pmt(loan, ratePct, years); // monthly savings vs market
  if (mo <= 0) return 0;
  const r = mktPct / 100 / 12; // discount at the market monthly rate
  if (r === 0) return mo * n;
  return (mo * (1 - Math.pow(1 + r, -n))) / r;
};

// Returns snapshot + 5-year wealth projection for the buyer deck (shared across creative tabs).
// Loan-takeover savings — mirrors the on-screen Rate Savings panel so the deck shows identical figures.
// origTerm defaults to 30 (standard original mortgage term); P/rate/term/mkt/payment come from the deal's loan.
function computeLoanSavings({ P, rate, term, mkt, origTerm = 30, dealPayment = 0 }) {
  if (!(P > 0)) return { totalSaved: 0 };
  const effOrig = Math.max(term, origTerm);
  const seasoned = Math.max(0, effOrig - term);
  const payDeal = pmt(P, rate, term);
  const payNew = pmt(P, mkt, effOrig);
  const intSubTo = Math.max(0, payDeal * term * 12 - P);
  const intNew = Math.max(0, payNew * effOrig * 12 - P);
  const intSameTerm = Math.max(0, pmt(P, mkt, term) * term * 12 - P);
  const rateSaved = Math.max(0, intSameTerm - intSubTo);
  const seasoningSaved = Math.max(0, intNew - intSameTerm);
  const totalSaved = rateSaved + seasoningSaved;
  const haveRealPmt = dealPayment > 0;
  const tiPortion = haveRealPmt ? Math.max(0, dealPayment - payDeal) : 0;   // taxes/insurance baked into the real payment
  const newPmtFull = payNew + tiPortion;                                    // fresh market loan carrying the same T&I
  const moRelief = haveRealPmt ? Math.max(0, newPmtFull - dealPayment) : Math.max(0, payNew - payDeal);
  const takePayment = haveRealPmt ? dealPayment : payDeal;
  return { P, rate, mkt, term, effOrig, seasoned, payDeal, payNew, newPmtFull, intSubTo, intNew, rateSaved, seasoningSaved, totalSaved, moRelief, takePayment, haveRealPmt };
}

function buildDealExtras({ loanAmt, rate, term, arv, equity, cashFlow, cashToClose, coc }) {
  const paydown5 = loanAmt > 0 ? loanAmt - balanceAt(loanAmt, rate, term, 5) : 0;
  const appreciation5 = arv > 0 ? arv * (Math.pow(1.03, 5) - 1) : 0;
  const cumCF5 = cashFlow * 60;
  const startEquity = Math.max(0, equity);
  // 1–30 year return curve: equity captured + loan paydown + cumulative cash flow + 3%/yr appreciation
  const curveSeries = [];
  for (let y = 1; y <= 30; y++) {
    const paydown = loanAmt > 0 ? loanAmt - balanceAt(loanAmt, rate, term, y) : 0;
    const appr = arv > 0 ? arv * (Math.pow(1.03, y) - 1) : 0;
    const cumCF = cashFlow * 12 * y;
    curveSeries.push({ year: y, total: startEquity + paydown + appr + cumCF });
  }
  const milestones = [1, 5, 10, 15, 20, 25, 30].map((y) => curveSeries[y - 1]).filter(Boolean);
  return {
    returns: { cashToClose, monthlyCF: cashFlow, annualCF: cashFlow * 12, coc },
    projection: { startEquity, paydown5, appreciation5, cumCF5, total5: startEquity + paydown5 + appreciation5 + cumCF5, apprRate: 3 },
    curve: { series: curveSeries, milestones, cashToClose },
    exits: [
      "Hold as a cash-flowing long-term rental",
      "BRRRR — season, refinance, and recycle your capital",
      "Resell on terms to your own buyer for a markup",
    ],
  };
}

// ---------- module-scope inputs (stable refs = no focus loss) ----------
const InfoDot = ({ text }) => {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex">
      <button type="button"
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setOpen((o) => !o); }}
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        className="text-slate-300 hover:text-emerald-600" aria-label="more info">
        <Info className="h-3.5 w-3.5" />
      </button>
      {open && (
        <span className="absolute left-1/2 top-5 z-30 w-52 -translate-x-1/2 rounded-lg bg-slate-900 px-3 py-2 text-[11px] font-normal normal-case leading-snug tracking-normal text-white shadow-lg">
          {text}
        </span>
      )}
    </span>
  );
};

const Field = ({ label, hint, info, children }) => (
  <label className="block">
    <div className="flex items-baseline justify-between gap-2">
      <span className="flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-slate-500">
        {label}{info && <InfoDot text={info} />}
      </span>
      {hint && <span className="text-[10px] text-slate-400">{hint}</span>}
    </div>
    <div className="mt-1">{children}</div>
  </label>
);

const TextInput = ({ value, onChange, placeholder }) => (
  <input type="text" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
);

// Address typeahead: shows real address suggestions as you type (debounced).
const AddressAutocomplete = ({ value, onChange, onPick, placeholder }) => {
  const [sugs, setSugs] = useState([]);
  const [open, setOpen] = useState(false);
  const [hi, setHi] = useState(-1);
  const boxRef = useRef(null);
  const timer = useRef(null);

  useEffect(() => {
    const onDoc = (e) => { if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const fetchSugs = (q) => {
    if (timer.current) clearTimeout(timer.current);
    if (!q || q.trim().length < 4) { setSugs([]); setOpen(false); return; }
    timer.current = setTimeout(async () => {
      try {
        const r = await fetch(`${AUTOCOMPLETE_API}?q=${encodeURIComponent(q)}`);
        if (!r.ok) { setSugs([]); return; }
        const data = await r.json();
        setSugs(data.suggestions || []);
        setOpen((data.suggestions || []).length > 0);
        setHi(-1);
      } catch { setSugs([]); }
    }, 250);
  };

  const handleChange = (v) => { onChange(v); fetchSugs(v); };
  const pick = (s) => { onChange(s); onPick && onPick(s); setOpen(false); setSugs([]); };

  const onKey = (e) => {
    if (!open || !sugs.length) return;
    if (e.key === "ArrowDown") { e.preventDefault(); setHi((h) => Math.min(h + 1, sugs.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
    else if (e.key === "Enter" && hi >= 0) { e.preventDefault(); pick(sugs[hi]); }
    else if (e.key === "Escape") setOpen(false);
  };

  return (
    <div ref={boxRef} className="relative">
      <input
        type="text" value={value} placeholder={placeholder}
        onChange={(e) => handleChange(e.target.value)}
        onFocus={() => sugs.length && setOpen(true)}
        onKeyDown={onKey}
        autoComplete="off"
        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
      />
      {open && sugs.length > 0 && (
        <ul className="absolute z-20 mt-1 max-h-64 w-full overflow-auto rounded-lg border border-slate-200 bg-white shadow-lg">
          {sugs.map((s, i) => (
            <li key={i}>
              <button
                type="button"
                onMouseEnter={() => setHi(i)}
                onClick={() => pick(s)}
                className={`flex w-full items-start gap-2 px-3 py-2 text-left text-sm ${i === hi ? "bg-emerald-50 text-emerald-800" : "text-slate-700 hover:bg-slate-50"}`}
              >
                <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-400" />
                <span>{s}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

// filled: the placeholder is a real number the app pulled, not a hint. Show it dark so it reads as
// data. Still a placeholder underneath, so typing replaces it and a fresh pull can update it.
const MoneyInput = ({ value, onChange, placeholder, filled }) => (
  <div className="flex items-center rounded-lg border border-slate-200 bg-white transition focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-100">
    <span className="pl-3 pr-1 text-sm text-slate-400">$</span>
    <input type="text" inputMode="decimal" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
      className={`w-full bg-transparent py-2 pr-3 text-sm tabular-nums text-slate-900 outline-none font-mono ${filled && !value ? "placeholder:font-semibold placeholder:text-slate-800" : ""}`} />
  </div>
);

const PlainInput = ({ value, onChange, placeholder, suffix }) => (
  <div className="flex items-center rounded-lg border border-slate-200 bg-white transition focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-100">
    <input type="text" inputMode="decimal" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
      className="w-full bg-transparent px-3 py-2 text-sm tabular-nums text-slate-900 outline-none font-mono" />
    {suffix && <span className="pr-3 text-sm text-slate-400">{suffix}</span>}
  </div>
);

const Stat = ({ label, value, tone = "default", big = false, sub }) => {
  const tones = { default: "text-slate-900", good: "text-emerald-600", bad: "text-rose-600", warn: "text-amber-600" };
  return (
    <div className="rounded-xl border border-slate-200 bg-white px-4 py-3">
      <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{label}</div>
      <div className={`mt-0.5 font-mono tabular-nums ${big ? "text-2xl" : "text-lg"} font-bold ${tones[tone]}`}>{value}</div>
      {sub && <div className="mt-0.5 text-[11px] text-slate-400">{sub}</div>}
    </div>
  );
};

const Verdict = ({ status, headline, detail }) => {
  const map = {
    go: { bg: "bg-emerald-50", bd: "border-emerald-200", tx: "text-emerald-800", Icon: CheckCircle2, ic: "text-emerald-600" },
    maybe: { bg: "bg-amber-50", bd: "border-amber-200", tx: "text-amber-900", Icon: AlertTriangle, ic: "text-amber-600" },
    no: { bg: "bg-rose-50", bd: "border-rose-200", tx: "text-rose-800", Icon: MinusCircle, ic: "text-rose-600" },
  };
  const s = map[status] || map.maybe;
  const Icon = s.Icon;
  return (
    <div className={`flex items-start gap-3 rounded-xl border ${s.bd} ${s.bg} px-4 py-3`}>
      <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${s.ic}`} />
      <div>
        <div className={`text-sm font-bold ${s.tx}`}>{headline}</div>
        {detail && <div className={`mt-0.5 text-xs ${s.tx} opacity-80`}>{detail}</div>}
      </div>
    </div>
  );
};

const SectionTitle = ({ children }) => (
  <h3 className="mb-3 text-xs font-bold uppercase tracking-widest text-slate-400">{children}</h3>
);

// ---------- main ----------
// Interactive comp map (Leaflet, loaded from CDN in index.html). Subject = red ★; comps = numbered pins:
// emerald = in the ARV, amber = flagged out, slate = out for other reasons. Clicking a pin toggles it
// in/out of that section's ARV — same effect as the include/exclude buttons on the cards.
const CompMap = ({ subject, pins, onToggle }) => {
  const boxRef = useRef(null);
  const mapRef = useRef(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (!boxRef.current || mapRef.current) return;
    let tries = 0;
    let cancelled = false;
    const boot = () => {
      if (cancelled) return;
      const L = window.L;
      if (!L) { if (tries++ < 40) setTimeout(boot, 150); return; }   // wait for the CDN script
      const m = L.map(boxRef.current, { scrollWheelZoom: false });
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "© OpenStreetMap" }).addTo(m);
      mapRef.current = { m, layer: L.layerGroup().addTo(m) };
      setReady(true);
    };
    boot();
    return () => { cancelled = true; if (mapRef.current) { mapRef.current.m.remove(); mapRef.current = null; } };
  }, []);
  useEffect(() => {
    const L = window.L;
    if (!ready || !L || !mapRef.current) return;
    const { m, layer } = mapRef.current;
    layer.clearLayers();
    const pts = [];
    const dot = (bg, txt, size = 24, fs = 11) => L.divIcon({
      className: "", iconSize: [size, size], iconAnchor: [size / 2, size / 2],
      html: `<div style="background:${bg};color:#fff;border-radius:9999px;width:${size}px;height:${size}px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:${fs}px;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.45)">${txt}</div>`,
    });
    if (subject && subject.lat != null && subject.lng != null) {
      L.marker([subject.lat, subject.lng], { icon: dot("#dc2626", "★", 28, 13), zIndexOffset: 1000 })
        .addTo(layer).bindTooltip(subject.label || "Subject");
      pts.push([subject.lat, subject.lng]);
    }
    pins.forEach((p) => {
      if (p.lat == null || p.lng == null) return;
      const bg = p.included ? "#059669" : p.flagged ? "#d97706" : "#94a3b8";
      const mk = L.marker([p.lat, p.lng], { icon: dot(bg, String(p.n)) }).addTo(layer);
      mk.bindTooltip(`#${p.n} · ${usd(p.price)} · ${p.included ? "in ARV — click to remove" : "out — click to include"}`);
      if (onToggle) mk.on("click", () => onToggle(p.i));
      pts.push([p.lat, p.lng]);
    });
    if (pts.length) { m.invalidateSize(); m.fitBounds(pts, { padding: [28, 28], maxZoom: 16 }); }
  }, [ready, subject, pins, onToggle]);
  return <div ref={boxRef} className="relative z-0 mt-2 h-64 w-full overflow-hidden rounded-lg border border-slate-200" />;
};

// Street View links for a comp: interactive pano when we have coordinates, place search otherwise.
const svLink = (c) => (c.lat != null && c.lng != null
  ? `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${c.lat},${c.lng}`
  : `https://www.google.com/maps/place/${encodeURIComponent(c.address || "")}`);

// Lot size: RentCast reports square feet; read it like an appraiser (acres once it's big enough to think in acres).
const fmtLot = (sf) => {
  const n = Number(sf);
  if (!n || n <= 0) return null;
  return n >= 8712 ? `${(n / 43560).toFixed(2)} acres` : `${Math.round(n).toLocaleString()} sf`;
};

// Comp detail pop-up — opens when a comp card's photo is clicked. Shows everything RentCast already
// sent with the pull (zero extra API credits). The big photo clicks through to interactive Street
// View, and the Include button is the exact same toggle as the card's checkbox and the map pin.
const DetailTile = ({ label, value, amber }) => (value == null || value === "" ? null : (
  <div className={`rounded-lg border p-2.5 ${amber ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-slate-50/50"}`}>
    <div className={`text-[10px] font-semibold uppercase tracking-wide ${amber ? "text-amber-600" : "text-slate-400"}`}>{label}</div>
    <div className={`mt-0.5 text-sm font-semibold ${amber ? "text-amber-800" : "text-slate-800"}`}>{value}</div>
  </div>
));

const CompDetailModal = ({ data, onClose, onToggle }) => {
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  if (!data) return null;
  const d = data;
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 p-3 sm:p-6" onClick={onClose}>
      <div className="mx-auto my-4 w-full max-w-2xl rounded-2xl bg-white p-4 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Comp #{d.n} · {d.source}</div>
            <div className="mt-0.5 truncate text-sm font-bold text-slate-900">{d.address || "(address withheld)"}</div>
          </div>
          <button type="button" onClick={onClose} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-50"><X className="h-4 w-4" /></button>
        </div>
        {d.address && (
          <a href={d.sv} target="_blank" rel="noopener noreferrer" title="Open interactive Street View"
            className="relative mt-3 block h-52 w-full overflow-hidden rounded-xl bg-slate-100 sm:h-64">
            <span className="absolute inset-0 flex items-center justify-center"><Building2 className="h-10 w-10 text-slate-300" /></span>
            <img src={`/api/photo?size=640x360&address=${encodeURIComponent(d.address)}`} alt=""
              className="absolute inset-0 h-full w-full object-cover"
              onError={(e) => { e.currentTarget.style.display = "none"; }} />
            <span className="absolute bottom-2 right-2 rounded bg-slate-900/70 px-1.5 py-0.5 text-[10px] font-semibold text-white">Street View — click to explore</span>
          </a>
        )}
        {d.flags.length > 0 && (
          <div className="mt-3 flex items-start gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11px] leading-snug text-amber-800">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
            <span>{d.flags.join(" · ")}</span>
          </div>
        )}
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {d.tiles.map((t, ix) => <DetailTile key={ix} {...t} />)}
        </div>
        {d.history && d.history.length > 0 && (
          <div className="mt-4">
            <div className="text-[11px] font-bold uppercase tracking-widest text-slate-400">Recorded sale history</div>
            <div className="mt-1.5 overflow-hidden rounded-lg border border-slate-200">
              <table className="w-full text-left text-[11px]">
                <thead><tr className="bg-slate-50 text-[10px] uppercase tracking-wide text-slate-400"><th className="px-2.5 py-1.5 font-semibold">Date</th><th className="px-2.5 py-1.5 font-semibold">Price</th><th className="px-2.5 py-1.5 font-semibold">$ / sqft</th></tr></thead>
                <tbody>
                  {d.history.map((h, ix) => (
                    <tr key={ix} className="border-t border-slate-100">
                      <td className="px-2.5 py-1.5 font-mono text-slate-600">{mediumDate(h.date)}</td>
                      <td className="px-2.5 py-1.5 font-mono font-bold text-slate-800">{h.price ? usd(h.price) : "—"}</td>
                      <td className="px-2.5 py-1.5 font-mono text-slate-500">{h.price && d.sqftNum > 0 ? `$${Math.round(h.price / d.sqftNum)}` : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-1 text-[10px] text-slate-400">County-recorded sales only — MLS listing history and price changes aren't in RentCast's data.</div>
          </div>
        )}
        <div className="mt-4 flex items-center justify-between gap-2">
          <button type="button" onClick={onToggle}
            className={`flex items-center gap-2 rounded-md border px-3 py-1.5 text-xs font-bold ${d.included ? "border-emerald-600 bg-emerald-600 text-white hover:bg-emerald-700" : "border-slate-300 bg-white text-slate-600 hover:bg-slate-50"}`}>
            <span className={`flex h-4 w-4 items-center justify-center rounded border text-[10px] font-bold ${d.included ? "border-white bg-white/20 text-white" : "border-slate-300 text-transparent"}`}>✓</span>
            {d.included ? "In the ARV — click to remove" : "Out of the ARV — click to include"}
          </button>
          {d.address && (
            <a href={gsearch(d.address)} target="_blank" rel="noopener noreferrer" className="text-[11px] font-semibold text-emerald-600 hover:underline">Google this property</a>
          )}
        </div>
      </div>
    </div>
  );
};

// ============================== OFFER CALL MODE ==============================
// A guided walk through YLHB's Acquisitions Script + SOP for the Offer Call.
// Stages follow the script; answers captured here drive the strategy engine, which
// ranks Cash / Sub-To / Hybrid / Seller Finance / Novation and hands the rep the
// exact script language to pitch it. Scoring thresholds live in scoreStrategies —
// tune them there. Compliance: no guarantees, ever (SOP Step 10).

// Pull a usable first name out of a county owner record. Records are messy: "Darryl Cook",
// "COOK DARRYL", "COOK, DARRYL", "SMITH FAMILY TRUST". Entities get skipped (no human to greet),
// "LAST, FIRST" is read after the comma, otherwise the first token wins. Always prefilled as a
// suggestion the rep can overwrite — the owner of record isn't always who's on the phone.
const ENTITY_WORDS = /\b(llc|l\.l\.c|inc|corp|corporation|company|co|trust|trustee|estate|properties|holdings|partners|lp|llp|associates|group|bank|na|ministries|church)\b/i;
const titleCase = (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
const ownerFullName = (names) => {
  const raw = Array.isArray(names) ? names.filter(Boolean)[0] : names;
  if (!raw) return "";
  const full = String(raw).trim();
  if (!full || ENTITY_WORDS.test(full)) return "";
  // "LAST, FIRST M" -> "First M Last"; otherwise keep the recorded order.
  const ordered = full.includes(",")
    ? `${full.split(",").slice(1).join(" ").trim()} ${full.split(",")[0].trim()}`
    : full;
  const parts = ordered.split(/\s+/).map((t) => t.replace(/[^A-Za-z'-]/g, "")).filter((t) => t.length > 0);
  if (!parts.length) return "";
  return parts.map(titleCase).join(" ");
};

const INITIAL_CALL = {
  sellerName: "", bookedBy: "",
  motivation: "", motivNotes: "",
  occupancy: "", condition: "", loan: "", balance: "", payment: "", rate: "", behind: "",
  escrowed: "", tiMonthly: "",   // is taxes+insurance inside that payment, and if not, what they run monthly
  hoa: "", hoaAmt: "",           // HOA dues come out of the same rent the payment does, so they belong in the test
  timeline: "", others: "",
  ask: "", priceBasis: "", needCash: "", needCashNotes: "",
  condItems: "",                 // JSON map of item key -> note, for the walkthrough checklist
  chosen: "",                    // the strategy the rep is actually pitching (may differ from the engine's top pick)
  terms: "",
};

const PILLARS = [
  { id: "motivation", label: "Motivation", done: (c) => !!c.motivation },
  { id: "condition", label: "Condition", done: (c) => !!c.condition },
  { id: "timeline", label: "Timeline", done: (c) => !!c.timeline },
  { id: "price", label: "Price", done: (c) => num(c.ask) > 0 },
];

const REBUTTALS = [
  { t: "“There's a similar house listed for this much.”", a: "“A listed price is just an asking price, not a sale. The only price that counts is what a buyer who is ready, willing and able will actually pay. Right now, that's us, and this is what we can do.”" },
  { t: "“Zillow says it's worth this much.”", a: "“Let me ask you this — has an employee of Zillow ever gone into your house to take pictures and analyze how much work it needs or doesn't need? Zillow takes the average sales price of houses sold on the MLS, and most of those are retail ready — updated, no work needed.”" },
  { t: "“My house appraised for this much.”", a: "“Here's the thing with appraisals — the appraiser isn't the one buying the house. It's only worth what a buyer will pay. And right now average days on market is 60 to 90 days. A lot can happen in that time.”" },
];

// PITI vs market rent. A sub-to only makes sense as a hold if the payment leaves room for the
// costs people forget: vacancy, maintenance, CapEx, and management run roughly 25-35% of rent.
// At or under 65% of rent there is real cash flow. Past 75% you are buying a break-even deal
// with due-on-sale risk attached. Seller-quoted payments often exclude escrow, so taxes and
// insurance get added when the rep says the payment does not include them.
// A loan well under today's market rate is an asset in its own right. Below this, the deal does
// not get to quietly die on the vine: it goes to the head of acquisitions if it is not locked up.
const LOW_RATE = 4.0;
const rateNum = (v) => {
  const n = parseFloat(String(v || "").replace(/[^0-9.]/g, ""));
  return isNaN(n) || n <= 0 ? null : n;
};
const isLowRate = (v) => { const n = rateNum(v); return n != null && n < LOW_RATE; };

const ANCHOR_PCT = 0.8;   // open here, not at the ceiling, so every concession still lands under max
const PITI_GOOD = 0.65, PITI_LIMIT = 0.75;
const pitiCheck = (cs, rent) => {
  const base = num(cs.payment);
  if (base <= 0 || !rent || rent <= 0) return null;
  const addTI = cs.escrowed === "no" ? num(cs.tiMonthly) : 0;
  const addHOA = cs.hoa === "yes" ? num(cs.hoaAmt) : 0;   // dues are a real monthly cost against the same rent
  const piti = base + addTI + addHOA;
  const ratio = piti / rent;
  const missingTI = cs.escrowed === "no" && num(cs.tiMonthly) <= 0;
  const missingHOA = cs.hoa === "yes" && num(cs.hoaAmt) <= 0;
  return {
    piti, rent, ratio, missingTI, missingHOA, hoa: addHOA,
    unknownEscrow: !cs.escrowed,
    verdict: ratio <= PITI_GOOD ? "good" : ratio <= PITI_LIMIT ? "thin" : "fail",
    targetPiti: Math.round(rent * PITI_GOOD),
  };
};

// A real repair number already says what the condition is. The calculator prices light at $15/sf,
// moderate at $30 and a gut at $50, so we read the dollars back through those same rates and split
// at the midpoints. Used only when the rep has not tapped a condition chip, and always labelled as
// inferred rather than treated as something the seller said.
const impliedCondition = (repairs, sqft) => {
  const r = num(repairs), sf = num(sqft);
  if (r <= 0 || sf <= 0) return null;
  const psf = r / sf;
  return psf < 22 ? "light" : psf <= 40 ? "moderate" : "heavy";
};

// The engine. Inputs: what the rep captured + live deal numbers from the calculator.
// Every rule that fires adds a human-readable reason so the rep sees WHY, not just a rank.
function scoreStrategies(c, deal) {
  const ask = num(c.ask);
  const maxCash = deal.maxCash > 0 ? deal.maxCash : 0;
  const arv = deal.arv > 0 ? deal.arv : 0;
  const bal = num(c.balance);
  const gap = ask > 0 && maxCash > 0 ? ask - maxCash : null;
  const equity = c.loan === "yes" && ask > 0 && bal > 0 ? ask - bal : null;
  const eqPct = equity != null && ask > 0 ? equity / ask : null;
  const M = (q, why) => ({ q, why });
  // What the rep tapped wins. Failing that, fall back to what the repair number implies.
  const implied = c.condition ? null : impliedCondition(deal.repairs, deal.sqft);
  const cond = c.condition || implied;
  // A chip that contradicts the repair dollars is worth saying out loud: the offer is built on the
  // dollars, so the two need to agree before anyone quotes a number.
  const impliedCheck = c.condition ? impliedCondition(deal.repairs, deal.sqft) : null;
  const condMismatch = impliedCheck && impliedCheck !== c.condition ? impliedCheck : null;
  const condNote = implied ? ` (read from the ${usd(deal.repairs)} repair number, confirm it on the call)` : "";
  const out = [];

  // ---- CASH ----
  {
    let sc = 45; const rs = [], warn = [], miss = [];
    if (gap != null && gap <= maxCash * 0.05) { sc += 30; rs.push("Their number is at or under your max cash offer — just close it."); }
    if (gap != null && gap > maxCash * 0.15) { sc -= 35; warn.push("Their number is well above cash — pitch cash to anchor, then pivot creative."); }
    if (cond === "heavy") { sc += 10; rs.push(`Heavy rehab${condNote} — classic cash / wholesale profile.`); }
    if (c.timeline === "asap") { sc += 8; rs.push("They need speed, and cash closes fastest."); }
    if (c.behind === "yes") { sc += 8; rs.push("Behind on payments — a fast close stops the bleeding."); }
    if (ask <= 0) miss.push(M("“If we could close quickly, buy it as-is, and make this super simple for you, what would you need to walk away with?”", "Their number sets the whole strategy."));
    if (maxCash <= 0) miss.push(M("Run Auto-comp up top so the ARV and max cash offer are live.", "Without ARV there's no cash number to compare."));
    out.push({ id: "cash", label: "Cash offer", tab: "cash", sc, rs, warn, miss,
      // Delivering a low number is the hardest thing a newer rep does. The sequence matters more
      // than the wording: earn the number first, say it plainly, then stop talking.
      pitch: [
        "1. Frame it before you say it. “We buy as-is. No repairs, no cleaning out, no commissions, no inspections, no showings, and we close on whatever date works for you.”",
        "2. Say the number once, plainly. “Based on all of that, what we can do is ____.” Then stop talking. Do not soften it, do not apologize for it, do not explain it before they react. Whoever talks first after the number loses ground.",
        "3. If they flinch, do not move. “I understand. What were you hoping to get?” Let them counter. Their counter is information you do not have yet.",
        "4. Only then, justify it. “We use lenders and private capital, but flips come with repairs, contractors, holding costs, commissions, and a market that can move. We have to buy at a number that still works after all of that.”",
        "5. If their number is above your ceiling, do not split the difference on the spot. That is what the Partnership Program is for.",
      ] });
  }

  // ---- SUB-TO ----
  {
    let sc = 0; const rs = [], warn = [], miss = [];
    if (c.loan !== "yes") {
      warn.push(c.loan === "no" ? "No loan on the property — nothing to take over. Look at Seller Finance." : "Find out if there's a loan first.");
      if (!c.loan) miss.push(M("“Do you still owe anything on it?”", "No loan = no Sub-To; free and clear = Seller Finance territory."));
    } else {
      sc = 40; rs.push("There's a loan in place to take over.");
      if (eqPct != null && eqPct <= 0.15) { sc += 20; rs.push("Low equity — their ask sits close to the balance, so a payment takeover solves it."); }
      if (c.behind === "yes") { sc += 15; rs.push("Behind on payments — take over + reinstate arrears is the classic Sub-To save."); }
      if (c.terms === "yes" || c.terms === "maybe") { sc += 8; rs.push("They're open to something other than a cash lump sum."); }
      if (c.timeline === "asap") { sc += 8; rs.push("Sub-To moves fast — no new loan to originate."); }
      if (cond === "heavy") { sc -= 10; warn.push(`Heavy rehab${condNote} on a Sub-To puts repair risk on you — price it in.`); }
      // The hold test. This can end the conversation regardless of everything else above.
      const pc = pitiCheck(c, deal.rent);
      if (pc) {
        const pct = `${Math.round(pc.ratio * 100)}%`;
        if (pc.verdict === "fail") {
          sc -= 55;
          warn.push(`Payment is ${pct} of market rent. That is not a Sub-To hold — it needs to be at or under 65%, which means about ${usd(pc.targetPiti)} a month. Vacancy, maintenance, CapEx and management eat 25-35% of rent before you see a dollar.`);
        } else if (pc.verdict === "thin") {
          sc -= 15;
          warn.push(`Payment is ${pct} of market rent. Break-even territory, so it only works if your exit beats standard rent (mid-term, co-living, or a lease option).`);
        } else {
          sc += 15;
          rs.push(`Payment is ${pct} of market rent, which leaves real room after vacancy, maintenance and CapEx.`);
        }
        if (pc.missingTI) warn.push("Taxes and insurance are not in that payment and have not been added, so the real ratio is worse than shown.");
        if (pc.missingHOA) warn.push("There is an HOA but the dues have not been entered, so the real ratio is worse than shown.");
      } else if (num(c.payment) > 0 && !deal.rent) {
        miss.push(M("Pull the market rent in the Property stage.", "Payment versus rent decides whether this is a hold or a headache."));
      }
      if (bal <= 0) miss.push(M("“Do you still owe anything on it?” — get the rough balance.", "Balance vs. ask decides Sub-To vs. Hybrid."));
      if (num(c.payment) <= 0) miss.push(M("“What's your current payment?”", "The payment IS the deal — it sets your monthly basis."));
    }
    out.push({ id: "subto", label: "Subject-To", tab: "subto", sc, rs, warn, miss,
      pitch: ["“What if I just took over your existing payments?”", "Get the payment, rate, and whether they're current — then run the Sub-To tab live."] });
  }

  // ---- SELLER FINANCE ----
  {
    let sc = 0; const rs = [], warn = [], miss = [];
    if (c.loan === "yes" && ask > 0 && bal > ask * 0.1) {
      warn.push("Not free and clear — with a real balance, Hybrid is the seller-carry play.");
    } else {
      sc = 20;
      if (c.loan === "no") { sc += 25; rs.push("Free and clear — the textbook seller-finance setup."); }
      if (gap != null && gap > 0) { sc += 18; rs.push("They want more than cash allows — terms can bridge the price gap."); }
      if (c.terms === "yes") { sc += 12; rs.push("They're open to becoming the bank."); }
      else if (c.terms === "maybe") { sc += 6; rs.push("Lukewarm on terms — worth the pitch."); }
      if (c.timeline === "flexible") { sc += 8; rs.push("No rush — room for a terms conversation."); }
      if (!c.loan) miss.push(M("“Do you still owe anything on it?”", "Seller finance wants free-and-clear (or close to it)."));
      if (!c.terms) miss.push(M("“What kind of terms would make you excited about seller financing?”", "Their answer tells you if the door is open."));
    }
    out.push({ id: "sf", label: "Seller finance", tab: "sf", sc, rs, warn, miss,
      pitch: ["“Sometimes becoming the bank creates a better overall solution.”", "“What kind of terms would make you excited about seller financing?”"] });
  }

  // ---- HYBRID ----
  {
    let sc = 0; const rs = [], warn = [], miss = [];
    if (c.loan !== "yes") {
      warn.push("No loan — that's straight Seller Finance, not a hybrid.");
    } else if (eqPct != null && eqPct <= 0.15) {
      sc = 10; warn.push("Equity's thin — plain Sub-To is likely cleaner.");
    } else {
      sc = 40; rs.push("A loan to take over AND real equity — Sub-To the loan, seller carries the difference.");
      if (gap != null && gap > 0) { sc += 15; rs.push("Bridges their price without more cash out of pocket."); }
      if (c.terms === "yes" || c.terms === "maybe") { sc += 10; rs.push("They're open to payments over time on the equity."); }
      if (bal <= 0) miss.push(M("Get the loan balance — the equity above it is what the seller carries.", "Ask − balance = the carried piece."));
    }
    out.push({ id: "hybrid", label: "Hybrid (Sub-To + carry)", tab: "hybrid", sc, rs, warn, miss,
      pitch: ["Take over the existing payments, and the seller carries the equity above the balance as a note — their price, your structure."] });
  }

  // ---- NOVATION ----
  {
    let sc = 15; const rs = [], warn = [], miss = [];
    if (cond === "light") { sc += 22; rs.push(`Light condition${condNote} — it can sell retail without a full rehab.`); }
    else if (cond === "moderate") { sc += 8; rs.push(`Moderate condition${condNote} — retail is possible with cosmetic touch-ups.`); }
    else if (cond === "heavy") { sc -= 18; warn.push(`Heavy rehab${condNote} kills the retail buyer — novation is a stretch here.`); }
    if (c.timeline === "flexible") { sc += 15; rs.push("They can wait out a retail sale (figure 60–90 days on market)."); }
    else if (c.timeline === "asap") { sc -= 12; warn.push("A retail timeline won't fit their urgency."); }
    if (gap != null && gap > 0 && arv > 0 && ask <= arv * 0.9 - deal.repairs) { sc += 12; rs.push("Their number fits under a retail sale with room for the spread."); }
    if (c.occupancy === "tenant") { sc -= 10; warn.push("Tenant in place makes retail showings hard."); }
    if (c.occupancy === "vacant") { sc += 6; rs.push("Vacant — easy access for showings and photos."); }
    if (!cond) miss.push(M("“What can you tell me about the current condition?”", "Condition decides if a retail buyer will touch it."));
    if (!c.timeline) miss.push(M("“How soon are you hoping to close?”", "Novation needs a seller who can wait."));
    out.push({ id: "nov", label: "Novation", tab: "nov", sc, rs, warn, miss,
      pitch: ["“We prepare and sell it retail on your behalf — you get closer to the retail number, we handle the work and the buyers, and you get paid at closing.”"] });
  }

  if (condMismatch) {
    const msg = `Condition says ${c.condition} but ${usd(deal.repairs)} of repairs reads as ${condMismatch}. The offer is built on the dollars — fix whichever is wrong.`;
    for (const o of out) if (["cash", "subto", "nov"].includes(o.id)) o.warn.push(msg);
  }
  for (const o of out) o.sc = Math.max(0, Math.min(100, Math.round(o.sc)));
  out.sort((a, b) => b.sc - a.sc);
  return { ranked: out, gap, equity };
}

// ---- tiny self-contained inputs so the drawer has zero dependencies on App-scoped components ----
const WChips = ({ value, onChange, opts }) => (
  <div className="mt-1.5 flex flex-wrap gap-1.5">
    {opts.map(([v, l]) => (
      <button key={v} type="button" onClick={() => onChange(value === v ? "" : v)}
        className={`rounded-md border px-2.5 py-1 text-[11px] font-semibold ${value === v ? "border-emerald-600 bg-emerald-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}>
        {l}
      </button>
    ))}
  </div>
);
const WField = ({ label, children }) => (
  <div className="mt-3">
    <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{label}</div>
    {children}
  </div>
);
const WText = ({ value, onChange, placeholder, money }) => (
  <div className="relative mt-1.5">
    {money && <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 font-mono text-xs text-slate-400">$</span>}
    <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} inputMode={money ? "numeric" : "text"}
      className={`w-full rounded-md border border-slate-200 bg-white py-1.5 pr-2.5 font-mono text-xs text-slate-800 outline-none focus:border-emerald-400 ${money ? "pl-6" : "pl-2.5"}`} />
  </div>
);
const WArea = ({ value, onChange, placeholder }) => (
  <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={3}
    className="mt-1.5 w-full resize-y rounded-md border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs leading-relaxed text-slate-800 outline-none focus:border-emerald-400" />
);
const Line = ({ children }) => (
  <div className="mt-2 rounded-lg border-l-4 border-emerald-500 bg-emerald-50/60 px-3 py-2 text-[12px] leading-snug text-slate-700">{children}</div>
);
const Hint = ({ children }) => (
  <div className="mt-2 flex items-start gap-1.5 rounded-md bg-amber-50 px-2.5 py-1.5 text-[11px] leading-snug text-amber-800">
    <Lightbulb className="mt-px h-3.5 w-3.5 shrink-0 text-amber-500" />
    <span>{children}</span>
  </div>
);

// Builds a self-contained HTML report of the whole call — every captured input, the live deal
// numbers, and the strategy ranking at the moment of download. Opens anywhere, prints to PDF clean.
// Composes the call as flowing CRM-note prose ("Seller is..." style) from whatever was captured.
// Empty fields are skipped entirely — the narrative never prints placeholders.
const buildCallNarrative = (cs, deal, strat) => {
  const money = (x) => usd(num(x));
  const L = { light: "light", moderate: "moderate", heavy: "heavy", vacant: "vacant", owner: "owner occupied", tenant: "tenant occupied", asap: "ASAP (two weeks or less)", soon: "within 30-60 days", flexible: "flexible on timing", distress: "property distress", hardship: "financial hardship", urgency: "urgency" };
  const p = [];
  const s1 = [];
  s1.push(`Offer call${cs.sellerName.trim() ? ` with ${cs.sellerName.trim()}` : ""}${deal.address ? ` regarding ${deal.address}` : ""}${cs.bookedBy.trim() ? `, booked by ${cs.bookedBy.trim()}` : ""}.`);
  if (cs.motivation) s1.push(`Seller's main driver is ${L[cs.motivation] || cs.motivation}.`);
  if (cs.motivNotes.trim()) s1.push(`In their words: "${cs.motivNotes.trim()}".`);
  p.push(s1.join(" "));
  const s2 = [];
  if (cs.condition) s2.push(`Property is in ${L[cs.condition]} condition${cs.occupancy ? ` and ${L[cs.occupancy]}` : ""}.`);
  else if (cs.occupancy) s2.push(`Property is ${L[cs.occupancy]}.`);
  if (isLowRate(cs.rate)) s2.push(`Loan is at ${rateNum(cs.rate)}%, well under market. If this is not locked up or creative was declined, it goes to the head of acquisitions rather than being marked dead.`);
  {
    const items = readItems(cs.condItems);
    const said = COND_ITEMS.filter(([k]) => items[k]).map(([k, label]) => `${label.toLowerCase()}: ${items[k]}`);
    if (said.length) s2.push(`Condition notes from the walkthrough - ${said.join("; ")}.`);
  }
  if (cs.hoa === "yes") s2.push(`There is an HOA${num(cs.hoaAmt) > 0 ? ` at ${money(cs.hoaAmt)} a month` : ""}.`);
  if (cs.hoa === "no") s2.push("No HOA.");
  if (cs.loan === "no") s2.push("Owned free and clear - no loan on the property.");
  if (cs.loan === "yes") {
    const bits = [];
    if (num(cs.balance) > 0) bits.push(`owes approximately ${money(cs.balance)}`);
    if (num(cs.payment) > 0) bits.push(`monthly payment around ${money(cs.payment)}`);
    if (cs.rate.trim()) bits.push(`rate ${cs.rate.trim()}`);
    s2.push(`There is a loan on the property${bits.length ? ` - seller ${bits.join(", ")}` : ""}.`);
    if (cs.behind === "yes") s2.push("Seller is behind on payments.");
    if (cs.behind === "no") s2.push("Payments are current.");
  }
  if (s2.length) p.push(s2.join(" "));
  const s3 = [];
  if (cs.timeline) s3.push(`Timeline is ${L[cs.timeline]}.`);
  if (cs.others.trim()) s3.push(`Other decision makers: ${cs.others.trim()}.`);
  if (num(cs.needCash) > 0) s3.push(`They only need ${money(cs.needCash)} in cash at closing${cs.needCashNotes.trim() ? ` (${cs.needCashNotes.trim()})` : ""}, so the rest does not have to come as cash.`);
  if (num(cs.ask) > 0) s3.push(`Seller's number is ${money(cs.ask)}${cs.priceBasis.trim() ? `, based on: "${cs.priceBasis.trim()}"` : ""}.`);
  if (cs.terms === "yes") s3.push("Seller is open to payments over time.");
  if (cs.terms === "maybe") s3.push("Seller may be open to payments over time.");
  if (cs.terms === "no") s3.push("Seller wants cash - not open to payments over time.");
  if (s3.length) p.push(s3.join(" "));
  const s4 = [];
  if (deal.arv > 0 || deal.maxCash > 0) {
    const bits = [];
    if (deal.arv > 0) bits.push(`ARV ${usd(deal.arv)}${deal.arvSource ? ` (${deal.arvSource})` : ""}`);
    if (deal.repairs > 0) bits.push(`estimated repairs ${usd(deal.repairs)}`);
    if (deal.maxCash > 0) bits.push(`MAO ${usd(deal.maxCash)}`);
    s4.push(`Deal Desk numbers at the time of the report: ${bits.join(", ")}.`);
  }
  if (strat.gap != null) s4.push(strat.gap > 0 ? `Seller's number is ${usd(strat.gap)} above max cash.` : "Seller's number is at or under max cash.");
  const top = strat.ranked[0];
  if (top && top.sc > 0) {
    const pickIds = cs.chosen ? cs.chosen.split(",").filter(Boolean) : [];
    const picks = strat.ranked.filter((r) => pickIds.includes(r.id));
    if (picks.length) s4.push(`Pitched on this call: ${picks.map((p) => p.label).join(" and ")}. Deal Desk's best fit was ${top.label} (score ${top.sc}).`);
    else s4.push(`Best-fit strategy: ${top.label} (score ${top.sc}).`);
    if (top.rs.length) s4.push(`Why: ${top.rs.slice(0, 2).join(" ")}`);
    if (top.miss.length) s4.push(`Still to get: ${top.miss[0].q}`);
  }
  if (s4.length) p.push(s4.join(" "));
  return p.filter(Boolean).join("\n\n").trim() || "No call details captured yet.";
};

const buildCallReport = (cs, deal, strat) => {
  const esc = (x) => String(x ?? "").replace(/[&<>"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
  const lbl = { light: "Light rehab", moderate: "Moderate rehab", heavy: "Heavy rehab", vacant: "Vacant", owner: "Owner occupied", tenant: "Tenant occupied", yes: "Yes", no: "No", maybe: "Maybe", asap: "ASAP (2 weeks or less)", soon: "30-60 days", flexible: "Flexible", distress: "Property distress", hardship: "Financial hardship", urgency: "Urgency" };
  const v = (x, money) => (x === "" || x == null ? "&mdash;" : money ? esc(usd(num(x))) : esc(lbl[x] || x));
  const row = (k, val) => `<tr><td>${k}</td><td>${val}</td></tr>`;
  const pillars = PILLARS.map((p) => `<span class="pill ${p.done(cs) ? "on" : ""}">${p.label}</span>`).join("");
  const narrative = buildCallNarrative(cs, deal, strat);
  const stratRows = strat.ranked.map((o, i) => `
    <div class="strat ${i === 0 && o.sc > 0 ? "best" : ""}">
      <div class="strathead"><b>${i + 1}. ${esc(o.label)}</b><span>${i === 0 && o.sc > 0 ? "BEST FIT &middot; " : ""}score ${o.sc}</span></div>
      ${o.rs.map((r) => `<div class="why">&#10003; ${esc(r)}</div>`).join("")}
      ${o.warn.map((w) => `<div class="warn">&#9888; ${esc(w)}</div>`).join("")}
      ${o.miss.map((m) => `<div class="miss">Still to ask: ${esc(m.q)}</div>`).join("")}
    </div>`).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><title>YLHB Offer Call Report</title><style>
    body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#1e293b;max-width:760px;margin:24px auto;padding:0 16px;font-size:13px;line-height:1.45}
    h1{font-size:18px;margin:0;color:#065f46}.sub{color:#64748b;font-size:11px;margin-top:2px}
    h2{font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:#94a3b8;border-bottom:1px solid #e2e8f0;padding-bottom:4px;margin:22px 0 8px}
    table{width:100%;border-collapse:collapse}td{padding:4px 6px;border-bottom:1px solid #f1f5f9;vertical-align:top}td:first-child{width:220px;color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:.06em}
    .pill{display:inline-block;border-radius:999px;padding:2px 10px;font-size:11px;font-weight:600;background:#f1f5f9;color:#94a3b8;margin-right:6px}.pill.on{background:#d1fae5;color:#047857}
    .pitched{margin-bottom:8px;border-radius:8px;background:#ecfdf5;border:1px solid #a7f3d0;padding:8px 12px;color:#065f46}
    .strat{border:1px solid #e2e8f0;border-radius:10px;padding:10px 12px;margin-top:8px}.strat.best{border-color:#059669;background:#ecfdf5}
    .strathead{display:flex;justify-content:space-between;font-size:13px}.strathead span{color:#64748b;font-size:11px}
    .why{color:#334155;margin-top:3px}.warn{color:#b45309;margin-top:3px}.miss{color:#64748b;font-style:italic;margin-top:3px}
    .foot{margin-top:26px;padding-top:10px;border-top:1px solid #e2e8f0;color:#94a3b8;font-size:10px}
    .crmbox{position:relative;border:1px solid #a7f3d0;background:#f0fdf4;border-radius:10px;padding:12px 14px;white-space:pre-wrap}
    .bar{display:flex;align-items:center;gap:10px;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid #e2e8f0}
    .pdfbtn{border:1px solid #059669;background:#059669;color:#fff;border-radius:6px;padding:7px 14px;font-size:12px;font-weight:700;cursor:pointer}
    .pdfbtn:hover{background:#047857}
    .barhint{color:#94a3b8;font-size:11px}
    .howto{margin-top:12px;border:1px solid #e2e8f0;border-radius:10px;padding:10px 14px;background:#f8fafc;font-size:12px}
    .howto b{color:#334155}.howto ol{margin:6px 0 0;padding-left:18px}.howto li{margin-bottom:4px;color:#475569}
    .howto .note{margin-top:6px;color:#94a3b8;font-size:10.5px}
    .copybtn{float:right;margin:0 0 8px 12px;border:1px solid #059669;background:#059669;color:#fff;border-radius:6px;padding:4px 10px;font-size:11px;font-weight:600;cursor:pointer}
    @media print{.copybtn{display:none}.howto{display:none}.bar{display:none}}
    @media print{body{margin:0}}
  </style></head><body>
    <div class="bar">
      <button class="pdfbtn" onclick="window.print()">Save as PDF</button>
      <span class="barhint">Opens your print box &mdash; set Destination to &ldquo;Save as PDF&rdquo;, then Save. <b>Then upload that PDF to the seller&rsquo;s contact in Closer Control, under Documents.</b></span>
    </div>
    <h1>YLHB &mdash; Offer Call Report</h1>
    <div class="sub">${esc(deal.address || "No address entered")} &middot; ${new Date().toLocaleString()}</div>
    <div style="margin-top:10px">${pillars}</div>
    <h2>Call summary &mdash; copy &amp; paste into the CRM</h2>
    <div class="crmbox">
      <button class="copybtn" onclick="navigator.clipboard.writeText(document.getElementById('crm-sum').innerText).then(()=>{this.textContent='Copied!';setTimeout(()=>{this.textContent='Copy summary'},1500)}).catch(()=>{alert('Select the text and copy it manually.')})">Copy summary</button>
      <div id="crm-sum">${esc(narrative)}</div>
    </div>
    <div class="howto">
      <b>Filing this in Closer Control</b>
      <ol>
        <li><b>Paste the summary.</b> Hit Copy summary above, open the seller's contact in Closer Control, and paste it into the conversation or notes. This is the part teammates actually read, so do it even if you skip the rest.</li>
        <li><b>Save this page as a PDF.</b> Click the green Save as PDF button at the top of this page, then set Destination to Save as PDF and click Save. It is already named with the property address.</li>
        <li><b>Attach it to the contact.</b> In that contact's record, open the Documents panel, choose Add, and upload the PDF you just saved.</li>
        <li><b>Then follow the SOP:</b> submit to the TC same day, title open within one business day, and notify Dispositions.</li>
      </ol>
      <div class="note">Closer Control moves buttons around from time to time, so if a label does not match, look for the upload or attach control inside the contact's Documents area.</div>
    </div>
    <h2>Call basics</h2><table>
      ${row("Seller", v(cs.sellerName))}${row("Booked by (lead manager)", v(cs.bookedBy))}
      ${row("Main motivator", v(cs.motivation))}${row("Motivation notes", v(cs.motivNotes))}
    </table>
    <h2>Property</h2><table>
      ${row("Condition", v(cs.condition))}
      ${(() => {
        const items = readItems(cs.condItems);
        const keys = COND_ITEMS.filter(([k]) => items[k] !== undefined);
        if (!keys.length) return row("Walkthrough checklist", "&mdash;");
        return keys.map(([k, label]) => row(label, items[k] ? esc(items[k]) : "noted, no detail")).join("");
      })()}${row("Occupancy", v(cs.occupancy))}
      ${isLowRate(cs.rate) ? row("Escalation", `<b style="color:#047857">${esc(String(rateNum(cs.rate)))}% loan &mdash; send to the head of acquisitions if not locked up or if creative was declined</b>`) : ""}
      ${row("HOA", cs.hoa === "yes" ? `Yes${num(cs.hoaAmt) > 0 ? ` &mdash; ${esc(usd(num(cs.hoaAmt)))}/mo` : ""}` : v(cs.hoa))}
      ${row("Loan on the property", v(cs.loan))}${cs.loan === "yes" ? row("Approx. balance", v(cs.balance, true)) + row("Monthly payment", v(cs.payment, true)) + row("Rate", v(cs.rate)) + row("Behind on payments", v(cs.behind)) : ""}
    </table>
    <h2>Timeline &amp; price</h2><table>
      ${row("Timeline", v(cs.timeline))}${row("Other decision makers", v(cs.others))}
      ${row("Their number", v(cs.ask, true))}
      ${row("Cash needed at closing", v(cs.needCash, true))}
      ${row("What the cash is for", v(cs.needCashNotes))}${row("How they got that number", v(cs.priceBasis))}
      ${row("Open to payments over time", v(cs.terms))}
    </table>
    <h2>Deal numbers at download</h2><table>
      ${row("ARV (After Repair Value)", deal.arv > 0 ? esc(usd(deal.arv)) : "&mdash;")}
      ${row("ARV source", deal.arvSource ? esc(deal.arvSource) : "<span style=\"color:#b45309\">not tagged</span>")}
      ${row("Repairs", deal.repairs > 0 ? esc(usd(deal.repairs)) : "&mdash;")}
      ${row("MAO (Max Allowable Offer)", deal.maxCash > 0 ? esc(usd(deal.maxCash)) : "&mdash;")}
      ${row("Gap (ask &minus; MAO)", strat.gap != null ? (strat.gap > 0 ? "+" : "") + esc(usd(strat.gap)) : "&mdash;")}
    </table>
    <h2>Strategy ranking</h2>
    ${(() => {
      const ps = strat.ranked.filter((r) => (cs.chosen || "").split(",").filter(Boolean).includes(r.id));
      return ps.length ? `<div class="pitched">Pitched on this call: <b>${esc(ps.map((p) => p.label).join(" and "))}</b></div>` : "";
    })()}
    ${stratRows}
    <div class="foot">Internal working document generated by the YLHB Deal Desk. Figures are estimates for analysis only &mdash; not an appraisal, not an offer, and no outcome is promised or guaranteed.</div>
  </body></html>`;
};

// ---- Offer Call autosave -------------------------------------------------
// Calls are saved in THIS BROWSER, keyed by the subject address, so a rep who refreshes,
// closes the tab, or comes back tomorrow picks up exactly where they left off. This is not
// team-shared storage: the CRM stays the single source of truth for what the whole team sees.
// Where an ARV came from. Tagged on every deal so the call report shows whether the number was
// comped or estimated — the difference between a real offer and a guess with a dollar sign on it.
const ARV_SOURCES = [
  ["privy", "Privy comps"],
  ["ps-comps", "PropStream comps"],
  ["ps-estimate", "PropStream estimate"],
  ["mls", "MLS / agent"],
  ["appraisal", "Appraisal"],
  ["deal-desk", "Deal Desk comps (RentCast)"],
];
const ARV_SOURCE_LABEL = Object.fromEntries(ARV_SOURCES);

const CALL_STORE_PREFIX = "ylhb.call.v1:";
const callStoreKey = (addr) => CALL_STORE_PREFIX + String(addr || "").trim().toLowerCase().replace(/\s+/g, " ");
// Only save once the address looks real (an autocomplete pick always has "City, ST"), so
// half-typed addresses do not litter storage with junk records.
const addressSavable = (addr) => String(addr || "").includes(",") && String(addr).trim().length > 8;
const readSavedCall = (addr) => {
  try {
    const raw = window.localStorage.getItem(callStoreKey(addr));
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
};
// ---- Team sync -----------------------------------------------------------
// The shared layer: calls also go to /api/calls so the next person on this address sees them.
// Identity is two things kept in this browser — the rep's name (stamped on saves so a handoff
// shows WHO captured it) and the team passcode (gates the endpoint, since the app is public).
const SYNC_ID_KEY = "ylhb.sync.identity.v1";
const readSyncId = () => {
  try { return JSON.parse(window.localStorage.getItem(SYNC_ID_KEY) || "null") || { name: "", code: "" }; }
  catch { return { name: "", code: "" }; }
};
const writeSyncId = (v) => { try { window.localStorage.setItem(SYNC_ID_KEY, JSON.stringify(v)); } catch {} };

const fmtSavedAt = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return "";
  const today = new Date().toDateString() === d.toDateString();
  return today ? d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : d.toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
};

// The walkthrough checklist. Roof and HVAC lead on purpose: they are the two biggest repair
// numbers on a house, and their age is also the lever we use later to go back for more room.
const COND_ITEMS = [
  ["roof", "Roof"],
  ["hvac", "HVAC"],
  ["water", "Water heater"],
  ["windows", "Windows"],
  ["electrical", "Electrical"],
  ["plumbing", "Plumbing"],
  ["foundation", "Foundation"],
  ["kitchen", "Kitchen"],
  ["baths", "Bathrooms"],
  ["floors", "Flooring"],
  ["paint", "Paint"],
  ["exterior", "Siding / exterior"],
];
const readItems = (raw) => { try { const v = JSON.parse(raw || "{}"); return v && typeof v === "object" ? v : {}; } catch { return {}; } };

const CALL_STAGES = ["Prep", "Open", "Motivation", "Property", "Timeline", "Price", "Numbers", "Strategy", "Close"];

const OfferCall = ({ open, onClose, cs, upd, deal, onTab, onCondition, reset, save }) => {
  const [stage, setStage] = useState(0);
  const [syncOpen, setSyncOpen] = useState(false);
  const [showCode, setShowCode] = useState(false);
  const [idDraft, setIdDraft] = useState(() => ({ ...save.syncId }));
  useEffect(() => { setIdDraft({ ...save.syncId }); }, [save.syncId]);
  if (!open) return null;
  const strat = scoreStrategies(cs, deal);
  const downloadReport = () => {
    const html = buildCallReport(cs, deal, strat);
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `offer-call-${(deal.address || "report").replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "report"}-${new Date().toISOString().slice(0, 10)}.html`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  };
  const name = cs.sellerName.trim();
  const nm = (name.split(/\s+/)[0] || "").trim() || "John"; // script greetings use the first name only, even when the full name is captured
  const canPrev = stage > 0, canNext = stage < CALL_STAGES.length - 1;
  return (
    <div className="fixed inset-y-0 right-0 z-40 flex w-full flex-col border-l border-slate-200 bg-white shadow-2xl sm:w-[470px]">
      {/* header */}
      <div className="border-b border-slate-100 p-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900"><Phone className="h-4 w-4 text-emerald-600" /> Offer Call</div>
          <div className="flex items-center gap-1.5">
            <button type="button" onClick={() => { if (window.confirm("Clear this call and start fresh?")) { reset(); setStage(0); } }} className="rounded-md border border-slate-200 px-2 py-1 text-[10px] font-semibold text-slate-500 hover:bg-slate-50">New call</button>
            <button type="button" onClick={onClose} title="Minimize — your call info stays put" className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 text-slate-500 hover:bg-slate-50"><Minus className="h-4 w-4" /></button>
          </div>
        </div>
        {/* The drawer covers the address field, so the call has to say which house it is about. */}
        <div className="mt-1.5 flex items-start gap-1.5 rounded-md bg-slate-100 px-2.5 py-1.5">
          <MapPin className="mt-px h-3.5 w-3.5 shrink-0 text-slate-400" />
          <div className="min-w-0">
            <div className="text-[11.5px] font-bold leading-snug text-slate-800">
              {deal.address ? deal.address : <span className="font-semibold text-amber-700">No address set. Close this and pick one up top before you dial.</span>}
            </div>
            {deal.address && (deal.arv > 0 || deal.maxCash > 0) && (
              <div className="mt-0.5 text-[10.5px] leading-snug text-slate-500">
                {deal.arv > 0 ? <>ARV {usd(deal.arv)}</> : null}
                {deal.arv > 0 && deal.maxCash > 0 ? " · " : ""}
                {deal.maxCash > 0 ? <>max allowable cash offer <b className="text-slate-700">{usd(deal.maxCash)}</b> · anchor at <b className="text-emerald-700">{usd(Math.round(deal.maxCash * ANCHOR_PCT))}</b></> : null}
              </div>
            )}
          </div>
        </div>

        {/* four pillars */}
        <div className="mt-2 flex items-center gap-1.5">
          {PILLARS.map((p) => (
            <span key={p.id} className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold ${p.done(cs) ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-400"}`}>
              {p.done(cs) ? <CheckCircle2 className="h-3 w-3" /> : <MinusCircle className="h-3 w-3" />}{p.label}
            </span>
          ))}
        </div>
        {/* stage pips */}
        <div className="mt-2 flex flex-wrap gap-1">
          {CALL_STAGES.map((t, i) => (
            <button key={t} type="button" onClick={() => setStage(i)}
              className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${i === stage ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-500 hover:bg-slate-200"}`}>{t}</button>
          ))}
        </div>
        <div className="mt-1.5 text-[10px] leading-snug text-slate-400">
          {!save.savable
            ? "Pick the subject address up top and this call saves itself."
            : save.sync.status === "synced" && save.sync.by
              ? <>Shared with the team. Last saved by <b className="text-slate-500">{save.sync.by}</b>{save.sync.at ? <> at <b className="text-slate-500">{fmtSavedAt(save.sync.at)}</b></> : null}.</>
              : save.sync.status === "saving"
                ? "Saving to the team…"
                : save.sync.status === "synced"
                  ? <>Shared with the team{save.sync.at ? <> · saved <b className="text-slate-500">{fmtSavedAt(save.sync.at)}</b></> : ""}.</>
                  : save.sync.status === "denied"
                    ? <span className="text-amber-600">Team passcode was rejected. Saving to this browser only until it is fixed.</span>
                    : save.sync.status === "error"
                      ? <span className="text-amber-600">Cannot reach the team store right now. Your work is safe in this browser.</span>
                      : save.loadedAt
                        ? <>Picked up your saved call from <b className="text-slate-500">{fmtSavedAt(save.loadedAt)}</b>.</>
                        : save.savedAt
                          ? <>Saved <b className="text-slate-500">{fmtSavedAt(save.savedAt)}</b> to this address.</>
                          : "Saves itself to this address as you type."}
          {" "}
          <button type="button" onClick={() => setSyncOpen((v) => !v)} className="font-semibold text-emerald-600 hover:underline">
            {save.syncId.code ? "sync settings" : "turn on team sync"}
          </button>
        </div>
        {syncOpen && (
          <div className="mt-2 rounded-lg border border-slate-200 bg-slate-50 p-2.5">
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Team sync</div>
            <div className="mt-1 text-[10.5px] leading-snug text-slate-500">
              Your name gets stamped on every call you save, so whoever opens this address next knows who captured it. The passcode is the same one for the whole team — get it from B.
            </div>
            <input value={idDraft.name} onChange={(e) => setIdDraft({ ...idDraft, name: e.target.value })} placeholder="Your name"
              className="mt-2 w-full rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 outline-none focus:border-emerald-400" />
            <div className="relative mt-1.5">
              <input value={idDraft.code} onChange={(e) => setIdDraft({ ...idDraft, code: e.target.value })} placeholder="Team passcode"
                type={showCode ? "text" : "password"} autoCapitalize="off" autoCorrect="off" spellCheck={false}
                className="w-full rounded-md border border-slate-200 bg-white px-2.5 py-1.5 pr-14 text-xs text-slate-800 outline-none focus:border-emerald-400" />
              <button type="button" onClick={() => setShowCode((v) => !v)}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-slate-400 hover:bg-slate-100 hover:text-slate-600">
                {showCode ? "hide" : "show"}
              </button>
            </div>
            {/* A pasted passcode often drags a trailing space along, which fails silently. Flag it. */}
            {idDraft.code !== idDraft.code.trim() && (
              <div className="mt-1 flex items-start gap-1.5 text-[10.5px] leading-snug text-amber-700">
                <AlertTriangle className="mt-px h-3 w-3 shrink-0 text-amber-500" />
                There is a space at the start or end of that passcode. It will be trimmed when you save.
              </div>
            )}
            <div className="mt-2 flex gap-1.5">
              <button type="button" onClick={() => { save.setIdentity({ name: idDraft.name.trim(), code: idDraft.code.trim() }); setSyncOpen(false); }}
                className="rounded-md bg-emerald-600 px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-emerald-700">Save</button>
              <button type="button" onClick={() => setSyncOpen(false)}
                className="rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-[11px] font-semibold text-slate-600 hover:bg-slate-100">Cancel</button>
            </div>
          </div>
        )}
      </div>

      {/* body */}
      <div className="flex-1 overflow-y-auto p-3 pb-4">
        {/* Loud, unmissable warning when this call is NOT reaching the team. Silent isolation is the
            real risk here: a rep works all week and nobody else ever sees a single call. */}
        {save.savable && (save.sync.status === "denied" || save.sync.status === "error" || save.sync.status === "off") && (
          <div className="mb-3 rounded-xl border-2 border-red-400 bg-red-50 p-3">
            <div className="flex items-start gap-2">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
              <div>
                <div className="text-[12px] font-bold text-red-800">
                  {save.sync.status === "denied" ? "Wrong team passcode — your team cannot see this call." : save.sync.status === "off" ? "Team sync is not set up — your team cannot see this call." : "Cannot reach the team right now — your team cannot see this call."}
                </div>
                <div className="mt-0.5 text-[11px] leading-snug text-red-700">
                  Your work is safe in this browser and nothing is lost. But it is not being shared, so the next person on this address will see an empty call.
                  {save.sync.status === "denied" ? " Fix the passcode below and it will sync from here on." : save.sync.status === "off" ? " Turn it on below." : " It will keep retrying as you type."}
                </div>
                {save.sync.status !== "error" && (
                  <button type="button" onClick={() => setSyncOpen(true)}
                    className="mt-2 rounded-md bg-red-600 px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-red-700">
                    {save.sync.status === "denied" ? "Fix passcode" : "Set up team sync"}
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
        {stage === 0 && (<div>
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Before you dial (SOP Step 1)</div>
          <div className="mt-2 text-[12px] leading-relaxed text-slate-600">Review the CRM notes, lead source, motivation summary, timeline, ballpark price, repair notes, photos, comps, the Zillow estimate, and ownership on PropStream. Walk in informed.</div>
          <Hint>Type the address up top and hit <b>Auto-comp</b> before you dial — have the ARV and max cash on screen while they talk.</Hint>
          <WField label="Seller name"><WText value={cs.sellerName} onChange={(v) => upd("sellerName", v)} placeholder="John Smith" /></WField>
          {(deal.ownerType === "Organization" || deal.heldFor) && (
            <div className="mt-2 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[10.5px] leading-snug text-slate-600">
              {deal.ownerType === "Organization" && (
                <div className="font-semibold text-amber-700">Owned by an entity, not a person. Find out who actually has authority to sign before you pitch anything.</div>
              )}
              {deal.heldFor && <div className={deal.ownerType === "Organization" ? "mt-0.5" : ""}>Owned for <b className="text-slate-800">{deal.heldFor}</b>.</div>}
            </div>
          )}
          {deal.ownerNames && deal.ownerNames.length > 0 && (
            <div className="mt-1 text-[10.5px] leading-snug text-slate-400">
              Owner of record: <span className="text-slate-600">{deal.ownerNames.join(", ")}</span> — prefilled as a starting point. Confirm who you're actually talking to.
            </div>
          )}
          <WField label="Who booked the call (lead manager)"><WText value={cs.bookedBy} onChange={(v) => upd("bookedBy", v)} placeholder="Mary" /></WField>
          <WField label="Your wholesale / assignment fee">
            <WText money value={deal.wholesaleFee} onChange={deal.setWholesaleFee} placeholder="20000" />
          </WField>
          <div className="mt-1 text-[10.5px] leading-snug text-slate-400">
            You get paid first. Your fee comes out of the deal before the seller's offer, so the number you quote already pays you.
          </div>
          <div className="mt-3 rounded-lg bg-slate-50 px-3 py-2 text-[11px] italic leading-snug text-slate-500">“People do not care how much you know, until they know how much you care.”</div>
        </div>)}

        {stage === 1 && (<div>
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Opening</div>
          <Line>“Hey, is this {nm}?” … “Hey {nm}, how are you? My name is ____, and my partner {cs.bookedBy.trim() || "Mary"} scheduled a call for us today because you were looking to sell your property on ____. Is that right?”</Line>
          <Line>Or simply: “Hi {nm}, my name is ____ and I'm partners with {cs.bookedBy.trim() || "Mary"}. How are you doing today?”</Line>
          <Hint>Acknowledge their surroundings and mirror their energy. Slow it down — comfort first, authority second, numbers later.</Hint>
        </div>)}

        {stage === 2 && (<div>
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Rapport &amp; motivation</div>
          <Line>“Catch me up to speed — what's going on with the house?”</Line>
          <Line>“What has you thinking about selling?”</Line>
          <Line>“How were you hoping we could help?”</Line>
          <Hint>Don't interrogate — keep it natural. Probe with “What's that been like?” · “How long has that been going on?” · “What happens next once you sell?”</Hint>
          <WField label="Main motivator">
            <WChips value={cs.motivation} onChange={(v) => upd("motivation", v)} opts={[["distress", "Property distress"], ["hardship", "Financial hardship"], ["urgency", "Urgency"]]} />
          </WField>
          {/* Pick-one guidance. Reps hear three problems at once and freeze, so this names what each
              bucket actually sounds like and tells them to pick the one driving the decision. */}
          <div className="mt-2 rounded-lg border border-slate-200 bg-white p-2.5 text-[11px] leading-snug text-slate-600">
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">What these mean</div>
            <div className="mt-1.5"><b className="text-slate-800">Property distress</b> is the house itself being the problem. Repairs they cannot afford or manage, a bad tenant, code issues, a place they inherited and cannot keep up.</div>
            <div className="mt-1.5"><b className="text-slate-800">Financial hardship</b> is money pressure pushing the sale. Behind on payments, medical bills, divorce, job loss, taxes owed, a payment they can no longer carry.</div>
            <div className="mt-1.5"><b className="text-slate-800">Urgency</b> is a clock. A job transfer, a closing date on another house, a move, an estate that has to settle, or a life change that will not wait.</div>
            <div className="mt-2 text-[10.5px] text-slate-400">Most sellers have more than one. Pick the one that is actually driving the decision, and put the story in their own words below. That story is what you repeat back later when you ask for the agreement.</div>
          </div>
          <WField label="Notes — their why, in their words"><WArea value={cs.motivNotes} onChange={(v) => upd("motivNotes", v)} placeholder="tired landlord, moving to FL for grandkids…" /></WField>
        </div>)}

        {stage === 3 && (<div>
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Property discovery</div>
          {/* Beds and baths the record got wrong. Same controls as the calculator, so a rep who
              walks a legit 4th bedroom can add it without leaving the call. */}
          <div className="mt-3 rounded-lg border border-slate-200 bg-white p-2.5">
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Beds and baths the record missed</div>
            <div className="mt-0.5 text-[10.5px] leading-snug text-slate-500">
              County says {deal.recBeds != null ? `${deal.recBeds} bed` : "—"}{deal.recBaths != null ? ` / ${deal.recBaths} bath` : ""}. If they walked you through more than that, add it here and the ARV moves.
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Extra beds</div>
                <div className="mt-1 flex items-center gap-1.5">
                  <button type="button" onClick={() => deal.setAdjBeds(Math.max(-5, deal.adjBeds - 1))} className="h-7 w-7 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">−</button>
                  <span className="w-8 text-center font-mono text-sm font-bold text-slate-800">{deal.adjBeds > 0 ? `+${deal.adjBeds}` : deal.adjBeds}</span>
                  <button type="button" onClick={() => deal.setAdjBeds(Math.min(5, deal.adjBeds + 1))} className="h-7 w-7 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">+</button>
                </div>
              </div>
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Extra baths</div>
                <div className="mt-1 flex items-center gap-1.5">
                  <button type="button" onClick={() => deal.setAdjBaths(Math.max(-5, deal.adjBaths - 0.5))} className="h-7 w-7 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">−</button>
                  <span className="w-8 text-center font-mono text-sm font-bold text-slate-800">{deal.adjBaths > 0 ? `+${deal.adjBaths}` : deal.adjBaths}</span>
                  <button type="button" onClick={() => deal.setAdjBaths(Math.min(5, deal.adjBaths + 0.5))} className="h-7 w-7 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">+</button>
                </div>
              </div>
            </div>
            {deal.subjAdjust !== 0 && (
              <div className="mt-1.5 text-[10.5px] leading-snug text-emerald-700">
                Adds {deal.subjAdjust > 0 ? "+" : "−"}{usd(Math.abs(deal.subjAdjust))} to the ARV.
              </div>
            )}
            <div className="mt-1 text-[10.5px] leading-snug text-slate-400">
              Only for rooms the county missed at the same square footage. If the extra room also means extra sq ft, fix the sq ft up top instead.
            </div>
          </div>

          <Line>“What have you done to the property since you bought it?” · “What can you tell me about the current condition?”</Line>
          <Hint>You are after the overall rehab level and their perception, not a formal inspection. Work the list below conversationally and write down what they say.</Hint>

          {/* Checklist: tap an item to log it, then type what the seller said. Roof and HVAC first
              because they carry the biggest dollars and set up the later ask for more room. */}
          {(() => {
            const items = readItems(cs.condItems);
            const setItem = (k, v) => {
              const next = { ...items };
              if (v === null) delete next[k]; else next[k] = v;
              upd("condItems", Object.keys(next).length ? JSON.stringify(next) : "");
            };
            const logged = Object.keys(items).length;
            return (
              <div className="mt-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Walkthrough checklist</div>
                  <div className="text-[10px] font-semibold text-slate-400">{logged} of {COND_ITEMS.length} logged</div>
                </div>
                <div className="mt-1.5 space-y-1">
                  {COND_ITEMS.map(([k, label]) => {
                    const on = items[k] !== undefined;
                    return (
                      <div key={k} className={`rounded-lg border ${on ? "border-emerald-300 bg-emerald-50/50" : "border-slate-200 bg-white"}`}>
                        <button type="button" onClick={() => setItem(k, on ? null : "")}
                          className="flex w-full items-center gap-2 px-2.5 py-1.5 text-left">
                          <span className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border text-[10px] font-bold ${on ? "border-emerald-600 bg-emerald-600 text-white" : "border-slate-300 text-transparent"}`}>✓</span>
                          <span className={`text-[11.5px] font-semibold ${on ? "text-emerald-900" : "text-slate-600"}`}>{label}</span>
                          {on && items[k] ? <span className="ml-auto truncate text-[10.5px] text-slate-500">{items[k]}</span> : null}
                        </button>
                        {on && (
                          <div className="px-2.5 pb-2">
                            <input value={items[k]} onChange={(e) => setItem(k, e.target.value)}
                              placeholder={k === "roof" ? "e.g. replaced 4 years ago" : k === "hvac" ? "e.g. original, 2001" : "what did they say?"}
                              className="w-full rounded-md border border-slate-200 bg-white px-2 py-1 font-mono text-[11px] text-slate-800 outline-none focus:border-emerald-400" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
                <div className="mt-1.5 text-[10.5px] leading-snug text-slate-400">
                  Log the age of anything they volunteer. An old roof or original HVAC is both a real repair number and the reason you can go back for more room later.
                </div>
              </div>
            );
          })()}
          <WField label="Condition (drives repairs in the calculator)">
            <WChips value={cs.condition} onChange={(v) => { upd("condition", v); onCondition(v); }} opts={[["light", "Light"], ["moderate", "Moderate"], ["heavy", "Heavy"]]} />
          </WField>
          <WField label="Estimated repairs">
            <WText money value={deal.repairOverride} onChange={deal.setRepairOverride} placeholder={deal.repairs > 0 ? String(Math.round(deal.repairs)) : "type a number"} />
          </WField>
          <div className="mt-1 text-[10.5px] leading-snug text-slate-400">
            {num(deal.repairOverride) > 0
              ? <>Using your number: <span className="font-semibold text-slate-600">{usd(num(deal.repairOverride))}</span>. Clear the box to go back to the condition estimate. This drives the MAO.</>
              : deal.repairs > 0
                ? <>From the condition chip above: <span className="font-semibold text-slate-600">{usd(deal.repairs)}</span>{deal.repairPsf > 0 ? ` (${usd(deal.repairPsf)}/sf)` : ""}. Type a real number here if you have a contractor bid — it overrides the estimate.</>
                : <>Pick a condition above, or type a real repair number if you have one.</>}
          </div>
          {cs.condition && impliedCondition(deal.repairs, deal.sqft) && impliedCondition(deal.repairs, deal.sqft) !== cs.condition && (
            <div className="mt-1.5 flex items-start gap-1.5 rounded-md border border-amber-300 bg-amber-50 px-2.5 py-1.5 text-[10.5px] leading-snug text-amber-800">
              <AlertTriangle className="mt-px h-3 w-3 shrink-0 text-amber-500" />
              <span>
                These disagree. You tapped <b>{cs.condition}</b>, but {usd(deal.repairs)} on {num(deal.sqft).toLocaleString()} sq ft is about ${Math.round(num(deal.repairs) / num(deal.sqft))}/sf, which is a <b>{impliedCondition(deal.repairs, deal.sqft)}</b> rehab. Your offer is being built on the {usd(deal.repairs)}, so fix whichever one is wrong.
              </span>
            </div>
          )}
          {!cs.condition && impliedCondition(deal.repairs, deal.sqft) && (
            <div className="mt-1.5 flex items-start gap-1.5 text-[10.5px] leading-snug text-slate-500">
              <Info className="mt-px h-3 w-3 shrink-0 text-slate-400" />
              <span>
                {usd(deal.repairs)} on {num(deal.sqft).toLocaleString()} sq ft works out to about ${Math.round(num(deal.repairs) / num(deal.sqft))}/sf, which reads as a <b className="text-slate-700">{impliedCondition(deal.repairs, deal.sqft)} rehab</b>. The strategy scoring is using that until you tap a chip. Confirm it with the seller.
              </span>
            </div>
          )}
          {/* The chain a rep is actually changing when they touch repairs. Kept to one line so the
              stage stays readable, but it makes condition feel connected to the offer. */}
          {deal.arv > 0 && !deal.repairsKnown && (
            <div className="mt-2 flex items-start gap-1.5 rounded-md border border-amber-300 bg-amber-50 px-2.5 py-1.5 text-[11px] leading-snug text-amber-800">
              <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0 text-amber-500" />
              <span><b>No max offer yet.</b> Tap a condition above or type a repair number. Quoting a price before you know the repairs is how you end up stuck with one.</span>
            </div>
          )}
          {deal.arv > 0 && deal.repairsKnown && (
            <div className="mt-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2">
              <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">What this does to your offer</div>
              <div className="mt-1 flex items-center justify-between gap-2">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">ARV</div>
                <div className="font-mono text-sm font-bold text-slate-800">{usd(deal.arv)}</div>
              </div>
              <div className="text-slate-300">−</div>
              <div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Repairs</div>
                <div className="font-mono text-sm font-bold text-slate-800">{deal.repairs > 0 ? usd(deal.repairs) : "—"}</div>
              </div>
              <div className="text-slate-300">=</div>
              <div className="text-right">
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Max offer</div>
                <div className="font-mono text-sm font-bold text-emerald-700">{deal.maxCash > 0 ? usd(deal.maxCash) : "—"}</div>
              </div>
              </div>
              <div className="mt-1 text-[10.5px] leading-snug text-slate-500">
                Repairs come straight off what you can pay, so every item on the checklist above is worth real money. Anchor at <b className="text-emerald-700">{deal.maxCash > 0 ? usd(Math.round(deal.maxCash * ANCHOR_PCT)) : "—"}</b>, never go past the max.
              </div>
            </div>
          )}
          <WField label="Occupancy">
            <WChips value={cs.occupancy} onChange={(v) => upd("occupancy", v)} opts={[["vacant", "Vacant"], ["owner", "Owner occupied"], ["tenant", "Tenant"]]} />
          </WField>
          <Line>“Do you still owe anything on it?”</Line>
          <Hint>Ask it exactly that casually. If yes, follow with “What's your current payment?” — the payment and balance quietly decide Sub-To vs Hybrid vs Seller Finance.</Hint>
          <WField label="Loan on the property?">
            <WChips value={cs.loan} onChange={(v) => upd("loan", v)} opts={[["yes", "Yes"], ["no", "Free & clear"]]} />
          </WField>
          {cs.loan === "yes" && (<>
            <div className="grid grid-cols-2 gap-2">
              <WField label="Approx. balance"><WText money value={cs.balance} onChange={(v) => upd("balance", v)} placeholder="148000" /></WField>
              <WField label="Monthly payment"><WText money value={cs.payment} onChange={(v) => upd("payment", v)} placeholder="1150" /></WField>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <WField label="Rate (if they know) — use decimals, like 3.875"><WText value={cs.rate} onChange={(v) => upd("rate", v)} placeholder="3.875" /></WField>
            </div>
            {isLowRate(cs.rate) && (
              <div className="mt-2 rounded-xl border-2 border-emerald-500 bg-emerald-50 p-3">
                <div className="flex items-start gap-2">
                  <Zap className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                  <div>
                    <div className="text-[12px] font-bold text-emerald-900">{rateNum(cs.rate)}% loan. Do not let this one go.</div>
                    <div className="mt-0.5 text-[11px] leading-snug text-emerald-800">
                      A rate this far under market is worth real money on its own, and it cannot be replaced once this seller sells to someone else. Work the creative offer hard on this call.
                    </div>
                    <div className="mt-1.5 text-[11px] font-semibold leading-snug text-emerald-900">
                      Required after this call: if it is not locked up, or the seller is flat out declining creative financing, send it to the head of acquisitions. Do not mark it dead yourself.
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-2">
              <WField label="Behind on payments?"><WChips value={cs.behind} onChange={(v) => upd("behind", v)} opts={[["yes", "Yes"], ["no", "Current"]]} /></WField>
            </div>
            <WField label="Does that payment include taxes and insurance?">
              <WChips value={cs.escrowed} onChange={(v) => upd("escrowed", v)} opts={[["yes", "Yes, escrowed"], ["no", "No, P&I only"]]} />
            </WField>
            {cs.escrowed === "no" && (
              <WField label="Monthly taxes + insurance">
                <WText money value={cs.tiMonthly} onChange={(v) => upd("tiMonthly", v)} placeholder="350" />
              </WField>
            )}
            <Hint>Ask it plainly: “Is that payment just principal and interest, or does it include your taxes and insurance?” Most sellers quote the escrowed number, but the ones who do not will make this deal look better than it is.</Hint>

            <WField label="Is there an HOA?">
              <WChips value={cs.hoa} onChange={(v) => upd("hoa", v)} opts={[["yes", "Yes"], ["no", "No"]]} />
            </WField>
            {typeof deal.hoaKnown === "boolean" && (
              <div className="mt-1 text-[10.5px] leading-snug text-slate-400">
                The property record says {deal.hoaKnown ? "there is an HOA" : "there is no HOA"}. Confirm it with the seller, since records lag.
              </div>
            )}
            {cs.hoa === "yes" && (
              <>
                <WField label="HOA dues (monthly)">
                  <WText money value={cs.hoaAmt} onChange={(v) => upd("hoaAmt", v)} placeholder="250" />
                </WField>
                <Hint>Dues come out of the same rent the payment does, so they go straight into the test below. Also ask whether the HOA allows rentals, whether there is a cap or a waitlist, and whether any special assessment is coming. A no-rental HOA kills a Sub-To hold no matter how good the payment looks.</Hint>
              </>
            )}

            {/* The hold test */}
            <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Payment vs market rent</div>
                {!deal.rent && (
                  <button type="button" onClick={deal.onGetRent} disabled={deal.rentLoading}
                    className="rounded-md border border-emerald-200 bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-700 hover:bg-emerald-100 disabled:opacity-50">
                    {deal.rentLoading ? "Pulling…" : "Get market rent"}
                  </button>
                )}
              </div>
              {(() => {
                const pc = pitiCheck(cs, deal.rent);
                if (!deal.rent) return <div className="mt-1 text-[10.5px] leading-snug text-slate-500">Pull the market rent to test whether this payment can carry the house.</div>;
                if (!pc) return <div className="mt-1 text-[10.5px] leading-snug text-slate-500">Market rent {usd(deal.rent)}/mo. Add their payment above to run the test.</div>;
                const pct = Math.round(pc.ratio * 100);
                const tone = pc.verdict === "good" ? "text-emerald-700" : pc.verdict === "thin" ? "text-amber-700" : "text-red-700";
                return (
                  <div className="mt-1">
                    <div className="text-[12px] font-bold text-slate-800">
                      {usd(Math.round(pc.piti))} payment vs {usd(pc.rent)} rent = <span className={tone}>{pct}%</span>
                    </div>
                    {pc.hoa > 0 && <div className="mt-0.5 text-[10.5px] text-slate-500">Includes {usd(pc.hoa)}/mo HOA dues.</div>}
                    <div className={`mt-0.5 text-[11px] font-semibold leading-snug ${tone}`}>
                      {pc.verdict === "good"
                        ? "Under 65%. This one can carry itself as a rental."
                        : pc.verdict === "thin"
                          ? `Between 65% and 75%. Break-even as a standard rental. Needs ${usd(pc.targetPiti)} or less to have real room, so it only works if your exit beats market rent.`
                          : `Over 75%. Not a Sub-To hold. The payment would need to be around ${usd(pc.targetPiti)} or less.`}
                    </div>
                    {pc.missingTI && <div className="mt-1 text-[10.5px] leading-snug text-amber-700">Taxes and insurance are not in that payment yet, so the real number is worse than this.</div>}
                    {pc.missingHOA && <div className="mt-1 text-[10.5px] leading-snug text-amber-700">There is an HOA but the dues are not entered yet, so the real number is worse than this.</div>}
                    {pc.unknownEscrow && <div className="mt-1 text-[10.5px] leading-snug text-slate-500">Confirm whether taxes and insurance are in that payment, or this ratio may be understated.</div>}
                  </div>
                );
              })()}
            </div>
          </>)}
        </div>)}

        {stage === 4 && (<div>
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Timeline</div>
          <Line>“How soon are you hoping to close?”</Line>
          <Line>“Is there anyone else involved in the decision?”</Line>
          <Line>“In a perfect world, what would this situation look like for you?”</Line>
          <WField label="Timeline">
            <WChips value={cs.timeline} onChange={(v) => upd("timeline", v)} opts={[["asap", "ASAP (≤ 2 wks)"], ["soon", "30–60 days"], ["flexible", "Flexible"]]} />
          </WField>
          <WField label="Other decision makers"><WArea value={cs.others} onChange={(v) => upd("others", v)} placeholder="spouse, sibling on title…" /></WField>
        </div>)}

        {stage === 5 && (<div>
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Price discovery</div>
          <Line>“Do you already have an idea of what you were hoping to get for the property?”</Line>
          <Hint>Let THEM say a number first. If they resist: “I totally understand that. But if you did know, what do you think that number would be?” Still stuck: “How much do you still owe?” → “And after paying that off, how much would you want left over?”</Hint>
          <WField label="Their number"><WText money value={cs.ask} onChange={(v) => upd("ask", v)} placeholder="215000" /></WField>
          <WField label="“How did you come up with that number?” (optional)"><WArea value={cs.priceBasis} onChange={(v) => upd("priceBasis", v)} placeholder="Zillow, neighbor sold for…, appraisal…" /></WField>

          {/* Their asking price is a wish. The cash they truly need at closing is the real number,
              and it is almost always far smaller. Every dollar found here is a dollar we keep. */}
          <div className="mt-3 rounded-lg border-l-4 border-slate-900 bg-slate-100 px-3 py-2">
            <div className="text-[11.5px] font-bold text-slate-900">Now find the smallest number they can actually live with.</div>
            <div className="mt-0.5 text-[11px] leading-snug text-slate-600">
              What they are asking and what they need are two different numbers. Work down this ladder until they give you the second one. Do not negotiate against their asking price, negotiate against their need.
            </div>
          </div>
          <Line>1. “After the loan is paid off and everything is settled, what do you actually need in your pocket to move on?”</Line>
          <Line>2. “What are you doing with the money?” This is the one that matters. Movers and a deposit is a different number than a lawyer's retainer or a roof on the next place.</Line>
          <Line>3. “If I covered the back payments and all of the closing costs, how close does that get you?”</Line>
          <Line>4. “Does all of it have to come at closing, or could part of it come to you over the next few months?”</Line>
          <Line>5. “What is the piece you absolutely have to have on closing day?” That answer is the real number.</Line>
          <Hint>Say the question and then stop. Silence is what gets you the honest answer here. Most sellers name something well under their asking price, and on a creative deal that number is what you have to solve for, not the price.</Hint>
          <div className="grid grid-cols-2 gap-2">
            <WField label="Cash they need at closing"><WText money value={cs.needCash} onChange={(v) => upd("needCash", v)} placeholder="8000" /></WField>
            <WField label="What is it for?"><WText value={cs.needCashNotes} onChange={(v) => upd("needCashNotes", v)} placeholder="movers + deposit" /></WField>
          </div>
          {num(cs.needCash) > 0 && num(cs.ask) > 0 && (
            <div className="mt-1.5 rounded-md border border-emerald-300 bg-emerald-50 px-2.5 py-1.5 text-[11px] leading-snug text-emerald-800">
              They are asking {usd(num(cs.ask))} but only need <b>{usd(num(cs.needCash))}</b> at closing. That is <b>{usd(num(cs.ask) - num(cs.needCash))}</b> that does not have to be cash, and it is the room a creative structure lives in.
            </div>
          )}
          <div className="mt-3 text-[10px] font-bold uppercase tracking-widest text-slate-400">Rebuttals — tap to open</div>
          {REBUTTALS.map((r, i) => (
            <details key={i} className="mt-1.5 rounded-lg border border-slate-200 bg-white px-3 py-2">
              <summary className="cursor-pointer text-[11px] font-semibold text-slate-700">{r.t}</summary>
              <div className="mt-1.5 text-[11px] leading-snug text-slate-600">{r.a}</div>
            </details>
          ))}
        </div>)}

        {stage === 6 && (<div>
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Run the numbers</div>
          <div className="mt-2 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-2"><div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">ARV</div><div className="font-mono text-sm font-bold text-slate-800">{deal.arv > 0 ? usd(deal.arv) : "—"}</div></div>
            <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-2"><div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">Max cash</div><div className="font-mono text-sm font-bold text-slate-800">{deal.maxCash > 0 ? usd(deal.maxCash) : "—"}</div></div>
            <div className={`rounded-lg border p-2 ${strat.gap != null && strat.gap > 0 ? "border-amber-300 bg-amber-50" : "border-emerald-300 bg-emerald-50"}`}><div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">Gap</div><div className="font-mono text-sm font-bold text-slate-800">{strat.gap != null ? (strat.gap > 0 ? "+" : "") + usd(strat.gap) : "—"}</div></div>
          </div>
          {deal.maxCash <= 0 && <Hint>No ARV yet — hit <b>Auto-comp</b> up top. The strategy stage needs the max cash number to rank against their ask.</Hint>}
          <Line>Value framing: “What Zillow doesn't know is the actual condition of the property.” · “We buy houses as-is. No repairs, no commissions, no inspections, and no showings.” · “We can close quickly and make this process simple.”</Line>
          <Line>The main question: “If we could close quickly, buy it as-is, and make this super simple for you, what would you need to walk away with?”</Line>
          <Hint>Negotiation anchor, script-style: “In a perfect world, we would probably need to be somewhere in the low ____s. Now obviously the world isn't perfect — but how close could you get me to that?” Anchor a bit under your max cash so there's room to move.</Hint>
          {/* The move the roof/HVAC answers were being saved for. */}
          <div className="mt-3 rounded-lg border-l-4 border-slate-900 bg-slate-100 px-3 py-2">
            <div className="text-[11.5px] font-bold text-slate-900">Stuck on price? Use the roof and the HVAC.</div>
            <div className="mt-0.5 text-[11px] leading-snug text-slate-600">
              If they will not move and you need room, this is what the checklist answers were for. Put them on a brief hold, come back, and use the condition of the big-ticket items as the reason you can ask for more.
            </div>
          </div>
          <Line>“Do you mind holding for just a minute? Let me see what I can do.”</Line>
          <Line>Come back with: “I went back and looked at this again. You said the roof was ____ and the HVAC was ____. Based on that, let me see if I can get this approved at a better number for you.”</Line>
          <Hint>Only works if you actually logged those answers in the Property stage. This is a real reason to revisit the number, not a script trick, so do not invent condition details you were never told.</Hint>
          <Line>Takeaway close if they hold firm: “If that's truly what you need to accomplish your goal, then honestly listing it with an agent might make more sense.”</Line>
          <WField label="Open to payments over time? (sets up creative)">
            <WChips value={cs.terms} onChange={(v) => upd("terms", v)} opts={[["yes", "Yes"], ["maybe", "Maybe"], ["no", "No"]]} />
          </WField>
        </div>)}

        {stage === 7 && (() => {
          // Rebuilt for a live call: pick one, read one thing, everything else stays folded.
          // Reps often pitch two: the cash number to anchor, then a creative option for sellers who
          // want more. Selection is a set, stored as a comma string so team sync and saving are unchanged.
          const ids = cs.chosen ? cs.chosen.split(",").filter(Boolean) : [];
          const toggle = (id) => upd("chosen", (ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]).join(","));
          // Order matters more than score here. A two-option close leads with the cash number so it
          // anchors low, then offers the creative option as the way to get closer to what they want.
          // Pitching the creative one first gives away the anchor.
          const chosenList = strat.ranked.filter((r) => ids.includes(r.id))
            .sort((a, b) => (a.id === "cash" ? -1 : b.id === "cash" ? 1 : 0));
          const fallback = strat.ranked[0] && strat.ranked[0].sc > 0 ? strat.ranked[0] : null;
          const showList = chosenList.length ? chosenList : (fallback ? [fallback] : []);
          const active = showList[0] || null;
          const multi = showList.length > 1;
          const secondFor = (id) => ({
            nov: "“The short version is we prepare and sell it on your behalf, so you end up closer to full value, and we get paid out of what we add rather than out of your pocket.”",
            sf: "“The short version is you get the number you want, and instead of one lump sum today, it comes to you over time on terms we agree on together.”",
            hybrid: "“The short version is you get the number you want. Part of it comes at closing, and the rest comes to you over time instead of all at once.”",
            subto: "“The short version is you get the number you want, and instead of waiting on a bank, we take over what is already in place and handle it from here.”",
          }[id] || "");
          const overAsk = strat.gap != null && strat.gap > 0;
          return (<div>
            <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Strategy</div>
            <div className="mt-0.5 text-[11px] leading-snug text-slate-500">Tap the one you are pitching, or tap two to present options. Scored by fit, but you decide.</div>
            <div className="mt-2 rounded-lg border-l-4 border-slate-900 bg-slate-100 px-3 py-2">
              <div className="text-[11.5px] font-bold text-slate-900">Always pitch cash first.</div>
              <div className="mt-0.5 text-[11px] leading-snug text-slate-600">
                Even when cash is not the play, say the cash number out loud before anything else. It anchors the conversation low, and everything after it sounds like you moving toward them. Lead with a creative offer and you have given away the anchor for nothing.
              </div>
              {deal.maxCash > 0 && (
                <div className="mt-2 border-t border-slate-300 pt-2">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Open here — your anchor</div>
                  <div className="mt-0.5 font-mono text-2xl font-bold tabular-nums text-emerald-700">{usd(Math.round(deal.maxCash * ANCHOR_PCT))}</div>
                  <div className="mt-0.5 text-[10px] font-bold uppercase tracking-widest text-slate-500">Max allowable cash offer</div>
                  <div className="font-mono text-lg font-bold tabular-nums text-slate-900">{usd(deal.maxCash)}</div>
                  <div className="mt-0.5 text-[10.5px] leading-snug text-slate-500">
                    Say the anchor, not the ceiling. That leaves {usd(deal.maxCash - Math.round(deal.maxCash * ANCHOR_PCT))} of room to move toward them and still keep your {usd(num(deal.wholesaleFee))} fee. Never go above the ceiling.
                    {strat.gap != null && strat.gap > 0 ? <> They want <b className="text-slate-700">{usd(strat.gap)}</b> more than this.</> : strat.gap != null ? <> Their number is already under it.</> : null}
                  </div>
                </div>
              )}
            </div>

            {/* 1. PICK — compact, the whole board at a glance */}
            <div className="mt-2 space-y-1.5">
              {strat.ranked.map((o, i) => {
                const on = showList.some((x) => x.id === o.id);
                return (
                  <button key={o.id} type="button" onClick={() => toggle(o.id)}
                    className={`flex w-full items-center justify-between gap-2 rounded-lg border px-3 py-2 text-left transition ${
                      on ? "border-emerald-600 bg-emerald-50 ring-1 ring-emerald-600" : "border-slate-200 bg-white hover:border-slate-300"
                    }`}>
                    <span className="flex items-center gap-1.5">
                      <span className={`text-[12px] font-bold ${on ? "text-emerald-900" : "text-slate-700"}`}>{o.label}</span>
                      {i === 0 && o.sc > 0 && <span className="rounded bg-slate-200 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-slate-600">Best fit</span>}
                      {o.warn.length > 0 && <AlertTriangle className="h-3 w-3 text-amber-500" />}
                    </span>
                    <span className={`font-mono text-[11px] font-bold ${on ? "text-emerald-700" : "text-slate-400"}`}>{o.sc}</span>
                  </button>
                );
              })}
            </div>

            {/* 2. SAY — the only prose on screen by default */}
            {active && (
              <div className="mt-3 rounded-xl border-2 border-emerald-500 bg-emerald-50/50 p-3">
                <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-700">
                  What to say — {showList.map((x) => x.label).join(" then ")}
                </div>
                {multi && (
                  <div className="mt-1 text-[11px] leading-snug text-slate-600">
                    Two options, in this order. Say the {showList[0].label.toLowerCase()} number first and stop talking. Let them react. Then offer the second as what you can do <i>if</i> the first does not work for them. Never present them as equal choices, and never lead with the second one.
                  </div>
                )}
                {overAsk && (
                  <Line>“It sounds like you like everything about what we discussed other than the price… probably 9 out of 10 homeowners we talk with feel the same way. So what we did was develop a way to offer sellers more money and still have it make sense for us, our Partnership Program. If I could get you closer to your number, would you like to go over the details, or should we just part ways now?”</Line>
                )}
                {showList.map((o, k) => (
                  <div key={o.id} className={k > 0 ? "mt-3 border-t border-emerald-200 pt-2.5" : "mt-1"}>
                    {multi && <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-700">{k === 0 ? "First" : "Then"} — {o.label}</div>}
                    {overAsk && secondFor(o.id) && <Line>{secondFor(o.id)}</Line>}
                    {o.pitch.map((p, j) => <Line key={j}>{p}</Line>)}
                    <button type="button" onClick={() => onTab(o.tab)}
                      className="mt-2 w-full rounded-lg bg-emerald-600 px-3 py-2 text-[12px] font-bold text-white hover:bg-emerald-700">
                      Run the {o.label} numbers
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* 3. EVERYTHING ELSE — folded until asked for */}
            {showList.map((o) => (o.rs.length > 0 || o.warn.length > 0 || o.miss.length > 0) && (
              <details key={o.id} className="mt-2 rounded-lg border border-slate-200 bg-white px-3 py-2">
                <summary className="cursor-pointer text-[11px] font-semibold text-slate-700">Why {o.label} scores {o.sc}</summary>
                {o.rs.map((r, k) => <div key={k} className="mt-1 flex items-start gap-1.5 text-[11px] leading-snug text-slate-600"><CheckCircle2 className="mt-px h-3 w-3 shrink-0 text-emerald-500" />{r}</div>)}
                {o.warn.map((w, k) => <div key={k} className="mt-1 flex items-start gap-1.5 text-[11px] leading-snug text-amber-700"><AlertTriangle className="mt-px h-3 w-3 shrink-0 text-amber-500" />{w}</div>)}
                {o.miss.map((m, k) => <div key={k} className="mt-1.5 text-[11px] leading-snug text-slate-600"><span className="font-semibold">Still to ask: {m.q}</span> <span className="text-slate-400">{m.why}</span></div>)}
              </details>
            ))}

            {overAsk && (
              <details className="mt-1.5 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2">
                <summary className="cursor-pointer text-[11px] font-semibold text-amber-800">Careful with the word partnership</summary>
                <div className="mt-1.5 text-[11px] leading-snug text-amber-800">
                  It is the name of our program, not a description of what the seller becomes. No ownership stake, no share of the profit, no say in what we do with the house. If they ask “so am I a partner in this?”, say: “It is just what we call the program. You are selling us the house, and the agreement spells out exactly what you get and when.”
                </div>
              </details>
            )}

            {(cs.loan === "yes" || cs.terms === "yes" || cs.terms === "maybe") && (
              <details className="mt-1.5 rounded-lg border border-slate-200 bg-white px-3 py-2">
                <summary className="cursor-pointer text-[11px] font-semibold text-slate-700">Negotiating terms — the real number, what to trade, pushback</summary>

                <div className="mt-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">Find the real number</div>
                <Line>“After the loan is paid off and everything is settled, what do you need in your pocket to move on?”</Line>
                <Line>“What are you doing with the money?” Their answer is the real minimum.</Line>
                <Line>“If I covered the back payments and all the closing costs, how close does that get you?”</Line>

                <div className="mt-2.5 text-[10px] font-bold uppercase tracking-widest text-slate-400">What you can trade</div>
                <div className="mt-1 space-y-1 text-[11px] leading-snug text-slate-600">
                  <div><b className="text-slate-800">Price for terms.</b> Closer to their number in exchange for a lower rate, longer term, or later balloon.</div>
                  <div><b className="text-slate-800">Time for cash.</b> If they will wait on part of it, the cash at closing drops.</div>
                  <div><b className="text-slate-800">Certainty for flexibility.</b> A firm close date is worth real money to someone under pressure.</div>
                  <div><b className="text-slate-800">Never trade the rate.</b> On a Sub-To the existing low rate is the asset.</div>
                </div>

                <div className="mt-2.5 text-[10px] font-bold uppercase tracking-widest text-slate-400">Their pushback</div>
                <details className="mt-1 rounded border border-slate-200 px-2.5 py-1.5"><summary className="cursor-pointer text-[11px] font-semibold text-slate-700">“Why leave the loan in my name?”</summary><div className="mt-1 text-[11px] leading-snug text-slate-600">“What your lender cares about is that the payment gets made on time. We take that over and it gets paid. What changes for you is that you are no longer responsible for the house, the repairs, the tenants, or that payment leaving your account.”</div></details>
                <details className="mt-1 rounded border border-slate-200 px-2.5 py-1.5"><summary className="cursor-pointer text-[11px] font-semibold text-slate-700">“What if you stop paying?”</summary><div className="mt-1 text-[11px] leading-snug text-slate-600">“That is exactly why we put protections in writing. This closes at a title company, the payments are documented, and you get proof of every one.” Do not improvise promises. Anything beyond the agreement goes to the head of acquisitions.</div></details>
                <details className="mt-1 rounded border border-slate-200 px-2.5 py-1.5"><summary className="cursor-pointer text-[11px] font-semibold text-slate-700">“Can the bank call the loan?”</summary><div className="mt-1 text-[11px] leading-snug text-slate-600">Answer honestly: most mortgages have a due on sale clause, so yes, a lender has that right. As long as the payment is current it is uncommon, and if it happened we would refinance or sell to pay it off. Never tell a seller it cannot happen.</div></details>
                <details className="mt-1 rounded border border-slate-200 px-2.5 py-1.5"><summary className="cursor-pointer text-[11px] font-semibold text-slate-700">“So do I still own part of it?”</summary><div className="mt-1 text-[11px] leading-snug text-slate-600">“No. Partnership is just what we call the program. You are selling us the house, and the agreement says exactly what you get and when.” Do not soften this one.</div></details>

                <div className="mt-2.5 rounded border border-amber-300 bg-amber-50 px-2.5 py-1.5 text-[11px] leading-snug text-amber-800">
                  <b>Never on a call:</b> guarantees of any kind, promising the loan will not be called, legal or tax advice, terms outside an approved contract, or letting “partnership” imply ownership.
                </div>
              </details>
            )}
          </div>);
        })()}

        {stage === 8 && (<div>
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Close it out</div>
          {isLowRate(cs.rate) && (
            <div className="mb-3 rounded-xl border-2 border-emerald-500 bg-emerald-50 p-3">
              <div className="flex items-start gap-2">
                <Zap className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                <div>
                  <div className="text-[12px] font-bold text-emerald-900">{rateNum(cs.rate)}% loan on this one.</div>
                  <div className="mt-0.5 text-[11px] leading-snug text-emerald-800">
                    If you did not get it signed, or the seller turned down creative financing, this goes to the head of acquisitions today. Send the report and say what they pushed back on. It does not get marked dead on this call.
                  </div>
                </div>
              </div>
            </div>
          )}
          <Line>Commitment close: “If we can make the numbers work, are you ready to move forward today?”</Line>
          <div className="mt-2 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11px] leading-snug text-amber-800">
            <b>Never send agreements without walking through them live on the phone.</b> Verify seller info → send the agreement → review it line-by-line together → confirm signatures while you're still on the call.
          </div>
          <Line>Stress test (after signing): “When someone asks you why you decided to sell the house to us, what are you going to tell them?” — you want THEIR reason, not your pitch back. Coach if needed: “Would you say it helps you get closer to ___? It saves you time, energy, and money?”</Line>
          <Line>Next steps: “Within the next few days we'll likely need access for photos, walkthroughs, or contractors.”</Line>
          <Line>End in rapport: “It was great getting to know you.” · “Congratulations on getting this process started.” · “So what's the next chapter for you after this?”</Line>
          <Hint>Compliance (SOP): no guarantees, no legal advice, approved contracts only. Then: submit to the TC same day, title open within 1 business day, notify Dispositions.</Hint>
          <button type="button" onClick={downloadReport}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-3.5 text-sm font-bold text-white shadow-sm hover:bg-emerald-700">
            <FileDown className="h-4 w-4" /> Download call report
          </button>
          <div className="mt-1.5 text-center text-[10.5px] leading-snug text-slate-400">Everything captured on this call, plus a copy-and-paste summary for the CRM.</div>
        </div>)}
      </div>

      {/* footer nav */}
      <div className="flex items-center justify-between border-t border-slate-100 p-2.5">
        <button type="button" disabled={!canPrev} onClick={() => setStage((v) => Math.max(0, v - 1))}
          className="flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-[11px] font-semibold text-slate-600 disabled:opacity-40 hover:bg-slate-50"><ChevronLeft className="h-3.5 w-3.5" /> Back</button>
        <div className="text-[10px] font-semibold uppercase tracking-widest text-slate-400">{CALL_STAGES[stage]}</div>
        <button type="button" disabled={!canNext} onClick={() => setStage((v) => Math.min(CALL_STAGES.length - 1, v + 1))}
          className="flex items-center gap-1 rounded-md bg-slate-900 px-2.5 py-1.5 text-[11px] font-semibold text-white disabled:opacity-40 hover:bg-slate-700">Next <ChevronRight className="h-3.5 w-3.5" /></button>
      </div>
    </div>
  );
};

export default function App() {
  // property + ARV
  const [address, setAddress] = useState("");
  const [sqft, setSqft] = useState("");
  const [manualSold, setManualSold] = useState([]);  // hand-entered recorded sales (merged into the sold panel; cleared on a fresh successful pull)
  const [soldAdd, setSoldAdd] = useState(null);      // same, for the sold section
  const [arvOverride, setArvOverride] = useState("");
  const [marginalPsf, setMarginalPsf] = useState("");   // size-adjust rate ($ per sq ft of size difference); blank = auto (half the group's typical $/sf)
  // --- rental ---
  const [rentEst, setRentEst] = useState(null);      // RentCast rent estimate (auto)
  const [rentSaved, setRentSaved] = useState(null);  // rent remembered from the last time this address was worked
  const [pullAt, setPullAt] = useState(null);        // when this address was last actually pulled from RentCast
  const pullAddrRef = useRef("");                   // which address the data on screen belongs to
  const [rentLow, setRentLow] = useState(null);
  const [rentHigh, setRentHigh] = useState(null);
  const [rentOverride, setRentOverride] = useState(""); // manual rent (wins when set)
  const [rentLoading, setRentLoading] = useState(false);
  const [rentMsg, setRentMsg] = useState(null);
  const [rentFetchedFor, setRentFetchedFor] = useState(""); // address we last pulled rent for (lazy-load guard)
  const [tab, setTab] = useState("cash");
  const [callOpen, setCallOpen] = useState(false); // Offer Call drawer (acquisitions script walkthrough)
  const [callState, setCallState] = useState(INITIAL_CALL);
  const [callTouched, setCallTouched] = useState(false); // true only once a rep edits the call or a saved one is restored
  const [callSavedAt, setCallSavedAt] = useState(null);   // when this call was last written to browser storage
  const [callLoadedAt, setCallLoadedAt] = useState(null); // set when a previously saved call was restored for this address
  const callKeyRef = useRef("");                          // which address key the open call is attached to
  const [syncId, setSyncId] = useState(readSyncId);       // { name, code } — this browser's rep identity
  const [syncState, setSyncState] = useState({ status: "idle", by: null, at: null, msg: "" });
  const syncTimer = useRef(null);                         // debounce so we do not POST on every keystroke
  const [ownerNames, setOwnerNames] = useState(null); // owner of record from the subject pull — prefills the seller name and shows under the field
  const [subjectInfo, setSubjectInfo] = useState(null);
  // Subject property deep-dive (on-demand RentCast record lookup — 1 credit, once per address)
  const [subjDetail, setSubjDetail] = useState(null);
  const [subjDetailOpen, setSubjDetailOpen] = useState(false);
  const [subjDetailLoading, setSubjDetailLoading] = useState(false);
  const [subjTab, setSubjTab] = useState("Property");
  async function openSubjDetail() {
    if (subjDetailOpen) { setSubjDetailOpen(false); return; }
    setSubjDetailOpen(true);
    if (subjDetail || subjDetailLoading) return;
    const a = address.trim();
    if (!a) return;
    setSubjDetailLoading(true);
    try {
      const r = await fetch(`/api/subject?address=${encodeURIComponent(a)}`);
      const data = await r.json();
      if (r.ok && data.sections) { setSubjDetail(data); setSubjTab(Object.keys(data.sections)[0] || "Property"); }
      else setSubjDetail({ sections: {}, error: data.error || "No record found." });
    } catch { setSubjDetail({ sections: {}, error: "Lookup failed." }); }
    finally { setSubjDetailLoading(false); }
  }
  // Record corrections — beds/baths the county record missed (or overstated). Flat per-unit ARV adjustment.
  const [adjBeds, setAdjBeds] = useState(0);
  const [adjBaths, setAdjBaths] = useState(0);           // steps in halves: 0.5 = a half bath
  const [bedAdjAmt, setBedAdjAmt] = useState("15000");   // $ per bedroom — count-adjustment (same sqft), not an addition. Set back to 15k per B, Sep 2026
  const [bathAdjAmt, setBathAdjAmt] = useState("10000"); // $ per FULL bath; a half bath = 0.5 × this
  const [compLoading, setCompLoading] = useState(false);
  const [compMsg, setCompMsg] = useState(null); // {type:'ok'|'err', text}
  const [soldData, setSoldData] = useState(null);      // actual recorded sold comps (RentCast /properties)
  const [soldLoading, setSoldLoading] = useState(false);
  const [soldMsg, setSoldMsg] = useState(null);
  const [soldIncluded, setSoldIncluded] = useState({}); // manual "include" overrides for flagged sold comps, keyed by comp index (reset on each pull)
  const [arvSource, setArvSource] = useState("");   // which method produced the typed ARV
  const [compsOpen, setCompsOpen] = useState(false); // Deal Desk comp engine starts collapsed
  const [mlsOnly, setMlsOnly] = useState(true); // show only MLS-verified sales (applies only when the MLS cross-check ran)
  const [compDetail, setCompDetail] = useState(null); // { i } — which sold comp's detail pop-up is open (opened by clicking a card photo)

  async function autoComp() {
    const a = address.trim();
    if (!a) { setCompMsg({ type: "err", text: "Type the subject address first." }); return; }
    setCompLoading(true); setCompMsg(null);
    try {
      // 1) Subject record first (exact-address lookup, 1 credit): fills the sq ft, beds/baths and
      //    coordinates, and pre-loads the Subject property details panel off the same response.
      let hints = { sqft: num(sqft), propertyType: subjectInfo?.propertyType, lat: subjectInfo?.lat, lng: subjectInfo?.lng };
      try {
        const sr = await fetch(`/api/subject?address=${encodeURIComponent(a)}`);
        const sd = await sr.json().catch(() => null);
        if (sr.ok && sd) {
          if (sd.sections) { setSubjDetail(sd); setSubjDetailOpen(true); } // auto-show the panel — no extra click
          const raw = sd.raw || {};
          if (raw.sqft) setSqft(String(raw.sqft));
          setOwnerNames(raw.ownerNames || null);
          // The record often knows whether there is an HOA. Answer it for them rather than making
          // them ask, but never overwrite an answer a rep already gave.
          if (typeof raw.hoa === "boolean") setCallState((prev) => (prev.hoa ? prev : { ...prev, hoa: raw.hoa ? "yes" : "no" }));
          setCallState((prev) => (prev.sellerName.trim() ? prev : { ...prev, sellerName: ownerFullName(raw.ownerNames) })); // suggestion only — never overwrites what the rep typed
          setSubjectInfo({ propertyType: raw.propertyType ?? null, architecture: raw.architecture ?? null, ownerType: raw.ownerType ?? null, heldFor: raw.heldFor ?? null, hoa: raw.hoa ?? null, beds: raw.beds ?? null, baths: raw.baths ?? null, yearBuilt: raw.yearBuilt ?? null, lat: raw.lat ?? null, lng: raw.lng ?? null, sqft: raw.sqft ?? null });
          hints = { sqft: raw.sqft || num(sqft), propertyType: raw.propertyType, lat: raw.lat, lng: raw.lng };
        }
      } catch { /* subject lookup is best-effort — the sold comps still run without it */ }
      // 2) Recorded sold comps + MLS cross-check (the server makes both RentCast calls in one go)
      await pullSold(hints);
      setCompsOpen(true);
      if (!arvSource && num(arvOverride) <= 0) setArvSource("deal-desk");
      // 3) Market rent, so the payment-vs-rent test and the BRRRR panel are live without a second
      //    click. Best-effort on purpose: a rent miss must never take down a good comp pull.
      try { await fetchRent(a); } catch { /* keep going — rent can be pulled or typed later */ }
      setPullAt(new Date().toISOString());
      pullAddrRef.current = a.trim().toLowerCase();
      setCompMsg({ type: "ok", text: "Pulled the subject record, recorded sold comps, and market rent. The ARV is the median of the best solid sales — include/exclude comps below and it recalculates." });
    } catch {
      setCompMsg({ type: "err", text: "Couldn't reach the comp service. Is the proxy deployed?" });
    } finally {
      setCompLoading(false);
    }
  }

  async function pullSold(fresh) {
    const a = address.trim();
    if (!a) { setSoldMsg({ type: "err", text: "Type the subject address first." }); return; }
    setSoldLoading(true); setSoldMsg(null);
    try {
      const params = new URLSearchParams({ address: a });
      const sf = Number(fresh?.sqft) > 0 ? Number(fresh.sqft) : num(sqft);
      if (sf > 0) params.set("subjectSqft", String(sf));
      const ptype = fresh?.propertyType || subjectInfo?.propertyType;
      if (ptype) params.set("propertyType", ptype);
      const sLat = Number(fresh?.lat ?? subjectInfo?.lat), sLng = Number(fresh?.lng ?? subjectInfo?.lng);
      if (Number.isFinite(sLat) && Number.isFinite(sLng)) { params.set("subjectLat", String(sLat)); params.set("subjectLng", String(sLng)); }
      const r = await fetch(`${SOLD_API}?${params.toString()}`);
      const data = await r.json();
      if (!r.ok) { setSoldMsg({ type: "err", text: data.error || `Lookup failed (${r.status}).` }); setSoldData(null); setSoldIncluded({}); return; }
      setSoldData(data);
      setSoldIncluded({});
      setManualSold([]);   // fresh property, fresh slate (a failed pull keeps your hand-entered comps)
      const n = data.count || 0;
      setSoldMsg(n > 0
        ? { type: "ok", text: `${n} recorded sale${n === 1 ? "" : "s"} found.` }
        : { type: "err", text: "No recorded sales matched — widen the radius/date range, or the county may be light on recorded prices. You can enter your ARV directly in the picker below." });
    } catch (e) {
      setSoldMsg({ type: "err", text: "Couldn't reach the sold-comps service. Is the proxy deployed?" });
    } finally {
      setSoldLoading(false);
    }
  }

  // Pull the rent estimate. Runs as part of Auto-comp, or from the Offer Call drawer. One RentCast credit.
  async function fetchRent(addr) {
    const a = (addr || "").trim();
    if (!a) { setRentMsg({ type: "err", text: "Enter an address up top first, then reopen this tab." }); return; }
    setRentLoading(true);
    setRentMsg(null);
    try {
      const res = await fetch(`${RENT_API}?address=${encodeURIComponent(a)}`);
      const data = await res.json();
      if (!res.ok) { setRentMsg({ type: "err", text: data.error || "Rent lookup failed." }); return; }
      setRentEst(data.rent || null);
      setRentLow(data.rentLow || null);
      setRentHigh(data.rentHigh || null);
      setRentFetchedFor(a);
      setRentMsg(data.rent
        ? { type: "ok", text: `RentCast estimate ${usd(data.rent)}/mo${data.rentLow && data.rentHigh ? ` (range ${usd(data.rentLow)}–${usd(data.rentHigh)})` : ""}. Override below if you have a better number.` }
        : { type: "err", text: "No rent estimate available — enter rent manually below." });
    } catch (e) {
      setRentMsg({ type: "err", text: "Couldn't reach the rent service. Is the proxy deployed?" });
    } finally {
      setRentLoading(false);
    }
  }

  // Rent comes from Auto-comp, the drawer's Get market rent button, or a remembered prior pull.

  // rehab + MAO %
  const [rehabLevel, setRehabLevel] = useState("");   // no default: repairs stay unknown until a rep picks a level or types a number
  const [customPsf, setCustomPsf] = useState("");
  const [repairOverride, setRepairOverride] = useState("");
  const [underPct, setUnderPct] = useState(75); // under $200k band
  const [overPct, setOverPct] = useState(80);    // over $200k band

  // cash/mao
  const [wholesaleFee, setWholesaleFee] = useState("20000");   // YLHB standard assignment fee (raised from 15k, Sep 2026)


  const [sellingPct, setSellingPct] = useState("10");
  const [holding, setHolding] = useState("7500");
  const [desiredProfit, setDesiredProfit] = useState("25000");
  const [askingPrice, setAskingPrice] = useState("");

  // sub-to
  const [stBal, setStBal] = useState("");
  const [stPiti, setStPiti] = useState("");
  const [stArrears, setStArrears] = useState("");
  const [stCashSeller, setStCashSeller] = useState("");
  const [stClosing, setStClosing] = useState("3500");
  const [stRent, setStRent] = useState("");
  const [stReservePct, setStReservePct] = useState("12");

  // hybrid
  const [hyPrice, setHyPrice] = useState("");
  const [hyDown, setHyDown] = useState("");
  const [hyBal, setHyBal] = useState("");
  const [hyPiti, setHyPiti] = useState("");
  const [hyRate, setHyRate] = useState("0");
  const [hyTerm, setHyTerm] = useState("30");
  const [hyClosing, setHyClosing] = useState("3500");
  const [hyRent, setHyRent] = useState("");
  const [hyReservePct, setHyReservePct] = useState("12");

  // seller finance
  const [sfPrice, setSfPrice] = useState("");
  const [sfDown, setSfDown] = useState("");
  const [sfRate, setSfRate] = useState("0");
  const [sfAmort, setSfAmort] = useState("30");
  const [sfBalloon, setSfBalloon] = useState("0");
  const [sfTaxIns, setSfTaxIns] = useState("");
  const [sfRent, setSfRent] = useState("");
  const [sfReservePct, setSfReservePct] = useState("12");

  // novation
  const [novAsIs, setNovAsIs] = useState("");
  const [novProfit, setNovProfit] = useState("30000");
  const [novListFactor, setNovListFactor] = useState("95");
  const [novCostFactor, setNovCostFactor] = useState("8");

  // ---- Offer Call -> strategy tabs -------------------------------------------------------
  // What the rep captures on the phone should already be in whichever tab they open next.
  // Rule: fill a field only when it is still empty. We never overwrite something a person typed,
  // so a number changed on a tab stays changed even if the call is edited afterward.
  const fillIfEmpty = (cur, setter, val) => { if (!cur && val) setter(String(val)); };
  useEffect(() => {
    const ask = num(callState.ask);
    const bal = num(callState.balance);
    // The payment a rep can actually inherit: what the seller pays, plus escrow and dues when
    // those sit outside it. Same build-up as the payment-vs-rent test.
    const piti = num(callState.payment) > 0
      ? num(callState.payment)
        + (callState.escrowed === "no" ? num(callState.tiMonthly) : 0)
        + (callState.hoa === "yes" ? num(callState.hoaAmt) : 0)
      : 0;
    const equity = ask > 0 && bal > 0 ? Math.max(0, ask - bal) : 0;

    if (ask > 0) {
      fillIfEmpty(askingPrice, setAskingPrice, ask);   // Cash / MAO
      fillIfEmpty(hyPrice, setHyPrice, ask);           // Hybrid
      fillIfEmpty(sfPrice, setSfPrice, ask);           // Seller Finance
    }
    if (bal > 0) {
      fillIfEmpty(stBal, setStBal, bal);               // Sub-To
      fillIfEmpty(hyBal, setHyBal, bal);               // Hybrid
    }
    if (piti > 0) {
      fillIfEmpty(stPiti, setStPiti, Math.round(piti));
      fillIfEmpty(hyPiti, setHyPiti, Math.round(piti));
    }
    // On a Sub-To the seller's equity above the balance is what they walk with in cash.
    if (equity > 0) fillIfEmpty(stCashSeller, setStCashSeller, equity);
  }, [callState.ask, callState.balance, callState.payment, callState.escrowed, callState.tiMonthly, callState.hoa, callState.hoaAmt]);



  // ---- ARV ----
  // Record-correction dollars: rides on TOP of whichever ARV is driving (sold-comp median or manual override),
  // because a bedroom the county missed is missing from every one of those sources equally.
  const subjAdjust = Math.round(adjBeds * num(bedAdjAmt) + adjBaths * num(bathAdjAmt));

  // Structural flags + the shared price-outlier rule for the sold panel: flagged comps sit out of the
  // rule; flagged comps are auto-EXCLUDED from the average (averages bruise easier than medians), clean
  // comps auto-included, and every valid card carries an include/exclude override.

  // Sold-comp summary — "best 4" selection:
  //  1) structural junk filter (compFlags: beds/baths/size/age/distance)
  //  2) price sanity — $/sf more than 25% off the structurally-clean group median gets a "price outlier"
  //     flag (catches distressed/wholesale sales that are structurally identical; skipped when <3 clean comps
  //     because the reference median would itself be junk)
  //  3) the median runs on the TOP {SOLID_TARGET} solid comps (list arrives closest/newest first)
  //     plus anything manually included; solid comps beyond the top N sit on the bench
  //  4) fewer than MIN_SOLID comps in the median → thin flag drives the warning banner
  const soldSummary = useMemo(() => {
    const src = [...((soldData && soldData.comps) || []), ...manualSold];
    if (!src.length) return null;
    const mlsChecked = !!(soldData && soldData.mlsChecked);
    const pool0 = mlsChecked && mlsOnly ? src.filter((c) => c.manualEntry || c.mls) : src;
    const sf = num(sqft);
    const base = pool0.map((c, i) => ({ ...c, i, flags: [...compFlags(c, subjectInfo, sf)] }));
    // Size adjustment (appraiser-style): each sale's price, moved to the subject's size at the marginal rate.
    const marginalUsed = num(marginalPsf) > 0 ? Math.round(num(marginalPsf)) : Math.round(cleanMedian(base.filter((c) => c.flags.length === 0).map((c) => c.ppsf || 0)) / 2);
    base.forEach((c) => {
      const canAdj = sf > 0 && c.sqft > 0 && c.salePrice > 0 && marginalUsed > 0;
      c.adjPrice = canAdj ? Math.max(0, c.salePrice + (sf - c.sqft) * marginalUsed) : c.salePrice;
      c.appsf = sf > 0 && c.adjPrice > 0 ? c.adjPrice / sf : (c.ppsf || 0);
    });
    flagPriceOutliers(base);
    const solidIdx = base.filter((c) => c.flags.length === 0 && soldIncluded[c.i] !== false).slice(0, SOLID_TARGET).map((c) => c.i);
    const flagged = base.map((c) => {
      const o = soldIncluded[c.i];                       // true = force in, false = force out, undefined = auto
      const auto = solidIdx.includes(c.i);
      const included = o === true || (o === undefined && auto);
      return { ...c, manual: o !== undefined, included, benched: c.flags.length === 0 && o === undefined && !auto };
    });
    const pool = flagged.filter((c) => c.included);
    let medianPpsf = null, arv = null;
    if (pool.length && sf > 0) {
      const prices = pool.map((c) => c.adjPrice).filter((x) => x > 0).sort((a, b) => a - b);
      if (prices.length) {
        const m = Math.floor(prices.length / 2);
        const medPrice = prices.length % 2 ? prices[m] : (prices[m - 1] + prices[m]) / 2;
        arv = Math.round(medPrice);                       // median of size-adjusted sale prices = the sold-comp ARV
        medianPpsf = Math.round(medPrice / sf);
      }
    } else if (pool.length) {
      const pp = pool.map((c) => c.ppsf).filter((x) => x > 0).sort((a, b) => a - b);
      if (pp.length) {
        const m = Math.floor(pp.length / 2);
        medianPpsf = Math.round(pp.length % 2 ? pp[m] : (pp[m - 1] + pp[m]) / 2);
        arv = (soldData && soldData.soldArv) || null;     // no subject sq ft: fall back to the server's number
      }
    }
    return { flagged, usedCount: pool.length, total: flagged.length, medianPpsf, arv, thin: pool.length < MIN_SOLID, marginalUsed, mlsChecked, mlsCount: src.filter((c) => c.mls).length, srcTotal: src.length };
  }, [soldData, subjectInfo, sqft, soldIncluded, marginalPsf, manualSold, mlsOnly]);

  // Label the ARV stat with where the number actually came from — recorded sales or a manual override.
  // Rounding mirrors the picker exactly so this label always agrees with the picker's ✓ state.
  // The deal-driving ARV: manual override wins; otherwise the sold-comp median. Record corrections ride on top.
  const arv = useMemo(() => {
    // A typed ARV is taken as final. The bed/bath correction exists to patch a comp-derived number
    // that was built on the county's bed/bath count, so applying it to a number a human comped
    // themselves would count the same rooms twice and inflate the offer.
    if (num(arvOverride) > 0) return Math.max(0, num(arvOverride));
    const soldVal = soldSummary && soldSummary.arv > 0 ? soldSummary.arv : 0;
    if (soldVal <= 0) return 0;
    return Math.max(0, soldVal + subjAdjust);
  }, [soldSummary, arvOverride, subjAdjust]);

  const arvStat = useMemo(() => {
    const o = num(arvOverride);
    const soldVal = soldSummary && soldSummary.arv > 0 ? Math.round(soldSummary.arv) : null;
    let label = "ARV", sub = "sold-comp ARV · actual recorded sales";
    const srcLbl = ARV_SOURCE_LABEL[arvSource] || "";
    if (o > 0 && (!soldVal || o !== soldVal)) { label = "ARV"; sub = srcLbl ? `from ${srcLbl.toLowerCase()}` : "typed in — tag the source"; }
    if (subjAdjust !== 0) sub += ` · includes ${subjAdjust > 0 ? "+" : "−"}${usd(Math.abs(subjAdjust))} bed/bath correction`;
    return { label, sub };
  }, [arvOverride, soldSummary, subjAdjust, arvSource]);

  // ---- repairs ----
  const repairPsf = rehabLevel === "cosmetic" ? 15 : rehabLevel === "moderate" ? 30 : rehabLevel === "gut" ? 50 : num(customPsf);
  const repairs = useMemo(() => {
    if (num(repairOverride) > 0) return num(repairOverride);
    return repairPsf * num(sqft);
  }, [repairPsf, sqft, repairOverride]);
  // Unknown is not zero. Without a repair number there is no honest MAO, and the MAO is the figure
  // a rep says out loud to a seller, so it stays blank rather than assuming the house needs nothing.
  const repairsKnown = num(repairOverride) > 0 || (rehabLevel !== "" && repairPsf > 0 && num(sqft) > 0);

  // ---- rental ----
  // Typed rent wins, then a fresh pull, then whatever this address returned last time it was worked.
  // The remembered value keeps a re-opened deal complete without spending another RentCast credit.
  const effRent = num(rentOverride) > 0 ? num(rentOverride) : (rentEst || rentSaved || 0);
  const onePctMax = effRent > 0 ? effRent * 100 : 0; // 1% rule: rent >= 1% of price → max price = rent × 100

  // The RentCast data worth keeping: subject record, sold comps, sq ft, owner. Saved with the call
  // so a second visit to this address costs nothing. Skipped entirely if nothing has been pulled.
  const pullPayload = () => {
    if (!soldData && !subjDetail) return null;
    return {
      subjDetail, subjectInfo, soldData,
      sqft: num(sqft) > 0 ? num(sqft) : "",
      ownerNames,
      at: pullAt || new Date().toISOString(),
    };
  };

  // The data on screen belongs to one address. The moment the box says something else, drop it all,
  // otherwise a rep sees the previous property's photo, sq ft, details and comps under a new address.
  useEffect(() => {
    const now = String(address || "").trim().toLowerCase();
    if (!pullAddrRef.current || pullAddrRef.current === now) return;
    pullAddrRef.current = "";
    setPullAt(null);
    setSubjDetail(null); setSubjDetailOpen(false);
    setSubjectInfo(null); setOwnerNames(null);
    setSoldData(null); setSoldIncluded({}); setManualSold([]); setCompsOpen(false);
    setRentEst(null); setRentSaved(null);
    setSqft(""); setArvSource("");
    setCompMsg(null); setSoldMsg(null);
    setArvOverride(""); setRepairOverride("");
    setAdjBeds(0); setAdjBaths(0);
    // The call is about a seller and a house. Carrying it to a different address would put the
    // wrong seller's name, notes and numbers on the new property, and autosave would then write
    // them into that property's record for the whole team. A saved call for the new address is
    // restored immediately after this by the effect below.
    setCallState(INITIAL_CALL); setCallTouched(false);
    setCallLoadedAt(null); setCallSavedAt(null);
  }, [address]);

  // Restore a saved call when the rep lands on an address that already has one. The effect above
  // has already cleared anything belonging to the previous property, so nothing leaks across.
  useEffect(() => {
    if (!addressSavable(address)) return;
    const k = callStoreKey(address);
    if (k === callKeyRef.current) return;
    callKeyRef.current = k;
    setRentSaved(null);   // never carry one property's rent onto another
    setCallTouched(false);
    setPullAt(null);
    const local = readSavedCall(address);
    const applyRecord = (rec, from) => {
      setCallState({ ...INITIAL_CALL, ...rec.call });
      // Only a record with real call content counts as a call in progress. A pull-only record
      // (someone looked the address up and never dialed) leaves the pill reading "Offer Call".
      setCallTouched(Object.keys(INITIAL_CALL).some((k) => (rec.call || {})[k] && rec.call[k] !== INITIAL_CALL[k]));
      if (rec.repairOverride != null) setRepairOverride(rec.repairOverride);
      if (rec.wholesaleFee) setWholesaleFee(rec.wholesaleFee);
      if (num(rec.rent) > 0) setRentSaved(num(rec.rent));
      // Rehydrate a prior RentCast pull instead of paying for it again. Shown with its date so
      // nobody mistakes month-old comps for fresh ones, and Re-pull is always one click away.
      if (rec.pull && rec.pull.at) {
        // Open it on a restored pull too, not just a live one, so a cached address looks the same.
        if (rec.pull.subjDetail) { setSubjDetail(rec.pull.subjDetail); setSubjDetailOpen(true); }
        if (rec.pull.subjectInfo) setSubjectInfo(rec.pull.subjectInfo);
        if (rec.pull.soldData) { setSoldData(rec.pull.soldData); setCompsOpen(true); }
        if (rec.pull.sqft) setSqft(String(rec.pull.sqft));
        if (rec.pull.ownerNames) setOwnerNames(rec.pull.ownerNames);
        setPullAt(rec.pull.at);
        pullAddrRef.current = String(address || "").trim().toLowerCase();
      } else setPullAt(null);
      setCallLoadedAt(rec.at || null);
      setCallSavedAt(rec.at || null);
      if (from === "team") setSyncState((p) => ({ ...p, status: "synced", by: rec.by || null, at: rec.at || null, msg: "" }));
    };
    if (local && local.call) applyRecord(local, "local"); else { setCallLoadedAt(null); setCallSavedAt(null); }

    // Then ask the team store. Whichever copy is newer wins, so a teammate's later work
    // is never overwritten by a stale local copy sitting in this browser.
    const id = syncId;
    if (!id.code) return;
    let live = true;
    fetch(`/api/calls?address=${encodeURIComponent(address)}`, { headers: { "x-ylhb-key": id.code } })
      .then((r) => (r.status === 401 ? Promise.reject(new Error("bad-passcode")) : r.json()))
      .then((d) => {
        if (!live || !d) return;
        if (d.disabled) { setSyncState({ status: "off", by: null, at: null, msg: "" }); return; }
        if (d.found && d.record && d.record.call) {
          const remoteNewer = !local || !local.at || String(d.record.at || "") > String(local.at || "");
          if (remoteNewer) applyRecord(d.record, "team");
          else setSyncState((p) => ({ ...p, status: "synced", by: d.record.by || null, at: d.record.at || null, msg: "" }));
        } else {
          setSyncState({ status: "synced", by: null, at: null, msg: "" });
        }
      })
      .catch((e) => { if (live) setSyncState({ status: e.message === "bad-passcode" ? "denied" : "error", by: null, at: null, msg: "" }); });
    return () => { live = false; };
  }, [address, syncId]);

  // Autosave. Skips empty calls so simply opening the drawer never creates a record.
  useEffect(() => {
    if (!addressSavable(address)) return;
    const untouched = Object.keys(INITIAL_CALL).every((k) => callState[k] === INITIAL_CALL[k]);
    // Worth saving if a rep has worked the call OR if there is a RentCast pull to bank. Opening the
    // app and typing nothing still saves nothing.
    if (untouched && !pullPayload()) return;
    const at = new Date().toISOString();
    try {
      window.localStorage.setItem(callStoreKey(address), JSON.stringify({ call: callState, repairOverride, wholesaleFee, rent: effRent > 0 ? Math.round(effRent) : "", pull: pullPayload(), at }));
      setCallSavedAt(at);
    } catch { /* private mode or full storage — the call still works, it just will not persist */ }

    // Push to the team store a beat after typing stops, so a call is one save, not one per keystroke.
    if (!syncId.code) return;
    if (syncTimer.current) clearTimeout(syncTimer.current);
    syncTimer.current = setTimeout(() => {
      setSyncState((p) => ({ ...p, status: "saving" }));
      fetch(`/api/calls?address=${encodeURIComponent(address)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-ylhb-key": syncId.code },
        body: JSON.stringify({ call: callState, repairOverride, wholesaleFee, rent: effRent > 0 ? Math.round(effRent) : "", pull: pullPayload(), by: syncId.name, address }),
      })
        .then((r) => (r.status === 401 ? Promise.reject(new Error("bad-passcode")) : r.json()))
        .then((d) => {
          if (d && d.disabled) { setSyncState({ status: "off", by: null, at: null, msg: "" }); return; }
          if (d && d.error) { setSyncState({ status: "error", by: null, at: null, msg: "" }); return; }
          setSyncState({ status: "synced", by: syncId.name || null, at: (d && d.record && d.record.at) || at, msg: "" });
        })
        .catch((e) => setSyncState({ status: e.message === "bad-passcode" ? "denied" : "error", by: null, at: null, msg: "" }));
    }, 1200);
  }, [callState, repairOverride, wholesaleFee, effRent, address, syncId]);

  // ---- cash MAO (both bands) ----
  const ruleMaoUnder = arv * (num(underPct) / 100) - repairs;
  const ruleMaoOver = arv * (num(overPct) / 100) - repairs;
  const investorMaoUnder = ruleMaoUnder - num(wholesaleFee);
  const investorMaoOver = ruleMaoOver - num(wholesaleFee);
  const itemizedMao =
    arv - repairs - arv * (num(sellingPct) / 100) - num(holding) - num(desiredProfit) - num(wholesaleFee);

  // which band applies to THIS deal (by ARV) — used for the verdict
  const isOver = arv >= 200000;
  const activeRuleMao = isOver ? ruleMaoOver : ruleMaoUnder;
  const activeInvestorMao = repairsKnown ? (isOver ? investorMaoOver : investorMaoUnder) : 0;
  const activePct = isOver ? num(overPct) : num(underPct);

  // Each tab carries a plain-English explainer shown on hover, so a newer rep can tell these five
  // apart without leaving the screen. Written the way you would explain it to a seller, not a textbook.
  const tabs = [
    { id: "cash", label: "Cash / MAO", Icon: Calculator,
      blurb: "You buy it outright, as-is, and close fast. The MAO is the most you can pay and still make money after repairs and your fee.",
      fit: "Best when the house needs real work and the seller wants speed and certainty." },
    { id: "subto", label: "Sub-To", Icon: Building2,
      blurb: "You take over their existing mortgage payments. The loan stays in the seller's name, the deed comes to you.",
      fit: "Best when there is little equity, the rate is good, or they are behind and need the bleeding to stop." },
    { id: "hybrid", label: "Hybrid", Icon: Layers,
      blurb: "Sub-To plus seller carry. You take over the loan, and the seller carries their equity above the balance as a note you pay over time.",
      fit: "Best when there is a loan to take over AND real equity, so cash alone cannot reach their number." },
    { id: "sf", label: "Seller Finance", Icon: Banknote,
      blurb: "The seller becomes the bank. You pay them directly over time on terms you agree to, with no lender involved.",
      fit: "Best when the house is owned free and clear and they do not need all the money today." },
    { id: "nov", label: "Novation", Icon: RefreshCw,
      blurb: "You prepare and sell the house retail on the seller's behalf, then get paid from the spread at closing.",
      fit: "Best when the house is close to retail-ready and the seller can wait out a 60 to 90 day sale." },
  ];

  const deckCommon = {
    address, arv, repairs,
    subjectLine: propLine(subjectInfo),
    rent: effRent,
    askingDefault: num(askingPrice),
    contractDefault: num(askingPrice),
    fee: num(wholesaleFee),
    compCount: num(arvOverride) > 0 ? 0 : (soldSummary ? soldSummary.usedCount : 0),
    avgPpsf: num(arvOverride) > 0 ? 0 : (soldSummary && soldSummary.medianPpsf ? soldSummary.medianPpsf : 0),
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* header */}
      <div className="bg-slate-900 px-5 py-5">
        <div className="mx-auto max-w-5xl">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center rounded-lg bg-white px-2 py-1.5 shadow-sm">
                <img src="/logo.png" alt="Your Local Home Buyer" className="h-9 w-auto object-contain" />
              </div>
              <div>
                <div className="text-sm font-bold tracking-tight text-white">YLHB RE Calculator</div>
                <div className="text-[11px] text-slate-400">Acquisitions</div>
              </div>
            </div>
            <InstructionsButton />
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-5xl px-4 py-5">
        {/* PROPERTY + ARV */}
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <SectionTitle>Property &amp; ARV</SectionTitle>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="sm:col-span-2">
              <Field label="Subject address" hint="start typing — pick the exact match">
                <AddressAutocomplete value={address} onChange={setAddress} placeholder="1225 S 6th St, Louisville, KY" />
              </Field>
              {(propLine(subjectInfo) || lastSoldLine(subjectInfo) || address) && (
                <div className="mt-1.5 space-y-0.5">
                  {(propLine(subjectInfo) || lastSoldLine(subjectInfo)) && (
                    <div className="flex flex-wrap items-center gap-x-2 text-[11px] text-slate-500">
                      {propLine(subjectInfo) && <span>{propLine(subjectInfo)}</span>}
                      {propLine(subjectInfo) && lastSoldLine(subjectInfo) && <span className="text-slate-300">•</span>}
                      {lastSoldLine(subjectInfo) && <span className="font-medium text-slate-600">{lastSoldLine(subjectInfo)}</span>}
                    </div>
                  )}
                  {address && (
                    <a href={gsearch(address)} target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 hover:underline">
                      <Search className="h-3 w-3" /> Google this property <ExternalLink className="h-2.5 w-2.5" />
                    </a>
                  )}
                </div>
              )}
            </div>
            <div>
              <Field label="Subject sq ft">
                <PlainInput value={sqft} onChange={setSqft} placeholder="1500" suffix="sf" />
              </Field>
              {num(sqft) <= 0 && (
                <div className="mt-1.5 flex items-start gap-1.5 rounded-md border border-amber-300 bg-amber-50 px-2 py-1.5 text-[10.5px] leading-snug text-amber-800">
                  <AlertTriangle className="mt-px h-3 w-3 shrink-0 text-amber-600" />
                  <span><b>Needs a number before comps can run right.</b> The ARV math is built on it — Auto-comp fills it for most addresses, but if it stays blank after a pull, look it up and type it in.</span>
                </div>
              )}
              {compDetail && (() => {
                const c = soldSummary ? soldSummary.flagged.find((x) => x.i === compDetail.i) : null;
                if (!c) return null;
                const adj = Math.round(c.adjPrice || 0);
                const tiles = [
                  adj > 0 && adj !== Math.round(c.salePrice) ? { label: "Size-adjusted value", value: usd(adj) } : null,
                  { label: "Recorded sale price", value: usd(c.salePrice) },
                  c.ppsf > 0 ? { label: "Price / sq ft", value: `$${Math.round(c.ppsf)}` } : null,
                  c.beds != null ? { label: "Beds", value: String(c.beds) } : null,
                  c.baths != null ? { label: "Baths", value: String(c.baths) } : null,
                  num(c.sqft) > 0 ? { label: "Sq ft", value: num(c.sqft).toLocaleString() } : null,
                  c.yearBuilt ? { label: "Year built", value: String(c.yearBuilt) } : null,
                  fmtLot(c.lotSize) ? { label: "Lot size", value: fmtLot(c.lotSize) } : null,
                  c.distance != null ? { label: "Distance", value: `${Number(c.distance).toFixed(2)} mi` } : null,
                  c.saleDate ? { label: "Sale date", value: mediumDate(c.saleDate) } : null,
                  c.propertyType ? { label: "Type", value: String(c.propertyType) } : null,
                  c.architecture ? { label: "Architecture", value: String(c.architecture) } : null,
                  c.ownerOccupied != null ? { label: "Occupancy", value: c.ownerOccupied ? "Owner occupied" : "Absentee owner", amber: !c.ownerOccupied } : null,
                  c.heating ? { label: "Heating", value: String(c.heating) } : null,
                  c.cooling ? { label: "A/C", value: String(c.cooling) } : null,
                  c.garage ? { label: "Garage", value: String(c.garage) } : null,
                  c.mls && c.mls.number ? { label: "MLS #", value: String(c.mls.number) } : null,
                  c.mls && c.mls.name ? { label: "MLS", value: String(c.mls.name) } : null,
                  c.mls && c.mls.listPrice ? { label: "Last list price", value: usd(c.mls.listPrice) } : null,
                  c.mls && c.mls.daysOnMarket != null ? { label: "Days on market", value: String(c.mls.daysOnMarket) } : null,
                  c.mls && c.mls.listedDate ? { label: "Listed", value: mediumDate(c.mls.listedDate) } : null,
                  c.mls && c.mls.removedDate ? { label: "Off market", value: mediumDate(c.mls.removedDate) } : null,
                  c.mls && c.mls.listingType && c.mls.listingType !== "Standard" ? { label: "Listing type", value: String(c.mls.listingType), amber: true } : null,
                ].filter(Boolean);
                return (
                  <CompDetailModal
                    data={{
                      n: c.i + 1,
                      source: c.manualEntry ? "MANUAL" : c.mls ? "MLS SALE" : "DEED",
                      address: c.address || "",
                      sv: svLink(c),
                      flags: c.flags || [],
                      included: !!c.included,
                      tiles,
                      history: c.saleHistory || [],
                      sqftNum: num(c.sqft),
                    }}
                    onClose={() => setCompDetail(null)}
                    onToggle={() => setSoldIncluded((p) => ({ ...p, [compDetail.i]: !c.included }))}
                  />
                );
              })()}
              {/* ---- Offer Call: launch pill + guided drawer ---- */}
              {!callOpen && (
                <button type="button" onClick={() => setCallOpen(true)}
                  className="fixed bottom-4 right-4 z-30 flex items-center gap-2 rounded-full bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white shadow-xl hover:bg-emerald-700">
                  <Phone className="h-4 w-4" /> {callTouched ? "Resume call" : "Offer Call"}
                </button>
              )}
              <OfferCall
                open={callOpen}
                onClose={() => setCallOpen(false)}
                cs={callState}
                upd={(k, v) => { setCallTouched(true); setCallState((p) => ({ ...p, [k]: v })); }}
                reset={() => {
                  setCallState(INITIAL_CALL);
                  setCallTouched(false);
                  setCallLoadedAt(null); setCallSavedAt(null);
                  try { if (addressSavable(address)) window.localStorage.removeItem(callStoreKey(address)); } catch {}
                  if (syncId.code && addressSavable(address)) {
                    fetch(`/api/calls?address=${encodeURIComponent(address)}`, { method: "DELETE", headers: { "x-ylhb-key": syncId.code } }).catch(() => {});
                  }
                  setSyncState({ status: "idle", by: null, at: null, msg: "" });
                }}
                save={{ savable: addressSavable(address), savedAt: callSavedAt, loadedAt: callLoadedAt,
                  sync: syncState, syncId,
                  setIdentity: (v) => { writeSyncId(v); setSyncId(v); } }}
                deal={{ arv, maxCash: activeInvestorMao > 0 ? Math.round(activeInvestorMao) : 0, repairs, address, ownerNames, repairOverride, setRepairOverride, repairPsf: num(repairPsf), wholesaleFee, setWholesaleFee, arvSource: ARV_SOURCE_LABEL[arvSource] || "",
                  rent: effRent, rentLoading, onGetRent: () => fetchRent(address), sqft: num(sqft),
                  adjBeds, setAdjBeds, adjBaths, setAdjBaths, subjAdjust,
                  recBeds: subjectInfo?.beds ?? null, recBaths: subjectInfo?.baths ?? null,
                  repairsKnown, ownerType: subjectInfo?.ownerType ?? null, heldFor: subjectInfo?.heldFor ?? null, hoaKnown: subjectInfo?.hoa ?? null }}
                onTab={(t) => { setTab(t); setTimeout(() => document.getElementById("deal-tabs")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60); }}
                onCondition={(v) => { const map = { light: "cosmetic", moderate: "moderate", heavy: "gut" }; if (map[v]) setRehabLevel(map[v]); }}
              />
              <div className="mt-2 flex items-center gap-2">
                <button onClick={autoComp} disabled={compLoading}
                  className={`flex flex-1 items-center justify-center gap-1.5 rounded-md px-2.5 py-1.5 text-[11px] font-bold text-white disabled:opacity-60 ${pullAt ? "bg-slate-700 hover:bg-slate-800" : "bg-emerald-600 hover:bg-emerald-700"}`}>
                  {compLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : pullAt ? <RefreshCw className="h-3.5 w-3.5" /> : <Zap className="h-3.5 w-3.5" />}
                  {compLoading ? "Pulling…" : pullAt ? "Re-pull fresh data" : "Auto-comp address"}
                </button>
              </div>
              {pullAt && !compLoading && (
                <div className="mt-1 text-[10.5px] leading-snug text-slate-500">
                  Showing the RentCast pull from <b className="text-slate-700">{fmtSavedAt(pullAt)}</b>, reloaded free. Re-pull only if this deal has gone cold or something changed.
                </div>
              )}
            </div>
          </div>

          {/* Record corrections — beds/baths the county record missed */}
          <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50/60 p-2.5">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Record corrections</span>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-slate-500">Beds</span>
                <button type="button" onClick={() => setAdjBeds((v) => v - 1)}
                  className="h-6 w-6 rounded border border-slate-200 bg-white text-sm font-bold text-slate-600 hover:bg-slate-100">−</button>
                <span className={`w-8 text-center font-mono text-sm font-bold tabular-nums ${adjBeds !== 0 ? "text-emerald-700" : "text-slate-400"}`}>{adjBeds > 0 ? `+${adjBeds}` : adjBeds}</span>
                <button type="button" onClick={() => setAdjBeds((v) => v + 1)}
                  className="h-6 w-6 rounded border border-slate-200 bg-white text-sm font-bold text-slate-600 hover:bg-slate-100">+</button>
                <span className="text-[10px] text-slate-400">×</span>
                <div className="w-24"><MoneyInput value={bedAdjAmt} onChange={setBedAdjAmt} placeholder="15000" /></div>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-slate-500">Baths</span>
                <button type="button" onClick={() => setAdjBaths((v) => Math.round((v - 0.5) * 2) / 2)}
                  className="h-6 w-6 rounded border border-slate-200 bg-white text-sm font-bold text-slate-600 hover:bg-slate-100">−</button>
                <span className={`w-8 text-center font-mono text-sm font-bold tabular-nums ${adjBaths !== 0 ? "text-emerald-700" : "text-slate-400"}`}>{adjBaths > 0 ? `+${adjBaths}` : adjBaths}</span>
                <button type="button" onClick={() => setAdjBaths((v) => Math.round((v + 0.5) * 2) / 2)}
                  className="h-6 w-6 rounded border border-slate-200 bg-white text-sm font-bold text-slate-600 hover:bg-slate-100">+</button>
                <span className="text-[10px] text-slate-400">×</span>
                <div className="w-24"><MoneyInput value={bathAdjAmt} onChange={setBathAdjAmt} placeholder="10000" /></div>
                <span className="text-[10px] text-slate-400">/full</span>
              </div>
              <span className={`ml-auto font-mono text-sm font-bold tabular-nums ${subjAdjust > 0 ? "text-emerald-700" : subjAdjust < 0 ? "text-rose-600" : "text-slate-400"}`}>
                {subjAdjust !== 0 ? `${subjAdjust > 0 ? "+" : "−"}${usd(Math.abs(subjAdjust))} to ARV` : "no adjustment"}
              </span>
              {(adjBeds !== 0 || adjBaths !== 0) && (
                <button type="button" onClick={() => { setAdjBeds(0); setAdjBaths(0); }}
                  className="rounded border border-slate-200 bg-white px-1.5 py-0.5 text-[10px] font-semibold text-slate-500 hover:bg-slate-50">clear</button>
              )}
            </div>
            <div className="mt-1 text-[10px] text-slate-400">
              For beds/baths the county record missed or overstated — e.g. records say 3bd but you walked a legit 4bd. Adds a flat per-unit amount on top of the Deal Desk comp number. It does not apply when you type your own ARV, since a number you comped yourself already reflects the real room count. Baths step by ½ (a half bath = half the full-bath amount). Defaults are count-adjustments ($15K/bed · $10K/full bath) — not the $30–50K "add a bedroom" headlines, which include square footage. If the missed room also means missed sq ft, fix the sq ft field instead.
            </div>
          </div>
        </div>

        {/* SUBJECT DETAILS — on-demand deep dive from the property record */}
        <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <button type="button" onClick={openSubjDetail} className="flex w-full items-center justify-between gap-2">
            <SectionTitle>Subject property details</SectionTitle>
            <span className="shrink-0 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-semibold text-emerald-600 hover:bg-emerald-50">
              {subjDetailOpen ? "hide" : subjDetail ? "show" : "load details"}
            </span>
          </button>
          {subjDetailOpen && (
            subjDetailLoading ? (
              <div className="mt-3 flex items-center gap-2 text-[11px] font-semibold text-slate-500">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Pulling the property record…
              </div>
            ) : subjDetail && subjDetail.error ? (
              <div className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-[11px] text-rose-700">{subjDetail.error}</div>
            ) : subjDetail && (
              <>
                <a href={svLink({ lat: subjDetail.raw?.lat ?? subjectInfo?.lat, lng: subjDetail.raw?.lng ?? subjectInfo?.lng, address: subjDetail.address })}
                  target="_blank" rel="noopener noreferrer" title="Open interactive Street View"
                  className="relative mt-3 block h-48 w-full max-w-2xl overflow-hidden rounded-xl bg-slate-100 sm:h-56">
                  <span className="absolute inset-0 flex items-center justify-center"><Building2 className="h-10 w-10 text-slate-300" /></span>
                  <img src={`/api/photo?size=640x360&address=${encodeURIComponent(subjDetail.address)}`} alt=""
                    className="absolute inset-0 h-full w-full object-cover"
                    onError={(e) => { e.currentTarget.style.display = "none"; }} />
                  <span className="absolute bottom-2 right-2 rounded bg-slate-900/70 px-1.5 py-0.5 text-[10px] font-semibold text-white">Street View — click to explore</span>
                </a>
                <div className="mt-3 flex flex-wrap gap-1.5 border-b border-slate-100 pb-2">
                  {Object.keys(subjDetail.sections).map((t) => (
                    <button key={t} type="button" onClick={() => setSubjTab(t)}
                      className={`rounded-md px-2.5 py-1 text-[11px] font-semibold ${subjTab === t ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
                      {t}
                    </button>
                  ))}
                </div>
                <div className="mt-3 grid gap-2 sm:grid-cols-3 lg:grid-cols-4">
                  {(subjDetail.sections[subjTab] || []).map(([label, value], k) => (
                    <div key={k} className={`rounded-lg border p-2.5 ${String(value).includes("ABSENTEE") ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-slate-50/50"}`}>
                      <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">{label}</div>
                      <div className="mt-0.5 text-xs font-semibold text-slate-800">{String(value)}</div>
                    </div>
                  ))}
                </div>
              </>
            )
          )}
        </div>

        {/* ACTUAL SOLD COMPS (recorded closings) — collapsed by default now that the ARV box is
            the front door. Reps who already have a number never have to open this. */}
        {!compsOpen ? (
          <button type="button" onClick={() => setCompsOpen(true)}
            className="mt-4 flex w-full items-center justify-between gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-left shadow-sm hover:bg-slate-50 sm:px-5">
            <span>
              <span className="text-[11px] font-bold uppercase tracking-widest text-slate-500">Verify with Deal Desk comps (RentCast)</span>
              <span className="mt-0.5 block text-[11px] leading-snug text-slate-400">
                {soldSummary && soldSummary.arv > 0
                  ? <>Recorded sales say <b className="text-slate-600">{usd(Math.max(0, soldSummary.arv + subjAdjust))}</b>{num(arvOverride) > 0 && Math.abs(num(arvOverride) - (soldSummary.arv + subjAdjust)) > (soldSummary.arv + subjAdjust) * 0.1 ? <span className="text-amber-600"> — more than 10% off your number, worth a look</span> : ""}. Open to review the comps.</>
                  : "Auto-comp pulls recorded sales from RentCast to build or check an ARV. Optional if you already comped it elsewhere."}
              </span>
            </span>
            <ChevronRight className="h-4 w-4 shrink-0 text-slate-400" />
          </button>
        ) : (
        <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="flex items-center justify-between gap-2">
            <button type="button" onClick={() => setCompsOpen(false)} className="flex items-center gap-1.5 text-left hover:opacity-70" title="Collapse the comp engine">
              <SectionTitle>Actual sold comps — recorded closings (RentCast)</SectionTitle>
              <ChevronLeft className="h-3.5 w-3.5 shrink-0 text-slate-400" />
            </button>
            <div className="flex shrink-0 items-center gap-2">
              {soldLoading && (
                <span className="flex shrink-0 items-center gap-1.5 text-[11px] font-semibold text-slate-500">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" /> Pulling…
                </span>
              )}
              {soldData?.mlsChecked && (
                <button type="button" onClick={() => setMlsOnly((v) => !v)}
                  title={mlsOnly ? "Tap to also show deed-only sales — recorded closings that never matched an MLS listing" : "Tap to show only MLS-verified sales"}
                  className={`rounded-md border px-2.5 py-1 text-[11px] font-semibold ${mlsOnly ? "border-emerald-500 bg-emerald-50 text-emerald-700" : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}>
                  {(() => {
                    const h = ((soldData && soldData.comps) || []).filter((x) => !x.mls).length;
                    return mlsOnly ? (h > 0 ? `✓ MLS sales only · ${h} deed ${h === 1 ? "sale" : "sales"} hidden — tap to show` : "✓ MLS sales only") : "Showing all sales — tap for MLS only";
                  })()}
                </button>
              )}
              {!soldAdd && (
                <button type="button" onClick={() => setSoldAdd({ address: "", sqft: "", price: "" })}
                  className="rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-semibold text-slate-600 hover:bg-slate-50">
                  + comp
                </button>
              )}
            </div>
          </div>
          {soldAdd && (
            <div className="mt-2 flex flex-wrap items-end gap-2 rounded-lg border border-emerald-200 bg-emerald-50/40 p-2.5">
              <div className="min-w-[180px] flex-1">
                <Field label="Comp address" hint="optional">
                  <input type="text" value={soldAdd.address} onChange={(e) => setSoldAdd((p) => ({ ...p, address: e.target.value }))}
                    placeholder="123 Main St, City, ST"
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-700 outline-none transition focus:border-emerald-500 focus:ring-1 focus:ring-emerald-100" />
                </Field>
              </div>
              <div className="w-28"><Field label="Sq ft"><PlainInput value={soldAdd.sqft} onChange={(v) => setSoldAdd((p) => ({ ...p, sqft: v }))} placeholder="1500" suffix="sf" /></Field></div>
              <div className="w-36"><Field label="Sale price"><MoneyInput value={soldAdd.price} onChange={(v) => setSoldAdd((p) => ({ ...p, price: v }))} placeholder="200000" /></Field></div>
              <button type="button" disabled={!(num(soldAdd.sqft) > 0 && num(soldAdd.price) > 0)}
                onClick={() => { const sf = num(soldAdd.sqft), pr = num(soldAdd.price); setManualSold((ms) => [...ms, { address: soldAdd.address.trim(), salePrice: pr, sqft: sf, ppsf: Math.round(pr / sf), manualEntry: true }]); setSoldAdd(null); }}
                className="rounded-md bg-emerald-600 px-3 py-1.5 text-[11px] font-bold text-white hover:bg-emerald-700 disabled:opacity-50">
                Add
              </button>
              <button type="button" onClick={() => setSoldAdd(null)}
                className="rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-[11px] font-semibold text-slate-500 hover:bg-slate-50">
                Cancel
              </button>
            </div>
          )}
          <div className="mt-1 text-[10px] text-slate-400">
            Real recorded sale prices off the deed — last 12 months, within 1 mile, ±250 sq ft of the subject, sizes adjusted to the subject. Median of adjusted prices. (Different from Auto-comp above, which uses RentCast's estimate model.)
          </div>

          <div className="mt-2 text-[10px] italic text-slate-400">
            The ARV median runs on the <b className="text-slate-500">best {SOLID_TARGET} solid sales</b> — structurally similar AND priced with the group, sizes adjusted to the subject. <b className="text-amber-700">Possible distressed sale</b> = sold way too cheap, leave it out; <b className="text-amber-700">possible renovated resale</b> = sold high because it's already fixed up — Google it, and if it's remodeled, hit include (that IS after-repair condition). Recorded prices come from public records and can lag a few weeks; KY and IN both disclose sale prices. Verify anything you'll hang a deal on.
          </div>
          {subjectInfo?.lat != null && soldSummary && soldSummary.flagged.some((c) => c.lat != null) && (
            <CompMap
              subject={{ lat: subjectInfo.lat, lng: subjectInfo.lng, label: address || "Subject" }}
              pins={soldSummary.flagged.map((c) => ({ i: c.i, n: c.i + 1, lat: c.lat ?? null, lng: c.lng ?? null, price: c.salePrice, included: !!c.included, flagged: c.flags.length > 0 })).filter((p) => p.lat != null && p.lng != null)}
              onToggle={(i) => { const cur = soldSummary.flagged.find((x) => x.i === i); setSoldIncluded((p) => ({ ...p, [i]: !(cur && cur.included) })); }}
            />
          )}

          {soldMsg && (
            <div className={`mt-2 rounded-lg px-3 py-2 text-[11px] ${soldMsg.type === "ok" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>
              {soldMsg.text}
            </div>
          )}

          {soldSummary && (
            <>
              {soldSummary.thin && (
                <div className="mt-3 flex items-start gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11px] leading-snug text-amber-800">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <span><b>Thin comps — only {soldSummary.usedCount} of the {MIN_SOLID} solid sales this ARV needs at minimum.</b> The median is fragile. Google the flagged ones and hit <b>include</b> on any you verify, or add solid sales by hand with + comp. When comps run thin, do what appraisers do: <b>go wider before you go older</b> — stretch the distance before you reach past the 12-month window. And YLHB’s rule while you widen: <b>don’t cross major roads, highways, or train tracks</b> — those are market boundaries, and the buyer pool changes on the other side.</span>
                </div>
              )}
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <Stat label="Sold-comp ARV (After Repair Value)" value={soldSummary.arv ? usd(Math.max(0, soldSummary.arv + subjAdjust)) : "—"} tone={soldSummary.thin ? "default" : "good"} big sub={`${num(sqft) > 0 ? `size-adjusted median × ${num(sqft)} sf` : "enter subject sq ft above"}${soldSummary.arv && subjAdjust !== 0 ? ` · ${subjAdjust > 0 ? "+" : "−"}${usd(Math.abs(subjAdjust))} bed/bath` : ""}`} />
                <Stat label="Median $/sf" value={soldSummary.medianPpsf ? `$${soldSummary.medianPpsf}` : "—"} sub={`${soldSummary.usedCount} of ${soldSummary.total} comps · size-adjusted`} />
              </div>

              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {soldSummary.flagged.map((c, i) => (
                  <div key={i} className={`rounded-xl border-2 bg-white p-3 ${c.included ? "border-emerald-400" : "border-slate-200"}`}>
                    <div className="flex items-center justify-between gap-2">
                      <button type="button" onClick={() => setSoldIncluded((p) => ({ ...p, [i]: !c.included }))} className="flex items-center gap-2">
                        <span className={`flex h-5 w-5 items-center justify-center rounded-md font-mono text-[10px] font-bold text-white ${c.included ? "bg-emerald-600" : c.flags.length ? "bg-amber-500" : "bg-slate-400"}`}>{i + 1}</span>
                        <span className={`flex h-4 w-4 items-center justify-center rounded border text-[10px] font-bold ${c.included ? "border-emerald-600 bg-emerald-600 text-white" : "border-slate-300 bg-white text-transparent"}`}>✓</span>
                        <span className="text-xs font-semibold text-slate-700">Include in ARV</span>
                      </button>
                      <span className="flex shrink-0 items-center gap-1">{c.mls && <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-emerald-700" title={c.mls.number ? `MLS # ${c.mls.number}` : "Matched to an MLS listing"}>MLS</span>}<span className="rounded bg-sky-100 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-sky-700">{c.manualEntry ? "MANUAL" : "DEED"}</span></span>
                    </div>
                    <div className="mt-2 flex gap-3">
                      <button type="button" onClick={() => setCompDetail({ panel: "sold", i: c.i })} title="Open comp details"
                        className="relative flex h-20 w-24 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-slate-100 transition hover:ring-2 hover:ring-emerald-300">
                        <Building2 className="h-7 w-7 text-slate-300" />
                        {c.address && (
                          <img src={`/api/photo?address=${encodeURIComponent(c.address)}`} alt="" loading="lazy"
                            className="absolute inset-0 h-full w-full object-cover"
                            onError={(e) => { e.currentTarget.style.display = "none"; }} />
                        )}
                      </button>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-baseline justify-between gap-2">
                          <span className="font-mono text-lg font-bold tabular-nums text-slate-900">{usd(c.salePrice)}</span>
                          {c.distance != null && <span className="shrink-0 font-mono text-[11px] text-slate-500">{Number(c.distance).toFixed(2)} mi</span>}
                        </div>
                        {c.saleDate && <div className="text-[11px] text-slate-400">sold {mediumDate(c.saleDate)}</div>}
                        <div className="mt-0.5 flex items-center gap-1.5 text-xs font-medium text-slate-700">
                          <span className="truncate">{c.address || "(address withheld)"}</span>
                          {c.address && (
                            <a href={gsearch(c.address)} target="_blank" rel="noopener noreferrer" className="shrink-0 text-[11px] font-semibold text-emerald-600 hover:underline">
                              Google
                            </a>
                          )}
                        </div>
                        <div className="mt-0.5 text-[11px] text-slate-500">
                          {[
                            (c.beds != null || c.baths != null) ? `${c.beds ?? "?"} bd · ${c.baths ?? "?"} ba` : null,
                            `${c.sqft.toLocaleString()} sqft`,
                            c.yearBuilt ? String(c.yearBuilt) : null,
                            `$${c.ppsf}/sf`,
                            c.appsf > 0 && Math.round(c.appsf) !== Math.round(c.ppsf) ? `adj $${Math.round(c.appsf)}/sf` : null,
                          ].filter(Boolean).join(" · ")}
                        </div>
                      </div>
                    </div>
                    {(c.flags.length > 0 || c.benched) && (
                      <div className="mt-2 flex flex-wrap items-center gap-1">
                        {c.flags.map((f, k) => (
                          <span key={k} className="inline-flex items-center gap-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold text-amber-700">
                            <AlertTriangle className="h-2.5 w-2.5" /> {f}
                          </span>
                        ))}
                        {c.benched && (
                          <span className="inline-flex items-center rounded bg-slate-200/70 px-1.5 py-0.5 text-[10px] font-semibold text-slate-500">beyond the top {SOLID_TARGET}</span>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
        )}

        {/* ARV — leads with the number that is actually driving the deal, then lets a rep change
            it. Showing a blank "optional" box first made VAs think the tool had no ARV at all,
            even when the comps had already produced one. Answer first, override second. */}
        <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <SectionTitle>ARV — after repair value</SectionTitle>

          <div className="mt-2 rounded-xl border-2 border-slate-900 bg-slate-50 p-3">
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Driving this deal</div>
            <div className="mt-0.5 font-mono text-3xl font-bold tabular-nums text-slate-900">{arv > 0 ? usd(arv) : "—"}</div>
            <div className="mt-0.5 text-[11px] leading-snug text-slate-500">
              {arv <= 0
                ? "No ARV yet. Run Auto-comp up top, or type a number you comped elsewhere."
                : num(arvOverride) > 0
                  ? <>
                      <b className="text-slate-700">Your number is being used.</b> It overrides the Deal Desk comps
                      {soldSummary && soldSummary.arv > 0 ? <>, which say <b className="text-slate-700">{usd(Math.max(0, soldSummary.arv + subjAdjust))}</b></> : null}
                      {arvSource ? <>. Tagged {(ARV_SOURCE_LABEL[arvSource] || "").toLowerCase()}</> : null}.
                      {subjAdjust !== 0 ? <> The {subjAdjust > 0 ? "+" : "−"}{usd(Math.abs(subjAdjust))} bed/bath correction is <b>not</b> added, since you comped this yourself and already counted the rooms.</> : null} Clear the box to go back to the comps.
                    </>
                  : <>Calculated from the recorded sold comps that Auto-comp pulled from RentCast, shown above.{subjAdjust !== 0 ? ` Includes a ${subjAdjust > 0 ? "+" : "−"}${usd(Math.abs(subjAdjust))} bed/bath correction.` : ""} <b className="text-slate-700">Anything you type here wins over this.</b></>}
            </div>

            {/* The override sits inside the box, directly under the line explaining what it does,
                so the number and the way to change it are one thing rather than two. */}
            <div className="mt-2.5 border-t border-slate-300 pt-2.5">
              <Field label={num(arvOverride) > 0 ? "Your ARV — overriding the comps" : "Use your own number instead"} hint={num(arvOverride) > 0 ? "clear it to go back to comps" : "wins over the comps"}>
                <MoneyInput value={arvOverride} onChange={setArvOverride} placeholder={arv > 0 && num(arvOverride) <= 0 ? String(Math.round(arv)) : "optional"} />
              </Field>
            </div>
          </div>

          <div className="mt-3">
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Where did this number come from?</div>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {ARV_SOURCES.map(([v, l]) => (
                <button key={v} type="button" onClick={() => setArvSource(arvSource === v ? "" : v)}
                  className={`rounded-md border px-2.5 py-1 text-[11px] font-semibold ${arvSource === v ? "border-emerald-600 bg-emerald-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}>
                  {l}
                </button>
              ))}
            </div>
            {num(arvOverride) > 0 && !arvSource && (
              <div className="mt-1.5 flex items-start gap-1.5 text-[10.5px] leading-snug text-amber-700">
                <AlertTriangle className="mt-px h-3 w-3 shrink-0 text-amber-500" />
                Tag the source. It goes on the call report, so anyone reviewing this deal later can see whether the ARV was comped or estimated.
              </div>
            )}
            {arvSource === "ps-estimate" && (
              <div className="mt-1.5 flex items-start gap-1.5 text-[10.5px] leading-snug text-amber-700">
                <AlertTriangle className="mt-px h-3 w-3 shrink-0 text-amber-500" />
                That is an automated estimate, not comped value. Fine for a first pass, but comp it before you put a number in front of a seller.
              </div>
            )}
          </div>

          {/* Last thing in the card: with an ARV settled, the next move is the call, not more analysis. */}
          {arv > 0 && !callTouched && (
            <>
              <button type="button" onClick={() => setCallOpen(true)}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-3 text-sm font-bold text-white shadow-sm hover:bg-emerald-700">
                <Phone className="h-4 w-4" /> You have an ARV. Open the Offer Call.
              </button>
              <div className="mt-1 text-center text-[10.5px] leading-snug text-slate-400">
                The Offer Call walks the script, captures what the seller tells you, and tells you which strategy to pitch.
              </div>
            </>
          )}
        </div>

        {/* CONTROLS: rehab + MAO bands */}
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <SectionTitle>Rehab level</SectionTitle>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "cosmetic", t: "Light", s: "$15/sf" },
                { id: "moderate", t: "Moderate", s: "$30/sf" },
                { id: "gut", t: "Full Gut", s: "$50/sf" },
                { id: "custom", t: "Custom", s: "set $/sf" },
              ].map((r) => (
                <button key={r.id} onClick={() => setRehabLevel(rehabLevel === r.id ? "" : r.id)}
                  className={`rounded-lg border px-3 py-2 text-left transition ${
                    rehabLevel === r.id ? "border-emerald-500 bg-emerald-50" : "border-slate-200 bg-white hover:border-slate-300"
                  }`}>
                  <div className="text-sm font-semibold text-slate-800">{r.t}</div>
                  <div className="text-[11px] text-slate-500">{r.s}</div>
                </button>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {rehabLevel === "custom" && (
                <Field label="Custom $/sf">
                  <PlainInput value={customPsf} onChange={setCustomPsf} placeholder="45" suffix="$/sf" />
                </Field>
              )}
              <Field label="Or total repair $" hint="overrides">
                <MoneyInput value={repairOverride} onChange={setRepairOverride} placeholder="optional" />
              </Field>
              <div className="mt-3 flex items-baseline justify-between rounded-lg bg-slate-50 px-3 py-2">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Estimated rehab</span>
                <span className="font-mono text-xl font-bold tabular-nums text-slate-800">{repairs > 0 ? usd(repairs) : "—"}</span>
              </div>
              {!repairsKnown && (
                <div className="mt-2 flex items-start gap-1.5 rounded-md border border-amber-300 bg-amber-50 px-2.5 py-1.5 text-[11px] leading-snug text-amber-800">
                  <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0 text-amber-500" />
                  <span><b>No repair number yet.</b> Pick a rehab level or type a real number. Until then there is no max offer, because an offer that assumes zero repairs is one you cannot honor.</span>
                </div>
              )}
              <div className="mt-1 text-[10px] text-slate-400">
                {num(repairOverride) > 0
                  ? "manual total — overrides the $/sf tiles"
                  : num(sqft) > 0
                    ? `${usd(repairPsf || 0)}/sf × ${num(sqft).toLocaleString()} sf — updates live with the tiles and subject sq ft`
                    : "pick a level and enter subject sq ft above to compute"}
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <SectionTitle>MAO % of ARV — by price band</SectionTitle>
            <div className="grid grid-cols-2 gap-3">
              <div className={`rounded-lg border px-3 py-2 ${!isOver ? "border-emerald-500 bg-emerald-50" : "border-slate-200"}`}>
                <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Under $200k</div>
                <div className="mt-1 flex items-baseline gap-1">
                  <span className="font-mono text-2xl font-bold tabular-nums text-slate-900">{underPct}</span>
                  <span className="text-xs text-slate-500">%</span>
                </div>
                <input type="range" min={60} max={85} step={1} value={underPct} onChange={(e) => setUnderPct(parseInt(e.target.value))} className="mt-1 w-full accent-emerald-600" />
              </div>
              <div className={`rounded-lg border px-3 py-2 ${isOver ? "border-emerald-500 bg-emerald-50" : "border-slate-200"}`}>
                <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Over $200k</div>
                <div className="mt-1 flex items-baseline gap-1">
                  <span className="font-mono text-2xl font-bold tabular-nums text-slate-900">{overPct}</span>
                  <span className="text-xs text-slate-500">%</span>
                </div>
                <input type="range" min={60} max={90} step={1} value={overPct} onChange={(e) => setOverPct(parseInt(e.target.value))} className="mt-1 w-full accent-emerald-600" />
              </div>
            </div>
            <div className="mt-3 rounded-lg bg-slate-50 px-3 py-2 text-[11px] text-slate-500">
              ARV {usd(arv)} → <b>{isOver ? "Over $200k" : "Under $200k"}</b> band applies ({activePct}%). Both columns show in the Cash/MAO tab; the green one is this deal.
            </div>
          </div>
        </div>

        {/* TABS */}
        {/* Strategy tabs. These switch the whole deal underneath them, so they read as a real
            control bar rather than five quiet chips: a labeled container, a green active tab, and
            an underline so the selected strategy connects visually to the panel below it. */}
        <div id="deal-tabs" className="mt-6 scroll-mt-3">
          <div className="mb-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-400">Pick your exit strategy</div>
          <div className="flex flex-wrap gap-2 rounded-xl border border-slate-200 bg-slate-100/70 p-1.5">
            {tabs.map((t) => {
              const Icon = t.Icon;
              const on = tab === t.id;
              return (
                <div key={t.id} className="group relative flex-1">
                  <button onClick={() => setTab(t.id)}
                    className={`flex w-full items-center justify-center gap-2 rounded-lg px-3.5 py-2.5 text-sm font-bold transition ${
                      on
                        ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/25 ring-2 ring-emerald-600 ring-offset-1 ring-offset-slate-100"
                        : "bg-white text-slate-600 shadow-sm hover:bg-white hover:text-slate-900 hover:shadow"
                    }`}>
                    <Icon className={`h-4 w-4 ${on ? "" : "text-slate-400"}`} />
                    <span className="whitespace-nowrap">{t.label}</span>
                  </button>
                  {/* Hover explainer. Hidden on touch screens, where there is no hover — the same
                      wording lives under the tab bar on small screens instead. */}
                  <div className="pointer-events-none absolute left-1/2 top-full z-30 hidden w-72 -translate-x-1/2 pt-2 opacity-0 transition-opacity group-hover:opacity-100 sm:group-hover:block">
                    <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xl">
                      <div className="flex items-center gap-1.5 text-[12px] font-bold text-slate-900">
                        <Icon className="h-3.5 w-3.5 text-emerald-600" />{t.label}
                      </div>
                      <div className="mt-1 text-[11.5px] leading-snug text-slate-600">{t.blurb}</div>
                      <div className="mt-1.5 text-[11px] leading-snug text-emerald-700">{t.fit}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          {/* Phones and tablets cannot hover, so the active strategy explains itself right here. */}
          {(() => {
            const t = tabs.find((x) => x.id === tab);
            return t ? (
              <div className="mt-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-[11.5px] leading-snug text-slate-600 sm:hidden">
                {t.blurb} <span className="text-emerald-700">{t.fit}</span>
              </div>
            ) : null;
          })()}
        </div>

        <div className="mt-4">
          {tab === "cash" && (
            <CashTab {...{ arv, repairs, underPct, overPct, isOver, ruleMaoUnder, ruleMaoOver, investorMaoUnder, investorMaoOver, itemizedMao, activeInvestorMao, activeRuleMao, activePct, wholesaleFee, setWholesaleFee, sellingPct, setSellingPct, holding, setHolding, desiredProfit, setDesiredProfit, askingPrice, setAskingPrice, rentOverride, setRentOverride, rentDefault: effRent, deckCommon, onGenerateRent: () => fetchRent(address), rentLoading, rentMsg, hasAddress: !!address.trim() }} />
          )}
          {tab === "subto" && (
            <SubToTab {...{ arv, repairs, underPct, overPct, wholesaleFee, setWholesaleFee, deckCommon, rentDefault: effRent, stBal, setStBal, stPiti, setStPiti, stArrears, setStArrears, stCashSeller, setStCashSeller, stClosing, setStClosing, stRent, setStRent, stReservePct, setStReservePct }} />
          )}
          {tab === "hybrid" && (
            <HybridTab {...{ arv, repairs, underPct, overPct, wholesaleFee, setWholesaleFee, deckCommon, rentDefault: effRent, hyPrice, setHyPrice, hyDown, setHyDown, hyBal, setHyBal, hyPiti, setHyPiti, hyRate, setHyRate, hyTerm, setHyTerm, hyClosing, setHyClosing, hyRent, setHyRent, hyReservePct, setHyReservePct }} />
          )}
          {tab === "sf" && (
            <SellerFinanceTab {...{ arv, repairs, underPct, overPct, wholesaleFee, setWholesaleFee, deckCommon, rentDefault: effRent, sfPrice, setSfPrice, sfDown, setSfDown, sfRate, setSfRate, sfAmort, setSfAmort, sfBalloon, setSfBalloon, sfTaxIns, setSfTaxIns, sfRent, setSfRent, sfReservePct, setSfReservePct }} />
          )}
          {tab === "nov" && (
            <NovationTab {...{ novAsIs, setNovAsIs, novProfit, setNovProfit, novListFactor, setNovListFactor, novCostFactor, setNovCostFactor }} />
          )}
        </div>

        <div className="mt-5 rounded-xl border border-slate-200 bg-white px-4 py-3 text-[11px] leading-relaxed text-slate-400">
          Formulas use standard YLHB methodology (ARV = avg $/sf × sq ft; MAO = ARV × band % − repairs).
          Bands default to 75% under $200k / 80% over, matching your sheet. Estimates only — verify comps and underwriting before offers. Not legal or financial advice.
        </div>
      </div>
    </div>
  );
}

// ---------- shared: how-to-use instructions ----------
function InstructionsButton() {
  const [open, setOpen] = useState(false);
  const steps = [
    ["Pull the property", "Type the address up top and hit Auto-comp. It pulls the ARV, sold comps, property details, and the subject's last sale — all from the address."],
    ["Tighten the comps", "Auto-comp keeps the 8 most-similar sold comps (last 12 months, ±250 sq ft). Comps that are off on beds, baths, age, size, or distance get an amber flag — delete the weak ones and the ARV recalculates live."],
    ["Pick your structure", "Use the tabs to run the deal as Cash/MAO, Sub-To, Hybrid, Seller Finance, Novation, or Rental. Each gives you a verdict and the key numbers."],
    ["Read the verdict", "Green means it pencils, amber means it's tight, red means walk. Hover the ⓘ icons for what any field means."],
    ["Wholesale it creative", "On the creative tabs, the 'If you wholesaled this contract' panel shows what you could assign the deal for — equity PLUS the financing value of the low rate. Lower rate = more value."],
    ["See the rate's worth", "The Rate Savings and amortization sliders show what a below-market loan saves over time and how the payment shifts from interest to principal."],
    ["Check the rental & BRRRR exit", "On the Cash/MAO tab, the BRRRR/DSCR panel shows the refinance, DSCR, and cash flow. Market rent is pulled automatically with Auto-comp, or type your own."],
    ["Send it to buyers", "Hit 'Download buyer deck' on any creative tab to generate a branded YLHB PowerPoint for your buyers list. Fill the required fields and it builds the slides."],
    ["Learn as you go", "Every tab has a plain-English explainer at the bottom, plus free Pace Morby videos on that structure."],
  ];
  return (
    <>
      <button onClick={() => setOpen(true)}
        className="flex shrink-0 items-center gap-1.5 rounded-lg border border-slate-600 bg-slate-800 px-3 py-1.5 text-[12px] font-semibold text-slate-200 hover:bg-slate-700">
        <HelpCircle className="h-4 w-4 text-emerald-400" /> How to use
      </button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setOpen(false)}>
          <div className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-1 flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-800">How to use the YLHB RE Calculator</h2>
              <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-slate-600"><X className="h-5 w-5" /></button>
            </div>
            <p className="mb-4 text-[13px] text-slate-500">Address in → deal out. Here's the flow, start to finish.</p>
            <ol className="space-y-3">
              {steps.map((s, i) => (
                <li key={i} className="flex gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[12px] font-bold text-emerald-700">{i + 1}</span>
                  <div>
                    <div className="text-[13px] font-bold text-slate-800">{s[0]}</div>
                    <div className="text-[13px] leading-relaxed text-slate-600">{s[1]}</div>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mt-5 rounded-lg bg-slate-50 px-3 py-2 text-[11px] text-slate-500">
              Tip: numbers are estimates to get you to a fast yes/no. Always verify ARV, rent, condition, and loan terms before you commit a dollar.
            </div>
            <button onClick={() => setOpen(false)} className="mt-4 w-full rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-700">Got it</button>
          </div>
        </div>
      )}
    </>
  );
}

// ---------- shared: buyer deck (.pptx) ----------
const YLHB = {
  email: "deals@yourlocalhomebuyerteam.com",
  phone: "(502) 305-8554",
  phoneRaw: "+15023058554",
  site: "www.yourlocalhomebuyerteam.com",
  siteUrl: "https://www.yourlocalhomebuyerteam.com",
};
const DECK = { FOREST: "1E4D2B", SAGE: "9CAF88", ORANGE: "E8833A", INK: "1A2E22", PAPER: "F5F7F4", WHITE: "FFFFFF", LINE: "DDE3DC" };

// Load PptxGenJS from CDN on first use (avoids bundling a heavy lib; keeps the Vercel build simple).
let _pptxPromise = null;
function loadPptx() {
  if (typeof window !== "undefined" && window.PptxGenJS) return Promise.resolve(window.PptxGenJS);
  if (_pptxPromise) return _pptxPromise;
  _pptxPromise = new Promise((resolve, reject) => {
    const sc = document.createElement("script");
    sc.src = "https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js";
    sc.async = true;
    sc.onload = () => (window.PptxGenJS ? resolve(window.PptxGenJS) : reject(new Error("PowerPoint library loaded but unavailable.")));
    sc.onerror = () => reject(new Error("Could not load the PowerPoint library (check your connection)."));
    document.head.appendChild(sc);
  });
  return _pptxPromise;
}

async function getLogoData() {
  try {
    const res = await fetch("/logo.png");
    const blob = await res.blob();
    return await new Promise((resolve) => {
      const r = new FileReader();
      r.onloadend = () => resolve(String(r.result).replace(/^data:/, "")); // pptxgenjs wants "image/png;base64,..."
      r.onerror = () => resolve(null);
      r.readAsDataURL(blob);
    });
  } catch { return null; }
}

async function generateBuyerDeck(data) {
  const PptxGenJS = await loadPptx();
  const logo = await getLogoData();
  const pptx = new PptxGenJS();
  pptx.defineLayout({ name: "W", width: 13.333, height: 7.5 });
  pptx.layout = "W";
  pptx.author = "Your Local Home Buyer";
  pptx.company = "Your Local Home Buyer";
  const addLogo = (s, x, y, w) => { if (logo) s.addImage({ data: logo, x, y, w, h: w * 0.59 }); };

  // Slide 1 — cover (photo if provided, else branded title card)
  let s = pptx.addSlide();
  if (data.photo) {
    s.background = { color: DECK.INK };
    try { s.addImage({ data: data.photo, x: 0, y: 0, w: 13.333, h: 5.1, sizing: { type: "cover", w: 13.333, h: 5.1 } }); } catch { /* bad image — skip */ }
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 5.1, w: 13.333, h: 2.4, fill: { color: DECK.FOREST } });
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 7.35, w: 13.333, h: 0.15, fill: { color: DECK.ORANGE } });
    addLogo(s, 11.1, 5.32, 1.6);
    s.addText("INVESTMENT OPPORTUNITY", { x: 0.6, y: 5.3, w: 10, h: 0.4, fontSize: 14, color: DECK.SAGE, bold: true, charSpacing: 3 });
    s.addText(data.address || "Property address", { x: 0.6, y: 5.7, w: 10.3, h: 0.9, fontSize: 30, color: DECK.WHITE, bold: true });
    if (data.headline) s.addText(data.headline, { x: 0.6, y: 6.7, w: 11, h: 0.5, fontSize: 16, color: DECK.SAGE });
  } else {
    s.background = { color: DECK.FOREST };
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.7, w: 13.333, h: 0.8, fill: { color: DECK.ORANGE } });
    addLogo(s, 0.6, 0.5, 2.3);
    s.addText("INVESTMENT OPPORTUNITY", { x: 0.6, y: 2.5, w: 12.1, h: 0.5, fontSize: 16, color: DECK.SAGE, bold: true, charSpacing: 3 });
    s.addText(data.address || "Property address", { x: 0.6, y: 3.0, w: 12.1, h: 1.2, fontSize: 38, color: DECK.WHITE, bold: true });
    if (data.headline) s.addText(data.headline, { x: 0.6, y: 4.35, w: 12.1, h: 0.6, fontSize: 18, color: DECK.SAGE });
  }

  const header = (slide, title) => {
    slide.background = { color: DECK.PAPER };
    slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 13.333, h: 1.1, fill: { color: DECK.FOREST } });
    slide.addText(title, { x: 0.6, y: 0.28, w: 10.4, h: 0.6, fontSize: 26, color: DECK.WHITE, bold: true });
    addLogo(slide, 11.3, 0.2, 1.45);
  };
  const kv = (rows) => rows.map((r) => [{ text: r[0], options: { bold: true, color: DECK.FOREST } }, { text: r[1], options: { align: "right", color: DECK.INK } }]);
  const tableOpts = { fontSize: 15, color: DECK.INK, rowH: 0.6, valign: "middle", fill: { color: DECK.WHITE }, border: { type: "solid", color: DECK.LINE, pt: 1 } };

  // Slide 2 — property
  s = pptx.addSlide(); header(s, "The Property");
  const propRows = [["Address", data.address || "—"]];
  if (data.subjectLine) propRows.push(["Property", data.subjectLine]);
  propRows.push(["After-Repair Value (ARV)", data.arv ? usd(data.arv) : "—"]);
  propRows.push(["Estimated rehab", data.repairs ? usd(data.repairs) : "—"]);
  propRows.push([data.priceLabel || "Purchase price", data.asking ? usd(data.asking) : "—"]);
  propRows.push(["Estimated rent", data.rent ? usd(data.rent) + "/mo" : "—"]);
  s.addTable(kv(propRows), { x: 0.6, y: 1.5, w: 12.1, colW: [4.2, 7.9], ...tableOpts });
  s.addText("Estimates for buyer review. Buyer to verify all figures, condition, and terms independently.", { x: 0.6, y: 6.9, w: 12.1, h: 0.4, fontSize: 9, color: "8A968C", italic: true });

  // Slide 3 — the deal
  s = pptx.addSlide(); header(s, `The Deal — ${data.dealType}`);
  const dRows = (data.dealRows && data.dealRows.length ? data.dealRows : [["—", "—"]]);
  s.addTable(kv(dRows), { x: 0.6, y: 1.5, w: 7.9, colW: [5.1, 2.8], ...tableOpts });
  if (dRows.some((r) => /PITI/i.test(String(r[0])))) s.addText("PITI = principal, interest, taxes & insurance — the monthly payment you take over.", { x: 0.6, y: 1.5 + dRows.length * 0.6 + 0.15, w: 7.9, h: 0.5, fontSize: 11, color: "6B7A6F", italic: true });
  s.addShape(pptx.ShapeType.roundRect, { x: 8.9, y: 1.5, w: 3.8, h: 2.4, fill: { color: DECK.FOREST }, rectRadius: 0.1 });
  s.addText([
    { text: (data.totalLabel || "TOTAL DEAL VALUE").toUpperCase() + "\n", options: { fontSize: 13, color: DECK.SAGE, bold: true } },
    { text: data.totalValue || "—", options: { fontSize: 32, color: DECK.WHITE, bold: true } },
  ], { x: 8.9, y: 1.95, w: 3.8, h: 1.5, align: "center", valign: "middle" });
  if (data.verdict) s.addText(data.verdict, { x: 8.9, y: 4.05, w: 3.8, h: 2.4, fontSize: 12, color: DECK.INK, align: "center" });

  // Slide 4 — why this deal
  const highlights = (data.highlights || []).filter(Boolean);
  if (highlights.length) {
    s = pptx.addSlide(); header(s, "Why this deal");
    const items = highlights.slice(0, 6).map((h) => ({ text: h, options: { bullet: { code: "2713", indent: 18 }, color: DECK.INK, fontSize: 18, paraSpaceAfter: 14 } }));
    s.addText(items, { x: 0.9, y: 1.6, w: 11.5, h: 4.6, valign: "top" });
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.9, w: 13.333, h: 0.6, fill: { color: DECK.ORANGE } });
  }

  // Slide — returns snapshot
  const R = data.returns;
  if (R && (R.monthlyCF || R.cashToClose || R.annualCF)) {
    s = pptx.addSlide(); header(s, "The Returns");
    const card = (x, label, value, accent) => {
      s.addShape(pptx.ShapeType.roundRect, { x, y: 1.6, w: 2.85, h: 1.9, fill: { color: DECK.WHITE }, line: { color: DECK.LINE, width: 1 }, rectRadius: 0.08 });
      s.addText([
        { text: label.toUpperCase() + "\n", options: { fontSize: 11, color: "6B7A6F", bold: true } },
        { text: value, options: { fontSize: 26, color: accent || DECK.FOREST, bold: true } },
      ], { x, y: 1.85, w: 2.85, h: 1.4, align: "center", valign: "middle" });
    };
    card(0.6, "Cash to close", R.cashToClose ? usd(R.cashToClose) : "—", DECK.INK);
    card(3.65, "Monthly cash flow", R.monthlyCF ? usd(R.monthlyCF) : "—", DECK.FOREST);
    card(6.7, "Annual cash flow", R.annualCF ? usd(R.annualCF) : "—", DECK.FOREST);
    card(9.75, "Cash-on-cash", R.coc ? R.coc.toFixed(1) + "%" : "—", DECK.ORANGE);
    if (data.exits && data.exits.length) {
      s.addText("Exit strategies", { x: 0.6, y: 3.9, w: 12, h: 0.4, fontSize: 15, color: DECK.FOREST, bold: true });
      const ex = data.exits.slice(0, 4).map((e) => ({ text: e, options: { bullet: { code: "2022", indent: 16 }, color: DECK.INK, fontSize: 15, paraSpaceAfter: 8 } }));
      s.addText(ex, { x: 0.7, y: 4.4, w: 12, h: 2, valign: "top" });
    }
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.9, w: 13.333, h: 0.6, fill: { color: DECK.ORANGE } });
  }

  // Slide — what taking over this loan saves (financing value)
  try {
    const LS = data.loanSavings;
    if (LS && LS.totalSaved > 0) {
      s = pptx.addSlide(); header(s, "What This Loan Saves");
      s.addText("Held to maturity — vs. financing this property with a new loan today", { x: 0.6, y: 1.18, w: 12.1, h: 0.3, fontSize: 12, color: DECK.SAGE, italic: true });
      const lsCard = (x, label, value, sub) => {
        s.addShape(pptx.ShapeType.roundRect, { x, y: 1.55, w: 5.95, h: 1.6, fill: { color: DECK.WHITE }, line: { color: DECK.LINE, width: 1 }, rectRadius: 0.08 });
        s.addText([
          { text: label.toUpperCase() + "\n", options: { fontSize: 12, color: "6B7A6F", bold: true } },
          { text: value + "\n", options: { fontSize: 30, color: DECK.FOREST, bold: true } },
          { text: sub, options: { fontSize: 11, color: "8A968C" } },
        ], { x: x + 0.25, y: 1.62, w: 5.45, h: 1.45, align: "left", valign: "middle" });
      };
      lsCard(0.6, "Rate savings", usd(LS.rateSaved), `${LS.rate.toFixed(2)}% vs ${LS.mkt.toFixed(2)}%, same ${LS.term} yrs left`);
      lsCard(6.78, "Seasoning savings", usd(LS.seasoningSaved), `${LS.term} yrs left vs a fresh ${LS.effOrig}-yr loan`);
      s.addShape(pptx.ShapeType.roundRect, { x: 0.6, y: 3.35, w: 12.13, h: 1.0, fill: { color: DECK.FOREST }, rectRadius: 0.08 });
      s.addText([
        { text: "TOTAL INTEREST SAVED     ", options: { fontSize: 16, color: DECK.SAGE, bold: true } },
        { text: usd(LS.totalSaved), options: { fontSize: 34, color: DECK.WHITE, bold: true } },
      ], { x: 0.9, y: 3.35, w: 11.5, h: 1.0, align: "left", valign: "middle" });
      const cmp = [
        [{ text: "" }, { text: "Take this loan", options: { bold: true, color: DECK.FOREST, align: "center" } }, { text: "Get a new loan", options: { bold: true, color: DECK.INK, align: "center" } }],
        [{ text: "Rate", options: { bold: true, color: DECK.FOREST } }, { text: LS.rate.toFixed(2) + "%", options: { align: "center", color: DECK.FOREST } }, { text: LS.mkt.toFixed(2) + "%", options: { align: "center", color: DECK.INK } }],
        [{ text: "Years to pay", options: { bold: true, color: DECK.FOREST } }, { text: LS.term + " left", options: { align: "center", color: DECK.FOREST } }, { text: LS.effOrig + " fresh", options: { align: "center", color: DECK.INK } }],
      ];
      if (LS.haveRealPmt) cmp.push([{ text: "Payment", options: { bold: true, color: DECK.FOREST } }, { text: usd(LS.takePayment) + "/mo", options: { align: "center", color: DECK.FOREST } }, { text: usd(LS.newPmtFull) + "/mo", options: { align: "center", color: DECK.INK } }]);
      cmp.push([{ text: "Total interest", options: { bold: true, color: DECK.FOREST } }, { text: usd(LS.intSubTo), options: { align: "center", color: DECK.FOREST } }, { text: usd(LS.intNew), options: { align: "center", color: DECK.INK } }]);
      s.addTable(cmp, { x: 0.6, y: 4.6, w: 7.6, colW: [2.6, 2.5, 2.5], fontSize: 12.5, color: DECK.INK, rowH: 0.38, valign: "middle", fill: { color: DECK.WHITE }, border: { type: "solid", color: DECK.LINE, pt: 1 } });
      const miniCard = (y, label, value, sub) => {
        s.addShape(pptx.ShapeType.roundRect, { x: 8.45, y, w: 4.28, h: 0.92, fill: { color: DECK.WHITE }, line: { color: DECK.LINE, width: 1 }, rectRadius: 0.08 });
        s.addText([
          { text: label.toUpperCase() + "   ", options: { fontSize: 10, color: "6B7A6F", bold: true } },
          { text: value, options: { fontSize: 19, color: DECK.ORANGE, bold: true } },
          { text: "\n" + sub, options: { fontSize: 9, color: "8A968C" } },
        ], { x: 8.65, y: y + 0.04, w: 3.9, h: 0.84, align: "left", valign: "middle" });
      };
      miniCard(4.6, "Monthly payment relief", usd(LS.moRelief), "lighter payment vs a new loan");
      miniCard(5.62, "Paid off sooner", LS.seasoned > 0 ? `${LS.seasoned} ${LS.seasoned === 1 ? "yr" : "yrs"}` : "—", "free & clear earlier");
      s.addText("Realized in full only if the loan is held to payoff. Estimates for buyer review.", { x: 0.6, y: 6.5, w: 12.1, h: 0.3, fontSize: 9, color: "8A968C", italic: true });
      s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.9, w: 13.333, h: 0.6, fill: { color: DECK.ORANGE } });
    }
  } catch (e) { /* loan-savings slide is optional — never block the rest of the deck */ }

  // Slide — 5-year wealth projection
  const P5 = data.projection;
  if (P5 && P5.total5 > 0) {
    s = pptx.addSlide(); header(s, "5-Year Wealth Snapshot");
    const projRows = [
      ["Equity today (below ARV)", usd(P5.startEquity)],
      ["Loan paydown (5 yrs)", usd(P5.paydown5)],
      [`Appreciation (5 yrs @ ${P5.apprRate}%/yr)`, usd(P5.appreciation5)],
      ["Cumulative cash flow (5 yrs)", usd(P5.cumCF5)],
    ];
    s.addTable(kv(projRows), { x: 0.6, y: 1.6, w: 7.9, colW: [5.4, 2.5], ...tableOpts, rowH: 0.7 });
    s.addShape(pptx.ShapeType.roundRect, { x: 8.9, y: 1.6, w: 3.8, h: 2.8, fill: { color: DECK.FOREST }, rectRadius: 0.1 });
    s.addText([
      { text: "TOTAL 5-YEAR VALUE\n", options: { fontSize: 13, color: DECK.SAGE, bold: true } },
      { text: usd(P5.total5), options: { fontSize: 30, color: DECK.WHITE, bold: true } },
    ], { x: 8.9, y: 2.2, w: 3.8, h: 1.6, align: "center", valign: "middle" });
    s.addText("Equity build + paydown + modest appreciation + cash flow. Appreciation is an assumption, not a guarantee.", { x: 0.6, y: 6.6, w: 12.1, h: 0.5, fontSize: 10, color: "8A968C", italic: true });
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 7.2, w: 13.333, h: 0.3, fill: { color: DECK.ORANGE } });
  }

  // Slide — CTA / contact
  s = pptx.addSlide();
  s.background = { color: DECK.FOREST };
  addLogo(s, 5.45, 0.7, 2.45);
  s.addText("Want this deal? Let's talk.", { x: 0.6, y: 2.35, w: 12.1, h: 0.8, fontSize: 34, color: DECK.WHITE, bold: true, align: "center" });

  const c = data.contact || {};
  let cy = 3.35;
  if (c.name) { s.addText(c.name, { x: 0.6, y: cy, w: 12.1, h: 0.45, fontSize: 20, color: DECK.SAGE, bold: true, align: "center" }); cy += 0.55; }

  s.addText([
    { text: "✉  ", options: { color: DECK.SAGE } },
    { text: YLHB.email, options: { color: DECK.WHITE, hyperlink: { url: `mailto:${YLHB.email}` } } },
  ], { x: 0.6, y: cy, w: 12.1, h: 0.45, fontSize: 18, align: "center" });
  cy += 0.5;
  s.addText([
    { text: "✆  ", options: { color: DECK.SAGE } },
    { text: c.phone || YLHB.phone, options: { color: DECK.WHITE, hyperlink: { url: `tel:${YLHB.phoneRaw}` } } },
  ], { x: 0.6, y: cy, w: 12.1, h: 0.45, fontSize: 18, align: "center" });
  cy += 0.5;
  s.addText([
    { text: "⌂  ", options: { color: DECK.SAGE } },
    { text: YLHB.site, options: { color: DECK.WHITE, bold: true, hyperlink: { url: YLHB.siteUrl } } },
  ], { x: 0.6, y: cy, w: 12.1, h: 0.45, fontSize: 18, align: "center" });

  s.addText("We work a short buyers list and move quickly — reach out to lock this one up.", { x: 0.6, y: cy + 0.7, w: 12.1, h: 0.5, fontSize: 14, color: DECK.SAGE, align: "center", italic: true });
  s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.9, w: 13.333, h: 0.6, fill: { color: DECK.ORANGE } });
  const safe = (data.address || "deal").replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").slice(0, 40);
  await pptx.writeFile({ fileName: `YLHB-${safe || "deal"}.pptx` });
}

// Dual-exit deck: shows the SAME deal as both a Fix & Flip and a BRRRR hold, so the buyer picks their lane.
async function generateDualDeck(data) {
  const PptxGenJS = await loadPptx();
  const logo = await getLogoData();
  const pptx = new PptxGenJS();
  pptx.defineLayout({ name: "W", width: 13.333, height: 7.5 });
  pptx.layout = "W";
  pptx.author = "Your Local Home Buyer";
  pptx.company = "Your Local Home Buyer";
  const addLogo = (s, x, y, w) => { if (logo) s.addImage({ data: logo, x, y, w, h: w * 0.59 }); };
  const header = (slide, title) => {
    slide.background = { color: DECK.PAPER };
    slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 13.333, h: 1.1, fill: { color: DECK.FOREST } });
    slide.addText(title, { x: 0.6, y: 0.28, w: 10.4, h: 0.6, fontSize: 26, color: DECK.WHITE, bold: true });
    addLogo(slide, 11.3, 0.2, 1.45);
  };
  const kv = (rows) => rows.map((r) => [{ text: r[0], options: { bold: true, color: DECK.FOREST } }, { text: r[1], options: { align: "right", color: DECK.INK } }]);
  const tableOpts = { fontSize: 14, color: DECK.INK, rowH: 0.55, valign: "middle", fill: { color: DECK.WHITE }, border: { type: "solid", color: DECK.LINE, pt: 1 } };
  const bullets = (arr, accent) => (arr || []).filter(Boolean).map((t) => ({ text: t, options: { bullet: { code: "2022", indent: 14 }, fontSize: 13, color: DECK.INK, paraSpaceAfter: 7 } }));

  // Slide 1 — cover
  let s = pptx.addSlide();
  const headline = "Two ways to win — Fix & Flip or BRRRR";
  if (data.photo) {
    s.background = { color: DECK.INK };
    try { s.addImage({ data: data.photo, x: 0, y: 0, w: 13.333, h: 5.1, sizing: { type: "cover", w: 13.333, h: 5.1 } }); } catch {}
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 5.1, w: 13.333, h: 2.4, fill: { color: DECK.FOREST } });
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 7.35, w: 13.333, h: 0.15, fill: { color: DECK.ORANGE } });
    addLogo(s, 11.1, 5.32, 1.6);
    s.addText("INVESTMENT OPPORTUNITY", { x: 0.6, y: 5.3, w: 10, h: 0.4, fontSize: 14, color: DECK.SAGE, bold: true, charSpacing: 3 });
    s.addText(data.address || "Property address", { x: 0.6, y: 5.7, w: 10.3, h: 0.9, fontSize: 30, color: DECK.WHITE, bold: true });
    s.addText(headline, { x: 0.6, y: 6.7, w: 11, h: 0.5, fontSize: 16, color: DECK.SAGE });
  } else {
    s.background = { color: DECK.FOREST };
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.7, w: 13.333, h: 0.8, fill: { color: DECK.ORANGE } });
    addLogo(s, 0.6, 0.5, 2.3);
    s.addText("INVESTMENT OPPORTUNITY", { x: 0.6, y: 2.5, w: 12.1, h: 0.5, fontSize: 16, color: DECK.SAGE, bold: true, charSpacing: 3 });
    s.addText(data.address || "Property address", { x: 0.6, y: 3.0, w: 12.1, h: 1.2, fontSize: 38, color: DECK.WHITE, bold: true });
    s.addText(headline, { x: 0.6, y: 4.35, w: 12.1, h: 0.6, fontSize: 18, color: DECK.SAGE });
  }

  // Slide 2 — property
  s = pptx.addSlide(); header(s, "The Property");
  const propRows = [["Address", data.address || "—"]];
  if (data.subjectLine) propRows.push(["Property", data.subjectLine]);
  propRows.push(["After-Repair Value (ARV)", data.arv ? usd(data.arv) : "—"]);
  propRows.push(["Estimated rehab", data.repairs ? usd(data.repairs) : "—"]);
  propRows.push([data.priceLabel || "Purchase price", data.asking ? usd(data.asking) : "—"]);
  propRows.push(["Estimated rent", data.rent ? usd(data.rent) + "/mo" : "—"]);
  s.addTable(kv(propRows), { x: 0.6, y: 1.5, w: 12.1, colW: [4.2, 7.9], ...tableOpts, rowH: 0.6, fontSize: 15 });
  s.addText("Estimates for buyer review. Buyer to verify all figures, condition, and terms independently.", { x: 0.6, y: 6.9, w: 12.1, h: 0.4, fontSize: 9, color: "8A968C", italic: true });

  // Slide 3 — two ways to win (the hero comparison)
  s = pptx.addSlide(); header(s, "Two ways to win");
  // Flip card
  s.addShape(pptx.ShapeType.roundRect, { x: 0.6, y: 1.45, w: 5.9, h: 4.9, fill: { color: DECK.WHITE }, line: { color: DECK.ORANGE, width: 2 }, rectRadius: 0.1 });
  s.addText("OPTION A — FIX & FLIP", { x: 0.85, y: 1.7, w: 5.4, h: 0.4, fontSize: 15, color: DECK.ORANGE, bold: true });
  s.addText([{ text: "Profit potential\n", options: { fontSize: 12, color: "6B7A6F" } }, { text: data.flip.profitStr, options: { fontSize: 30, color: DECK.INK, bold: true } }], { x: 0.85, y: 2.15, w: 5.4, h: 1.1, valign: "top" });
  s.addText(bullets(data.flip.bullets), { x: 0.95, y: 3.35, w: 5.3, h: 2.85, valign: "top" });
  // BRRRR card
  s.addShape(pptx.ShapeType.roundRect, { x: 6.85, y: 1.45, w: 5.9, h: 4.9, fill: { color: DECK.WHITE }, line: { color: DECK.FOREST, width: 2 }, rectRadius: 0.1 });
  s.addText("OPTION B — BRRRR (HOLD)", { x: 7.1, y: 1.7, w: 5.4, h: 0.4, fontSize: 15, color: DECK.FOREST, bold: true });
  s.addText([{ text: "Cash flow & DSCR\n", options: { fontSize: 12, color: "6B7A6F" } }, { text: data.brrrr.headlineStr + "\n", options: { fontSize: 24, color: DECK.FOREST, bold: true } }, { text: data.brrrr.returnStr, options: { fontSize: 13.5, color: DECK.INK, bold: true } }], { x: 7.1, y: 2.15, w: 5.4, h: 1.5, valign: "top" });
  s.addText(bullets(data.brrrr.bullets), { x: 7.2, y: 3.7, w: 5.3, h: 2.5, valign: "top" });
  s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.9, w: 13.333, h: 0.6, fill: { color: DECK.ORANGE } });

  // Slide 4 — Option A detail (flip)
  s = pptx.addSlide(); header(s, "Option A — Fix & Flip");
  s.addTable(kv(data.flip.rows), { x: 0.6, y: 1.5, w: 7.9, colW: [5.1, 2.8], ...tableOpts });
  s.addShape(pptx.ShapeType.roundRect, { x: 8.9, y: 1.5, w: 3.8, h: 2.4, fill: { color: DECK.ORANGE }, rectRadius: 0.1 });
  s.addText([{ text: "PROFIT POTENTIAL\n", options: { fontSize: 13, color: DECK.WHITE, bold: true } }, { text: data.flip.profitStr, options: { fontSize: 32, color: DECK.WHITE, bold: true } }], { x: 8.9, y: 1.95, w: 3.8, h: 1.5, align: "center", valign: "middle" });
  if (data.flip.note) s.addText(data.flip.note, { x: 8.9, y: 4.05, w: 3.8, h: 2.2, fontSize: 12, color: DECK.INK, align: "center" });

  // Slide 5 — Option B detail (BRRRR)
  s = pptx.addSlide(); header(s, "Option B — BRRRR (Hold)");
  s.addTable(kv(data.brrrr.rows), { x: 0.6, y: 1.5, w: 7.9, colW: [5.1, 2.8], ...tableOpts, rowH: 0.5 });
  s.addText("PITIA = principal, interest, taxes, insurance & HOA — the all-in monthly payment on the new loan.", { x: 0.6, y: 1.5 + data.brrrr.rows.length * 0.5 + 0.15, w: 7.9, h: 0.5, fontSize: 11, color: "6B7A6F", italic: true });
  s.addShape(pptx.ShapeType.roundRect, { x: 8.9, y: 1.5, w: 3.8, h: 2.4, fill: { color: DECK.FOREST }, rectRadius: 0.1 });
  s.addText([{ text: "CASH-ON-CASH\n", options: { fontSize: 13, color: DECK.SAGE, bold: true } }, { text: data.brrrr.cocStr, options: { fontSize: 32, color: DECK.WHITE, bold: true } }], { x: 8.9, y: 1.95, w: 3.8, h: 1.5, align: "center", valign: "middle" });
  if (data.brrrr.note) s.addText(data.brrrr.note, { x: 8.9, y: 4.05, w: 3.8, h: 2.2, fontSize: 12, color: DECK.INK, align: "center" });

  // Slide 6 — 5-year wealth (BRRRR)
  const P5 = data.brrrr.projection;
  if (P5 && P5.total5 > 0) {
    s = pptx.addSlide(); header(s, "BRRRR — 5-Year Wealth Snapshot");
    const projRows = [
      ["Equity after rehab (below ARV)", usd(P5.startEquity)],
      ["Loan paydown (5 yrs)", usd(P5.paydown5)],
      [`Appreciation (5 yrs @ ${P5.apprRate}%/yr)`, usd(P5.appreciation5)],
      ["Cumulative cash flow (5 yrs)", usd(P5.cumCF5)],
    ];
    s.addTable(kv(projRows), { x: 0.6, y: 1.6, w: 7.9, colW: [5.4, 2.5], ...tableOpts, rowH: 0.7, fontSize: 15 });
    s.addShape(pptx.ShapeType.roundRect, { x: 8.9, y: 1.6, w: 3.8, h: 2.8, fill: { color: DECK.FOREST }, rectRadius: 0.1 });
    s.addText([{ text: "TOTAL 5-YEAR VALUE\n", options: { fontSize: 13, color: DECK.SAGE, bold: true } }, { text: usd(P5.total5), options: { fontSize: 30, color: DECK.WHITE, bold: true } }], { x: 8.9, y: 2.2, w: 3.8, h: 1.6, align: "center", valign: "middle" });
    s.addText("Equity build + paydown + modest appreciation + cash flow. Appreciation is an assumption, not a guarantee.", { x: 0.6, y: 6.6, w: 12.1, h: 0.5, fontSize: 10, color: "8A968C", italic: true });
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 7.2, w: 13.333, h: 0.3, fill: { color: DECK.ORANGE } });
  }

  // Slide 7 — How the returns grow (1–30 yr chart)
  const CV = data.brrrr.curve;
  if (CV && CV.series && CV.series.length && CV.series[CV.series.length - 1].total > 0) {
    s = pptx.addSlide(); header(s, "How the returns grow — year 1 to 30");
    const labels = CV.series.map((p) => String(p.year));
    const values = CV.series.map((p) => Math.round(p.total));
    s.addChart(pptx.ChartType.line, [{ name: "Total return ($)", labels, values }], {
      x: 0.6, y: 1.4, w: 12.1, h: 3.55, showLegend: false, showTitle: false,
      lineSize: 3, lineSmooth: true, color: DECK.FOREST, chartColors: [DECK.FOREST],
      catAxisTitle: "Years held", showCatAxisTitle: true, catAxisTitleColor: "5A6B5E", catAxisTitleFontSize: 11,
      valAxisTitle: "Total return ($)", showValAxisTitle: true, valAxisTitleColor: "5A6B5E", valAxisTitleFontSize: 11,
      catAxisLabelFontSize: 9, valAxisLabelFontSize: 9, valAxisLabelColor: "5A6B5E", catAxisLabelColor: "5A6B5E",
    });
    const ms = CV.milestones;
    const headRow = [{ text: "Years held", options: { bold: true, color: DECK.WHITE, fill: { color: DECK.FOREST }, align: "left", fontSize: 12 } },
      ...ms.map((m) => ({ text: String(m.year), options: { bold: true, color: DECK.WHITE, fill: { color: DECK.FOREST }, align: "center", fontSize: 12 } }))];
    const totalRow = [{ text: "Total return", options: { bold: true, color: DECK.INK, align: "left", fontSize: 12 } },
      ...ms.map((m) => ({ text: usd(m.total), options: { color: DECK.INK, align: "center", fontSize: 12 } }))];
    const rows = [headRow, totalRow];
    if (CV.cashToClose > 0) {
      rows.push([{ text: "Return on cash in", options: { bold: true, color: DECK.INK, align: "left", fontSize: 12 } },
        ...ms.map((m) => ({ text: (m.total / CV.cashToClose).toFixed(1) + "x", options: { bold: true, color: DECK.ORANGE, align: "center", fontSize: 12 } }))]);
    }
    const colRest = (12.1 - 2.7) / ms.length;
    s.addTable(rows, { x: 0.6, y: 5.15, w: 12.1, colW: [2.7, ...ms.map(() => colRest)], rowH: 0.46, valign: "middle", border: { type: "solid", color: DECK.LINE, pt: 0.5 } });
    s.addText("Total return = equity captured + loan paydown + cash flow + appreciation at 3%/yr. Appreciation is an assumption, not a guarantee.", { x: 0.6, y: 6.95, w: 12.1, h: 0.4, fontSize: 9, color: "8A968C", italic: true });
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 7.2, w: 13.333, h: 0.3, fill: { color: DECK.ORANGE } });
  }

  // Slide 8 — CTA
  s = pptx.addSlide();
  s.background = { color: DECK.FOREST };
  addLogo(s, 5.45, 0.7, 2.45);
  s.addText("Flip it or hold it — either way, let's talk.", { x: 0.6, y: 2.35, w: 12.1, h: 0.8, fontSize: 30, color: DECK.WHITE, bold: true, align: "center" });
  const c = data.contact || {};
  let cy = 3.35;
  if (c.name) { s.addText(c.name, { x: 0.6, y: cy, w: 12.1, h: 0.45, fontSize: 20, color: DECK.SAGE, bold: true, align: "center" }); cy += 0.55; }
  s.addText([{ text: "✉  ", options: { color: DECK.SAGE } }, { text: YLHB.email, options: { color: DECK.WHITE, hyperlink: { url: `mailto:${YLHB.email}` } } }], { x: 0.6, y: cy, w: 12.1, h: 0.45, fontSize: 18, align: "center" }); cy += 0.5;
  s.addText([{ text: "✆  ", options: { color: DECK.SAGE } }, { text: c.phone || YLHB.phone, options: { color: DECK.WHITE, hyperlink: { url: `tel:${YLHB.phoneRaw}` } } }], { x: 0.6, y: cy, w: 12.1, h: 0.45, fontSize: 18, align: "center" }); cy += 0.5;
  s.addText([{ text: "⌂  ", options: { color: DECK.SAGE } }, { text: YLHB.site, options: { color: DECK.WHITE, bold: true, hyperlink: { url: YLHB.siteUrl } } }], { x: 0.6, y: cy, w: 12.1, h: 0.45, fontSize: 18, align: "center" });
  s.addText("We work a short buyers list and move quickly — reach out to lock this one up.", { x: 0.6, y: cy + 0.7, w: 12.1, h: 0.5, fontSize: 14, color: DECK.SAGE, align: "center", italic: true });
  s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.9, w: 13.333, h: 0.6, fill: { color: DECK.ORANGE } });

  const safe = (data.address || "deal").replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").slice(0, 40);
  await pptx.writeFile({ fileName: `YLHB-${safe || "deal"}-flip-brrrr.pptx` });
}

// Strip the leading house/street number from an address so buyer decks show street + city only (protects the exact property; the calculator's comp/search still use the full address).
const stripHouseNum = (a) => String(a || "").replace(/^\s*\d[\w-]*\s+/, "");

function BuyerDeckButton({ deal, common, generateOverride, label, priceLabel = "Purchase price" }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [photo, setPhoto] = useState(null); // data URL of uploaded property photo
  const [f, setF] = useState({
    address: stripHouseNum(common.address) || "",
    contract: common.contractDefault ? String(Math.round(common.contractDefault + (common.fee || 0))) : "",
    rent: common.rent ? String(Math.round(common.rent)) : "",
    name: "", phone: "", email: "",
  });
  const set = (k) => (e) => setF((p) => ({ ...p, [k]: e.target?.value ?? e }));
  const missing = ["address", "contract", "rent"].filter((k) => !String(f[k]).trim());

  function onPhoto(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { alert("Please choose an image file (JPG or PNG)."); return; }
    const r = new FileReader();
    r.onload = () => setPhoto(String(r.result));
    r.readAsDataURL(file);
  }

  async function go() {
    if (missing.length) return;
    setBusy(true);
    const buyerPrice = num(f.contract);  // field already holds contract + your fee (buyer's all-in)
    try {
      if (generateOverride) {
        await generateOverride({ address: f.address, asking: buyerPrice, rent: num(f.rent), photo, contact: { name: f.name, phone: f.phone, email: f.email } });
        setOpen(false);
        return;
      }
      await generateBuyerDeck({
        dealType: deal.type,
        address: f.address,
        subjectLine: common.subjectLine,
        arv: common.arv,
        repairs: common.repairs,
        asking: buyerPrice,
        priceLabel,
        rent: num(f.rent),
        photo,
        headline: deal.headline,
        dealRows: deal.rows,
        totalLabel: deal.totalLabel,
        totalValue: deal.totalValue,
        verdict: deal.verdict,
        highlights: deal.highlights,
        returns: deal.returns,
        projection: deal.projection,
        loanSavings: deal.loanSavings,
        basis: { compCount: common.compCount, avgPpsf: common.avgPpsf, rent: num(f.rent) },
        exits: deal.exits,
        contact: { name: f.name, phone: f.phone, email: f.email },
      });
      setOpen(false);
    } catch (e) {
      alert("Couldn't generate the deck: " + (e?.message || e));
    } finally {
      setBusy(false);
    }
  }

  const req = (k, label, money) => (
    <div>
      <label className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{label} <span className="text-rose-500">*</span></label>
      <div className={`mt-1 flex items-center rounded-lg border bg-white px-3 py-2 ${!String(f[k]).trim() ? "border-rose-300" : "border-slate-200"}`}>
        {money && <span className="mr-1 text-slate-400">$</span>}
        <input value={f[k]} onChange={set(k)} className="w-full text-sm outline-none" placeholder={label} />
      </div>
    </div>
  );

  return (
    <>
      <button onClick={() => { setF((p) => ({ ...p, address: stripHouseNum(common.address) || p.address, contract: common.contractDefault ? String(Math.round(common.contractDefault + (common.fee || 0))) : p.contract, rent: common.rent ? String(Math.round(common.rent)) : p.rent })); setOpen(true); }}
        className="flex w-full items-center justify-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-700 hover:bg-emerald-100">
        <FileDown className="h-4 w-4" /> {label || `Download buyer deck (.pptx) — ${deal.type}`}
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => !busy && setOpen(false)}>
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-1 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800">{label || `Buyer deck — ${deal.type}`}</h3>
              <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-slate-600"><X className="h-5 w-5" /></button>
            </div>
            <p className="mb-4 text-[12px] text-slate-500">Confirm the details for the slides. Fields marked <span className="text-rose-500">*</span> are required.</p>
            <div className="space-y-3">
              {req("address", "Property address")}
              <div className="grid grid-cols-2 gap-3">
                {req("contract", `${priceLabel}${num(common.fee) > 0 ? " (incl. fee)" : ""}`, true)}
                {req("rent", "Monthly rent", true)}
              </div>
              {num(common.fee) > 0 && <div className="-mt-1 text-[10px] text-slate-400">{priceLabel} includes your {usd(num(common.fee))} wholesale fee — what the buyer pays. Edit if needed.</div>}
              <div className="border-t border-slate-100 pt-3">
                <div className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Property photo for the cover (optional)</div>
                {photo ? (
                  <div className="flex items-center gap-3">
                    <img src={photo} alt="cover" className="h-16 w-24 rounded-md object-cover" />
                    <button onClick={() => setPhoto(null)} className="text-[12px] font-semibold text-rose-500 hover:underline">Remove</button>
                  </div>
                ) : (
                  <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-slate-300 px-3 py-3 text-[12px] font-semibold text-slate-500 hover:bg-slate-50">
                    <FileDown className="h-4 w-4" /> Choose a photo (JPG/PNG)
                    <input type="file" accept="image/*" onChange={onPhoto} className="hidden" />
                  </label>
                )}
                <div className="mt-1 text-[10px] text-slate-400">No photo? The cover falls back to a clean branded YLHB title card with the address.</div>
              </div>
              <div className="border-t border-slate-100 pt-3">
                <div className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Contact for the CTA slide (optional)</div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <input value={f.name} onChange={set("name")} placeholder="Name" className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none" />
                  <input value={f.phone} onChange={set("phone")} placeholder="Phone" className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none" />
                  <input value={f.email} onChange={set("email")} placeholder="Email" className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none" />
                </div>
              </div>
            </div>
            {missing.length > 0 && <div className="mt-3 text-[11px] text-rose-500">Fill in: {missing.map((m) => ({ address: "address", contract: "purchase price", rent: "monthly rent" }[m])).join(", ")}.</div>}
            <button onClick={go} disabled={busy || missing.length > 0}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-700 disabled:opacity-50">
              {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Building deck…</> : <><FileDown className="h-4 w-4" /> Generate PowerPoint</>}
            </button>
          </div>
        </div>
      )}
    </>
  );
}

// ---------- shared: per-tab explainer + free learning links ----------
const PACE_CHANNEL = "https://www.youtube.com/channel/UCRkUNGepO8YnTFHSj7urWsQ";
const ytSearch = (q) => `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`;

const EDU = {
  cash: {
    title: "Cash / MAO (wholesaling)",
    what: "A straight cash play. You lock the property under contract at a low enough price that a cash buyer can fix it and flip it — and you pocket the difference as an assignment fee, or buy it yourself.",
    how: "Start from the ARV (what it's worth fixed up), take 75–80% of it (the band), then subtract repairs and your fee. That's your Max Allowable Offer — the most you can pay and still leave meat on the bone for the next buyer.",
    analogy: "Like buying wholesale to resell at retail — your profit is baked in at the buy.",
    videos: [{ label: "Wholesaling basics", q: "pace morby wholesaling for beginners" }, { label: "How to calculate MAO", q: "pace morby maximum allowable offer ARV" }],
  },
  subto: {
    title: "Subject-To (Sub-To)",
    what: "You buy the house but leave the seller's existing mortgage in place — you take over their payments, while the loan stays in their name. You get the deed; they get out from under the debt.",
    how: "Gold when the seller has a low locked-in interest rate. You inherit that cheap payment (PITI), cover any back payments, and maybe hand the seller a little cash for their equity. Your money is made on the gap between the rent and that low inherited payment.",
    analogy: "Like taking over someone's gym membership at last year's rate instead of signing up at today's higher price.",
    videos: [{ label: "Subject-To explained", q: "pace morby subject to explained" }, { label: "Sub-To from start to finish", q: "pace morby subject to deal walkthrough" }],
  },
  hybrid: {
    title: "Hybrid (Sub-To + Seller Note)",
    what: "A combo deal: you take over the existing low-rate loan subject-to, AND the seller carries a second note for their equity on top.",
    how: "The cheap first loan stays in place. The gap between the price and that loan (minus your down) becomes a seller-financed note — often at 0%. You end up with two payments: one cheap and inherited, one to the seller. It gets deals done when the seller needs more than just debt relief.",
    analogy: "Sub-To handles the bank's loan; the seller note handles the seller's equity — best of both.",
    videos: [{ label: "Hybrid deals explained", q: "pace morby hybrid subject to seller carry explained" }, { label: "Combining sub-to + seller finance", q: "pace morby subto seller finance combo" }],
  },
  sf: {
    title: "Seller Financing",
    what: "The seller becomes the bank. Instead of paying a mortgage company, you make payments straight to the seller over time, on terms the two of you agree to.",
    how: "You negotiate the price, down payment, interest rate (often 0% in trade for a higher price), how long it amortizes, and whether there's a balloon. No bank, no qualifying. Works best when the seller owns the home free-and-clear.",
    analogy: "Like a payment plan made directly with the owner — they hold the note, you hold the keys.",
    videos: [{ label: "Seller finance explained", q: "pace morby seller finance explained" }, { label: "Structuring 0% seller finance", q: "pace morby zero percent seller financing" }],
  },
  nov: {
    title: "Novation",
    what: "An agreement that lets you improve and re-sell the seller's home for more — you keep the spread between what you promised them and what it sells for, without ever taking title.",
    how: "You list the (often fixed-up) house at ARV. The buyer's price, minus selling/closing costs, minus your profit, sets the max you can offer the seller. You're not buying it to hold — you're adding value and capturing the resale spread.",
    analogy: "Like a consignment deal: you don't own it, you just make it worth more and take a cut of the upside.",
    videos: [{ label: "Novation agreements", q: "pace morby novation agreement real estate" }, { label: "Novation vs wholesaling", q: "pace morby novation vs wholesale" }],
  },
  rental: {
    title: "Rental (Buy-and-Hold + the 1% rule)",
    what: "Buying a property to keep as a long-term rental for cash flow and appreciation. The 1% rule is a quick screen: the monthly rent should be at least 1% of the purchase price.",
    how: "Estimate the rent, then divide by your target percentage to get the highest price that still pencils. It's a fast filter to spot cash-flowing deals — but it ignores taxes, insurance, vacancy, and management, so always underwrite the real numbers before you commit.",
    analogy: "The 1% rule is a metal detector, not a shovel — it tells you where to dig, not that there's treasure.",
    videos: [{ label: "Buy-and-hold rentals", q: "pace morby buy and hold rental" }, { label: "The 1% rule explained", q: "1 percent rule rental property explained" }],
  },
};

function TabEducation({ id }) {
  const e = EDU[id];
  if (!e) return null;
  return (
    <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50/50 p-4">
      <div className="mb-2 flex items-center gap-2">
        <Info className="h-4 w-4 text-emerald-500" />
        <h3 className="text-sm font-bold text-slate-700">What is {e.title}?</h3>
      </div>
      <p className="text-[13px] leading-relaxed text-slate-600">{e.what}</p>
      <p className="mt-2 text-[13px] leading-relaxed text-slate-600"><b className="font-semibold text-slate-700">How it works:</b> {e.how}</p>
      {e.analogy && (
        <p className="mt-2 rounded-lg bg-white px-3 py-2 text-[12px] italic leading-relaxed text-slate-500">💡 {e.analogy}</p>
      )}
      <div className="mt-3">
        <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Learn more — free Pace Morby videos</div>
        <div className="mt-1.5 flex flex-wrap gap-2">
          {e.videos.map((v, k) => (
            <a key={k} href={ytSearch(v.q)} target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-semibold text-slate-600 hover:border-rose-300 hover:text-rose-600">
              <Play className="h-3 w-3 text-rose-500" /> {v.label} <ExternalLink className="h-2.5 w-2.5 text-slate-300" />
            </a>
          ))}
          <a href={PACE_CHANNEL} target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-semibold text-slate-500 hover:bg-slate-50">
            Pace Morby's channel <ExternalLink className="h-2.5 w-2.5 text-slate-300" />
          </a>
        </div>
        <div className="mt-1.5 text-[10px] text-slate-400">Links open a YouTube search of Pace Morby's content on the topic — always current, never a dead link.</div>
      </div>
    </div>
  );
}

// ---------- CASH ----------
function CashTab(props) {
  const { arv, repairs, underPct, overPct, isOver, ruleMaoUnder, ruleMaoOver, investorMaoUnder, investorMaoOver, itemizedMao, activeInvestorMao, activeRuleMao, activePct, wholesaleFee, setWholesaleFee, sellingPct, setSellingPct, holding, setHolding, desiredProfit, setDesiredProfit, askingPrice, setAskingPrice, rentOverride, setRentOverride, rentDefault, deckCommon, onGenerateRent, rentLoading, rentMsg, hasAddress } = props;
  const ask = num(askingPrice);
  let status = "maybe", headline = "Enter an asking price to grade the deal", detail = "";
  if (ask > 0 && arv > 0) {
    const spread = activeInvestorMao - ask;
    if (ask <= activeInvestorMao) {
      status = "go"; headline = "WHOLESALE — lock it";
      detail = `At ${usd(ask)} you're under your MAO with ~${usd(spread)} of room above your fee (${activePct}% band).`;
    } else if (ask <= activeRuleMao) {
      status = "maybe"; headline = "FLIP margin — thin for an assignment";
      detail = `Works as a flip at the ${activePct}% rule, but ${usd(ask - activeInvestorMao)} over your wholesale MAO. Renegotiate or shrink the fee.`;
    } else {
      status = "no"; headline = "PASS / renegotiate";
      detail = `Asking is ${usd(ask - activeRuleMao)} above even the ${activePct}% MAO. Numbers don't work at this price.`;
    }
  }
  return (
    <div className="space-y-4">
      {/* INPUTS: your wholesale numbers (full width) */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <SectionTitle>Your wholesale numbers</SectionTitle>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Your wholesale fee" info="Your assignment fee — the spread YOU keep for putting the deal together. Subtracted to get your MAO (Max Allowable Offer), and added on top for the buyer's all-in on the deck."><MoneyInput value={wholesaleFee} onChange={setWholesaleFee} /></Field>
          <Field label="Seller asking price" hint="negotiations & final contract price" info="One price for both jobs: it grades the deal while you negotiate, and prints on the buyer deck as your contract price (plus your wholesale fee). Just update it to your locked number once you're under contract."><MoneyInput value={askingPrice} onChange={setAskingPrice} /></Field>
        </div>
      </div>

      {/* VERDICT */}
      <Verdict status={status} headline={headline} detail={detail} />

      {/* RESULTS: MAO table + stat cards */}
      <div className="grid gap-4 md:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm overflow-x-auto">
          <SectionTitle>Max Allowable Offer — both bands</SectionTitle>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[11px] uppercase tracking-wide text-slate-400">
                <th className="py-1 text-left font-semibold"></th>
                <th className={`py-1 text-right font-semibold ${!isOver ? "text-emerald-600" : ""}`}>Under $200k ({underPct}%)</th>
                <th className={`py-1 text-right font-semibold ${isOver ? "text-emerald-600" : ""}`}>Over $200k ({overPct}%)</th>
              </tr>
            </thead>
            <tbody className="font-mono tabular-nums">
              <CRow label="% of ARV" a={usd(arv * underPct / 100)} b={usd(arv * overPct / 100)} />
              <CRow label="− Repairs" a={usd(repairs)} b={usd(repairs)} />
              <CRow label="= Wholesale price" a={usd(ruleMaoUnder)} b={usd(ruleMaoOver)} muted />
              <CRow label="− Your fee" a={usd(num(wholesaleFee))} b={usd(num(wholesaleFee))} />
              <tr className="border-t-2 border-slate-200">
                <td className="py-2 font-sans text-[11px] font-bold uppercase tracking-wide text-slate-500">MAO (Max Allowable Offer)</td>
                <td className={`py-2 text-right text-base font-bold ${!isOver ? "text-emerald-600" : "text-slate-900"}`}>{usd(investorMaoUnder)}</td>
                <td className={`py-2 text-right text-base font-bold ${isOver ? "text-emerald-600" : "text-slate-900"}`}>{usd(investorMaoOver)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <Stat label={`${activePct}% Rule MAO`} value={usd(activeRuleMao)} tone={activeRuleMao > 0 ? "default" : "bad"} big sub="ARV × band − repairs" />
          <Stat label="MAO (Max Allowable Offer)" value={usd(activeInvestorMao)} tone={activeInvestorMao > 0 ? "good" : "bad"} big sub="after your fee" />
          <Stat label="ARV" value={usd(arv)} sub={`repairs ${usd(repairs)}`} />
        </div>
      </div>

      {/* OPTIONAL — Itemized max offer: the flipper's inputs and the resulting number sit together so the cause/effect is obvious */}
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50/60 p-4 shadow-sm">
        <div className="flex items-start gap-2">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">Itemized max offer</span>
              <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-amber-700">Optional</span>
            </div>
            <p className="mt-0.5 text-[11px] leading-snug text-slate-500">
              A second, optional way to find your max offer — back into it from your <b className="font-semibold text-slate-600">end buyer's</b> costs and target profit (the investor who buys this from you and flips it — <b className="font-semibold text-slate-600">not you</b>). You don't have to fill this in — the Rule and MAO (Max Allowable Offer) above already work. When you do, the number on the right updates the instant you change a field on the left.
            </p>
          </div>
        </div>
        <div className="mt-3 grid items-stretch gap-4 md:grid-cols-2">
          {/* left: the flipper's inputs */}
          <div className="space-y-3">
            <Field label="Selling costs" hint="% of ARV" info="Cost to SELL the fixed-up house: agent commissions, title, closing. Roughly 8–10% of ARV."><PlainInput value={sellingPct} onChange={setSellingPct} suffix="%" /></Field>
            <Field label="Holding costs" info="Cost to OWN it during rehab and sale: loan interest, taxes, insurance, utilities. ~$3k–$8k on a typical flip."><MoneyInput value={holding} onChange={setHolding} /></Field>
            <Field label="Flipper's desired profit" hint="optional — your end buyer, not you" info="The profit the END BUYER (the investor who buys this from you and flips it) wants to clear after all their costs. This is THEIR cushion, not your wholesale fee. Commonly $25k–$40k+. Leave the default if you don't know it.">
              <MoneyInput value={desiredProfit} onChange={setDesiredProfit} />
              {num(desiredProfit) > 50000 && <div className="mt-1 flex items-start gap-1 text-[10px] font-medium text-amber-600"><span>⚠</span><span>That's high for a flip cushion — most flippers target $25k–$40k. A big number here pushes your max offer way down. Double-check this is really the buyer's number, not your wholesale fee.</span></div>}
            </Field>
          </div>
          {/* right: the live result, right next to the inputs that drive it */}
          <div className="flex flex-col justify-center rounded-xl border border-slate-200 bg-white p-5 text-center">
            <div className="text-[11px] font-bold uppercase tracking-widest text-slate-400">Itemized max offer</div>
            <div className="mt-1 text-4xl font-bold tabular-nums text-slate-900">{usd(itemizedMao)}</div>
            <div className="mt-2 text-[11px] leading-snug text-slate-500">Buy at this price or lower and the flipper still clears the profit you entered.</div>
            <div className="mt-3 text-[10px] font-medium text-amber-700">↻ Updates the instant you change the flipper's desired profit.</div>
            {(() => {
              // Buyer's ceiling: the most the END BUYER can pay all-in (contract + your fee) and still clear
              // their target profit. itemizedMao already nets out the fee, so ceiling = itemizedMao + fee.
              const fee = num(wholesaleFee);
              const asking = num(askingPrice);
              const maxAssign = itemizedMao + fee;
              const planned = asking + fee;          // what you'd actually assign it for today
              const slack = maxAssign - planned;     // = itemizedMao - asking (the fee cancels)
              const maxFee = maxAssign - asking;     // fee ceiling at the current contract price
              return (
                <div className="mt-3 w-full border-t border-slate-200 pt-3 text-left">
                  <div className="text-[11px] font-bold uppercase tracking-widest text-slate-400">Assign it for</div>
                  <div className="mt-1 font-mono text-2xl font-bold tabular-nums text-slate-900">{usd(maxAssign)} <span className="text-sm font-semibold text-slate-400">max</span></div>
                  <div className="text-[10px] leading-snug text-slate-400">The most your end buyer can pay all-in — contract price + your fee — and still clear {usd(num(desiredProfit))} on the numbers at left.</div>
                  {asking > 0 ? (
                    slack >= 0 ? (
                      <div className="mt-2 rounded-lg bg-emerald-50 px-2.5 py-1.5 text-[11px] leading-snug text-emerald-700">
                        ✓ Your plan — {usd(asking)} contract + {usd(fee)} fee = <b>{usd(planned)}</b> — works{slack === 0 ? <>, <b>exactly at the ceiling</b> (zero room)</> : <> with <b>{usd(slack)}</b> of room</>}.
                      </div>
                    ) : (
                      <div className="mt-2 rounded-lg bg-amber-50 px-2.5 py-1.5 text-[11px] leading-snug text-amber-700">
                        ⚠ Your plan — {usd(asking)} contract + {usd(fee)} fee = <b>{usd(planned)}</b> — is <b>{usd(-slack)}</b> over the ceiling. {maxFee > 0 ? <>Max fee at this contract price: <b>{usd(maxFee)}</b> — or renegotiate the price down.</> : <>Even a $0 fee doesn't work at this contract price — renegotiate the price.</>}
                      </div>
                    )
                  ) : (
                    <div className="mt-2 text-[10px] italic text-slate-400">Enter the Seller asking price up top and this checks your actual assignment against the ceiling.</div>
                  )}
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      <BrrrrPanel
        arv={arv} repairs={repairs} rentDefault={rentDefault} rentOverride={rentOverride} setRentOverride={setRentOverride} purchaseDefault={activeInvestorMao}
        askingPrice={askingPrice} wholesaleFee={wholesaleFee} deckCommon={deckCommon}
        onGenerateRent={onGenerateRent} rentLoading={rentLoading} rentMsg={rentMsg} hasAddress={hasAddress}
        flipDeck={{
          sellingCost: arv * num(sellingPct) / 100,
          holdingCost: num(holding),
          sellingPct: num(sellingPct),
        }}
      />
      <TabEducation id="cash" />
    </div>
  );
}
const CRow = ({ label, a, b, muted }) => (
  <tr className="border-t border-slate-100">
    <td className="py-1.5 font-sans text-[11px] font-semibold uppercase tracking-wide text-slate-500">{label}</td>
    <td className={`py-1.5 text-right ${muted ? "text-slate-500" : "text-slate-900"}`}>{a}</td>
    <td className={`py-1.5 text-right ${muted ? "text-slate-500" : "text-slate-900"}`}>{b}</td>
  </tr>
);

// ---------- shared: BRRRR + DSCR (the hold/refi exit) ----------
function BrrrrPanel({ arv, repairs, rentDefault, rentOverride, setRentOverride, purchaseDefault, askingPrice, wholesaleFee, deckCommon, flipDeck, onGenerateRent, rentLoading, rentMsg, hasAddress }) {
  const [purchase, setPurchase] = useState("");
  const [rehab, setRehab] = useState("");
  const [taxIns, setTaxIns] = useState("");
  const [hoa, setHoa] = useState("");
  const [ltv, setLtv] = useState("75");
  const [rate, setRate] = useState("7.5");
  const [term, setTerm] = useState("30");
  const [reservePct, setReservePct] = useState("10");

  const buy = num(purchase);                                 // no default — enter the all-in price (incl. wholesale fee)
  const ask = num(askingPrice);                              // asking / contract price (set on the Cash / MAO tab above)
  const fee = num(wholesaleFee);                             // your assignment fee — shared Cash-tab value
  const askPlusFee = ask + fee;                              // what an end buyer pays when you wholesale it
  const fix = num(rehab) > 0 ? num(rehab) : repairs;
  const rnt = num(rentDefault);                              // shared rent (Generate or manual), already = override || estimate
  const allIn = buy + fix;
  const refiLoan = arv * (num(ltv) / 100);
  const cashLeftIn = allIn - refiLoan;
  const pi = pmt(refiLoan, num(rate), num(term));
  // Estimated taxes + insurance from the ARV (editable). Based on U.S. average rates, excluding the
  // outlier states CA, NY & FL: ~0.9%/yr effective property tax + ~0.6%/yr dwelling insurance = ~1.5%/yr.
  const estTax = arv > 0 ? (arv * 0.009) / 12 : 0;
  const estIns = arv > 0 ? (arv * 0.006) / 12 : 0;
  const estTaxIns = estTax + estIns;
  const taxInsEff = num(taxIns) > 0 ? num(taxIns) : estTaxIns;
  const pitia = pi + taxInsEff + num(hoa);                 // lender's denominator
  const dscr = pitia > 0 && rnt > 0 ? rnt / pitia : 0;
  const reserves = rnt * (num(reservePct) / 100);
  const trueCF = rnt - pitia - reserves;                      // your real monthly cash flow
  const annualCF = trueCF * 12;
  const coc = cashLeftIn > 0 ? (annualCF / cashLeftIn) * 100 : null; // null = all capital recovered
  // ---- ROI metrics ----
  const noiAnnual = (rnt - taxInsEff - num(hoa) - reserves) * 12;        // operating income, before debt service
  const capRate = arv > 0 ? (noiAnnual / arv) * 100 : 0;                 // unlevered yield on the asset
  const equityCaptured = arv - allIn;                                    // instant equity from buying right + rehab
  const paydown1 = refiLoan > 0 ? refiLoan - balanceAt(refiLoan, num(rate), num(term), 1) : 0; // year-1 principal
  const totalReturn1 = annualCF + paydown1;                             // year-1 cash flow + loan paydown
  const totalRoi = cashLeftIn > 0 ? (totalReturn1 / cashLeftIn) * 100 : null; // null = all capital recovered

  let dTone = "default", dNote = "Qualifies at standard terms.";
  if (dscr <= 0) { dTone = "default"; dNote = "Enter rent + PITIA to score the refi."; }
  else if (dscr >= 1.25) { dTone = "good"; dNote = "Strong — qualifies for the best DSCR rates."; }
  else if (dscr >= 1.0) { dTone = "good"; dNote = "Qualifies with most DSCR lenders (standard terms)."; }
  else if (dscr >= 0.75) { dTone = "warn"; dNote = "Thin — needs compensating factors (bigger down, reserves, IO)."; }
  else { dTone = "bad"; dNote = "Won't cover the payment — most lenders pass below 0.75."; }

  let brrrrLine = "Fill in your buy price and refi terms to see how much capital comes back out.";
  if (arv > 0 && allIn > 0) {
    if (cashLeftIn <= 0) brrrrLine = `Full BRRRR — the ${usd(refiLoan)} refi pulls out everything you put in, plus ${usd(-cashLeftIn)} above your basis. Infinite return: all your capital recycles into the next deal.`;
    else if (cashLeftIn <= 15000) brrrrLine = `Near-full BRRRR — you'd leave just ${usd(cashLeftIn)} in the deal after the ${usd(refiLoan)} refi. Most of your capital comes back out.`;
    else brrrrLine = `Capital-heavy — ${usd(cashLeftIn)} stays trapped in the deal after refi. Push the buy price down or the rehab leaner to recover more.`;
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="mb-1 flex items-center gap-2">
        <RefreshCw className="h-4 w-4 text-emerald-500" />
        <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">BRRRR / DSCR — if you (or your buyer) hold it as a rental</h3>
      </div>
      <p className="mb-3 text-[11px] text-slate-400">Buy, rehab, rent, refinance, repeat. Refinance at the ARV, pull your capital back out, and see if it qualifies for a DSCR loan (rent ÷ PITIA).</p>

      <div className="grid gap-3 sm:grid-cols-3">
        <Field label="Purchase price (plus wholesale fee)" hint="all-in buy price" info="What the buyer actually pays to acquire it — the contract price PLUS your wholesale / assignment fee. If you're keeping it yourself, just enter your buy price (no fee to add). Enter it directly; no default.">
          <MoneyInput value={purchase} onChange={setPurchase} placeholder="Purchase price (plus wholesale fee)" />
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            <button type="button" onClick={() => setPurchase(String(Math.round(ask)))} disabled={ask <= 0}
              className="rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-[11px] font-bold text-emerald-700 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-40"
              title={ask > 0 ? "Fill with your asking / contract price — keeping it yourself, no fee to add" : "Enter a Seller asking price on the Cash / MAO tab above first"}>
              Use asking{ask > 0 ? ` · ${usd(ask)}` : ""}
            </button>
            <button type="button" onClick={() => setPurchase(String(Math.round(askPlusFee)))} disabled={ask <= 0}
              className="rounded-lg border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[11px] font-bold text-amber-700 hover:bg-amber-100 disabled:cursor-not-allowed disabled:opacity-40"
              title={ask > 0 ? `Wholesaling it — asking + your ${usd(fee)} wholesale fee, what the buyer pays` : "Enter a Seller asking price on the Cash / MAO tab above first"}>
              Asking + fee{ask > 0 ? ` · ${usd(askPlusFee)}` : ""}
            </button>
          </div>
          {ask <= 0
            ? <div className="mt-1 text-[10px] italic text-slate-400">Set a <b className="text-slate-500">Seller asking price</b> on the Cash / MAO tab above to enable these quick-fills.</div>
            : <div className="mt-1 text-[10px] text-slate-400">Tap a button to fill from your asking / contract price, or type any amount. <b className="text-slate-500">Wholesaling</b> → price + your fee (what the buyer pays). <b className="text-slate-500">Keeping it</b> → just the price.</div>}
        </Field>
        <Field label="Rehab budget" info="Defaults to the repair estimate up top."><MoneyInput value={rehab} onChange={setRehab} placeholder={repairs > 0 ? String(Math.round(repairs)) : "e.g. 30000"} /></Field>
        <Field label="Monthly rent" info="Market rent once it's fixed and leased. Pulled automatically with Auto-comp — type here to use your own number instead.">
          <MoneyInput value={rentOverride} onChange={setRentOverride} filled={num(rentDefault) > 0}
            placeholder={num(rentDefault) > 0 ? String(Math.round(num(rentDefault))) : (rentLoading ? "Pulling…" : "Type the rent")} />
          {rentMsg && rentMsg.type === "err" && <div className="mt-1 text-[10px] text-rose-600">{rentMsg.text}</div>}
          {num(rentDefault) > 0 && !rentLoading && <div className="mt-0.5 text-[10px] text-slate-400">Pulled with Auto-comp. Type to override.</div>}
          {num(rentDefault) <= 0 && !rentLoading && <div className="mt-0.5 text-[10px] text-slate-400">Run Auto-comp up top to pull this automatically, or type it.</div>}
        </Field>
        <Field label="Taxes + insurance" hint="monthly" info="Monthly property taxes + insurance — part of PITIA, the DSCR denominator. Auto-estimated from the ARV using U.S. average rates (~0.9% tax + ~0.6% insurance per year), excluding the outlier states CA, NY & FL. Type the actual to override.">
          <MoneyInput value={taxIns} onChange={setTaxIns} placeholder={estTaxIns > 0 ? String(Math.round(estTaxIns)) : "e.g. 300"} />
          {estTaxIns > 0 && (
            <div className="mt-1 text-[10px] text-slate-400">
              {num(taxIns) <= 0 ? <>Auto-estimate ~${Math.round(estTax).toLocaleString()} tax + ~${Math.round(estIns).toLocaleString()} insurance/mo. </> : null}
              <span className="italic">U.S. average rates, excludes CA/NY/FL — verify the actual for this property.</span>
            </div>
          )}
        </Field>
        <Field label="HOA" hint="monthly, if any" info="Monthly HOA / association dues, if the property has them. Also part of PITIA."><MoneyInput value={hoa} onChange={setHoa} /></Field>
        <Field label="Reserves" hint="% of rent" info="Vacancy + maintenance + management set-aside. NOT part of the lender's DSCR, but real money — used here for your true cash flow."><PlainInput value={reservePct} onChange={setReservePct} suffix="%" /></Field>
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        <Field label="Refi LTV" hint="% of ARV" info="Cash-out refinances on rentals typically max out around 70–75% of the after-repair value."><PlainInput value={ltv} onChange={setLtv} suffix="%" /></Field>
        <Field label="Refi rate" hint="%" info="DSCR loan rates run ~6–7.5% right now. Higher than owner-occupied — these are investor loans."><PlainInput value={rate} onChange={setRate} suffix="%" /></Field>
        <Field label="Refi term" hint="years" info="Almost always a 30-year amortization on DSCR loans."><PlainInput value={term} onChange={setTerm} suffix="yr" /></Field>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Refi loan" value={arv > 0 ? usd(refiLoan) : "—"} sub={`ARV × ${num(ltv)}%`} />
        <Stat label="Cash left in deal" value={arv > 0 && buy > 0 ? usd(cashLeftIn) : "—"} tone={buy > 0 ? (cashLeftIn <= 0 ? "good" : cashLeftIn <= 15000 ? "default" : "warn") : "default"} sub={cashLeftIn <= 0 ? "all capital out" : "stays in after refi"} />
        <Stat label="DSCR" value={dscr > 0 ? dscr.toFixed(2) : "—"} tone={dTone} big sub="rent ÷ PITIA" />
        <Stat label="New payment (PITIA)" value={pitia > 0 ? usd(pitia) : "—"} sub={`P&I ${usd(pi)} + tax/ins/HOA`} />
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <Stat label="Monthly cash flow" value={pitia > 0 && rnt > 0 ? usd(trueCF) : "—"} tone={trueCF > 0 ? "good" : pitia > 0 ? "bad" : "default"} sub={`after ${num(reservePct)}% reserves`} />
        <Stat label="Cash-on-cash" value={buy <= 0 ? "—" : coc === null ? "∞ (all cash out)" : annualCF !== 0 && cashLeftIn > 0 ? coc.toFixed(1) + "%" : "—"} tone={buy > 0 && (coc === null || (coc && coc > 8)) ? "good" : "default"} sub={coc === null ? "no capital left in" : "annual CF ÷ cash left in"} />
      </div>

      {/* ROI / Returns */}
      <div className="mt-4 rounded-xl border border-emerald-100 bg-emerald-50/40 p-3">
        <div className="mb-2 flex items-center gap-2">
          <TrendingDown className="h-4 w-4 rotate-180 text-emerald-500" />
          <h4 className="text-[11px] font-bold uppercase tracking-widest text-emerald-700/80">ROI / Returns</h4>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Cap rate" value={arv > 0 && rnt > 0 ? capRate.toFixed(1) + "%" : "—"} tone={capRate >= 7 ? "good" : capRate > 0 ? "default" : "default"} sub="NOI ÷ ARV (unlevered)" />
          <Stat label="Equity captured" value={arv > 0 && buy > 0 ? usd(equityCaptured) : "—"} tone={buy > 0 && equityCaptured > 0 ? "good" : buy > 0 ? "bad" : "default"} sub="ARV − all-in" />
          <Stat label="Total ROI (yr 1)" value={buy <= 0 ? "—" : totalRoi === null ? "∞ (all cash out)" : (cashLeftIn > 0 && totalReturn1 !== 0 ? totalRoi.toFixed(1) + "%" : "—")} tone={buy > 0 && (totalRoi === null || (totalRoi && totalRoi > 12)) ? "good" : "default"} sub="cash flow + paydown ÷ cash in" />
          <Stat label="Annual cash flow" value={pitia > 0 && rnt > 0 ? usd(annualCF) : "—"} tone={annualCF > 0 ? "good" : pitia > 0 ? "bad" : "default"} sub={`${usd(trueCF)}/mo × 12`} />
        </div>
        <div className="mt-2 text-[10px] text-slate-400">
          Cap rate is the unlevered yield (NOI ÷ ARV). Total ROI (yr 1) adds your first-year loan paydown to cash flow{buy > 0 && equityCaptured > 0 ? <>, on top of the <b className="text-emerald-700">{usd(equityCaptured)}</b> of equity you captured up front</> : null} — your real return on the cash left in the deal.
        </div>
      </div>

      <div className={`mt-3 rounded-lg px-3 py-2 text-[11px] ${dTone === "good" ? "bg-emerald-50 text-emerald-700" : dTone === "bad" ? "bg-rose-50 text-rose-700" : dTone === "warn" ? "bg-amber-50 text-amber-800" : "bg-slate-50 text-slate-500"}`}>
        <b>DSCR {dscr > 0 ? dscr.toFixed(2) : "—"}:</b> {dNote}
      </div>
      <div className="mt-2 rounded-lg bg-slate-50 px-3 py-2 text-[11px] text-slate-500">{brrrrLine}</div>
      <div className="mt-2 text-[10px] text-slate-400">DSCR uses gross rent ÷ PITIA (the lender's formula — no operating expenses). Your cash flow above subtracts reserves for the real picture. Verify rent, taxes, and rate with the lender before counting on it.</div>

      {deckCommon && flipDeck && (
        <div className="mt-3">
          <BuyerDeckButton
            label="Download deal deck — Flip + BRRRR (.pptx)"
            common={{ ...deckCommon, rent: rnt }}
            generateOverride={async (form) => {
              await generateDualDeck({
                address: form.address,
                subjectLine: deckCommon.subjectLine,
                arv,
                repairs,
                asking: form.asking,
                rent: form.rent,
                photo: form.photo,
                basis: { compCount: deckCommon.compCount, avgPpsf: deckCommon.avgPpsf, rent: form.rent },
                contact: form.contact,
                flip: (() => {
                  const fSell = flipDeck.sellingCost || 0;
                  const fHold = flipDeck.holdingCost || 0;
                  const fProfit = arv - buy - repairs - fSell - fHold;   // buyer's real flip profit at YOUR offer price
                  return {
                    profitStr: buy > 0 ? usd(fProfit) : "—",
                    rows: [
                      ["After-repair value (ARV)", usd(arv)],
                      ["Estimated rehab", usd(repairs)],
                      [`Selling costs (${flipDeck.sellingPct}% of ARV)`, usd(fSell)],
                      ["Holding costs", usd(fHold)],
                      ["Your purchase price", buy > 0 ? usd(buy) : "—"],
                    ],
                    bullets: [
                      buy > 0 && fProfit > 0 ? `About ${usd(fProfit)} profit at your ${usd(buy)} purchase price` : null,
                      arv > 0 ? `${usd(arv)} after-repair value` : null,
                      repairs > 0 ? `Rehab scoped at about ${usd(repairs)}` : null,
                      "Resell at retail once rehabbed",
                    ],
                    note: "",
                  };
                })(),
                brrrr: {
                  headlineStr: `${usd(trueCF)}/mo · DSCR ${dscr > 0 ? dscr.toFixed(2) : "—"}`,
                  cocStr: coc === null ? "∞" : (cashLeftIn > 0 && coc ? coc.toFixed(1) + "%" : "—"),
                  returnStr: (() => {
                    if (buy <= 0) return "";
                    if (cashLeftIn <= 0) return "∞ cash-on-cash & ROI — all cash out";
                    const parts = [];
                    if (coc) parts.push(coc.toFixed(1) + "% cash-on-cash");
                    if (totalRoi && totalReturn1 !== 0) parts.push(totalRoi.toFixed(1) + "% total ROI (yr 1)");
                    return parts.join("  ·  ");
                  })(),
                  rows: [
                    ["All-in (purchase + rehab)", usd(allIn)],
                    [`Refi loan (ARV × ${num(ltv)}%)`, usd(refiLoan)],
                    ["Loan term", `${num(term)} yr`],
                    ["Cash left in deal", cashLeftIn <= 0 ? `${usd(-cashLeftIn)} back out` : usd(cashLeftIn)],
                    ["Monthly rent", rnt > 0 ? usd(rnt) : "—"],
                    ["New payment (PITIA)", usd(pitia)],
                    [`Reserves (${num(reservePct)}% of rent)`, reserves > 0 ? usd(reserves) : "—"],
                    ["DSCR", dscr > 0 ? dscr.toFixed(2) : "—"],
                    ["Monthly cash flow", usd(trueCF)],
                  ],
                  bullets: [
                    dscr >= 1.0 ? `Qualifies for a DSCR loan at ${dscr.toFixed(2)} — no income docs` : (dscr > 0 ? `DSCR ${dscr.toFixed(2)} — may need compensating factors` : null),
                    cashLeftIn <= 0 ? "Full BRRRR — all capital comes back out at refi" : `Only ${usd(cashLeftIn)} left in after refi`,
                    trueCF > 0 ? `${usd(trueCF)}/mo cash flow after reserves` : null,
                    "Refinance, rent, and hold for long-term wealth",
                  ],
                  note: dNote,
                  ...(() => { const ex = buildDealExtras({ loanAmt: refiLoan, rate: num(rate), term: num(term), arv, equity: arv - allIn, cashFlow: trueCF, cashToClose: Math.max(0, cashLeftIn), coc: coc || 0 }); return { projection: ex.projection, curve: ex.curve }; })(),
                },
              });
            }}
          />
          <div className="mt-1 text-center text-[10px] text-slate-400">One deck, both exits — your buyer sees the flip play and the BRRRR play side by side.</div>
        </div>
      )}
    </div>
  );
}

// ---------- shared: "wholesale this creative contract" panel ----------
function WholesaleCompare({ arv, repairs, underPct, overPct, wholesaleFee, setWholesaleFee, dealCost, costLabel, financingValue = 0, buyerCashIn = 0, annualCF = 0 }) {
  const fee = num(wholesaleFee);                               // assignment fee — shared with the Cash/MAO tab's wholesale fee
  const haveDeal = arv > 0 && dealCost > 0;
  const equity = haveDeal ? arv - repairs - dealCost : 0;      // hard spread you created by locking it up creative
  const finVal = Math.max(0, financingValue || 0);             // soft value of the below-market loan (PV)
  const totalValue = equity + finVal;                          // what the deal is really worth to a creative buyer
  const buyerKeeps = totalValue - fee;                        // value the assignee inherits after paying your fee
  const buyerEquity = equity - fee;                           // hard equity the assignee inherits after your fee
  const CUSHION = 5000;                                        // a little value we want to leave the buyer
  // --- what the END BUYER earns: their cash in = this deal's cash to close + your fee ---
  const buyerTotalCashIn = Math.max(0, buyerCashIn) + fee;
  const buyerCoC = buyerTotalCashIn > 0 ? (annualCF / buyerTotalCashIn) * 100 : null;          // cash flow on their cash
  const buyerRoi = buyerTotalCashIn > 0 ? ((annualCF + buyerEquity) / buyerTotalCashIn) * 100 : null; // + equity stepped into
  const showBuyerReturns = haveDeal && buyerTotalCashIn > 0 && annualCF !== 0;

  let tone = "default", note = "Lock in the deal numbers above, then enter the assignment fee you'd charge to hand this creative contract to another investor.";
  if (arv <= 0) { note = "Set the ARV up top to see what this creative deal could assign for."; }
  else if (!haveDeal) { note = "Fill in this deal's price/basis above to see the value you've created and what it could assign for."; }
  else if (totalValue <= 0) {
    tone = "warn";
    note = `Not much to assign here — there's no equity and the rate isn't below market, so there's little value to carve a fee from. The deal would have to sell on cash flow alone.`;
  } else if (fee <= 0) {
    tone = "default";
    note = `You've created ${usd(totalValue)} of total value: ${usd(equity)} equity + ${usd(finVal)} from the below-market financing. Enter the fee you'd charge to assign it and you'll see what's left for the buyer.`;
  } else if (buyerKeeps >= CUSHION) {
    tone = "good";
    note = `Assignable — ${usd(totalValue)} of total value (${usd(equity)} equity + ${usd(finVal)} from the cheap loan). Charge your ${usd(fee)} fee and the next investor still inherits ${usd(buyerKeeps)} in value plus the cash flow. The lower the rate, the more room you have here.`;
  } else if (buyerKeeps > 0) {
    tone = "warn";
    note = `Tight — your ${usd(fee)} fee leaves the buyer only ${usd(buyerKeeps)} of value. They may still take it for the terms and cash flow, but don't get greedy or it won't move.`;
  } else {
    tone = "bad";
    note = `Your ${usd(fee)} fee is more than the ${usd(totalValue)} of total value in the deal. A buyer would be paying you for a deal with no cushion left — trim the fee to leave them room.`;
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="mb-1 flex items-center gap-2">
        <RefreshCw className="h-4 w-4 text-slate-400" />
        <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">If you wholesaled this creative contract</h3>
      </div>
      <p className="mb-3 text-[11px] text-slate-400">Assign this deal to another investor for a fee — they inherit the terms, you collect the spread. Value = equity + what the below-market loan is worth.</p>
      <div className="mb-3">
        <Field
          label="Your assignment fee"
          hint="shared across all tabs"
          info="What you'd charge another investor to take over this creative contract. This is the SAME number as 'Your wholesale fee' on the Cash / MAO tab — set it on any tab and it updates everywhere. It comes out of the total value you created — equity PLUS the present value of the below-market rate."
        >
          <MoneyInput value={wholesaleFee} onChange={setWholesaleFee} placeholder="Type your fee" />
        </Field>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Equity in the deal" value={haveDeal ? usd(equity) : "—"} tone={haveDeal ? (equity > 0 ? "good" : "warn") : "default"} sub="ARV − repairs − basis" />
        <Stat label="Financing value" value={haveDeal ? usd(finVal) : "—"} tone={finVal > 0 ? "good" : "default"} sub="PV of the low rate" />
        <Stat label="Total deal value" value={haveDeal ? usd(totalValue) : "—"} tone={totalValue > 0 ? "good" : "default"} big sub="equity + financing" />
      </div>
      {haveDeal && (
        <div className="mt-2 text-[10px] text-slate-400">"Basis" is your cost to acquire ({costLabel.toLowerCase()}) — <b>not</b> your fee. Your fee comes out of the equity, leaving the buyer the rest.</div>
      )}
      {haveDeal && fee > 0 && (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <Stat label="Buyer's equity after your fee" value={usd(buyerEquity)} tone={buyerEquity >= CUSHION ? "good" : buyerEquity > 0 ? "warn" : "bad"} sub="equity − your fee" />
          <Stat label="Buyer keeps, all-in" value={usd(buyerKeeps)} tone={buyerKeeps >= CUSHION ? "good" : buyerKeeps > 0 ? "warn" : "bad"} sub="+ financing value" />
        </div>
      )}
      {showBuyerReturns && (
        <div className="mt-3 rounded-xl border border-emerald-100 bg-emerald-50/40 p-3">
          <div className="mb-2 text-[10px] font-bold uppercase tracking-widest text-emerald-700/80">What the end buyer earns</div>
          <div className="grid gap-3 sm:grid-cols-3">
            <Stat label="Buyer's total cash in" value={usd(buyerTotalCashIn)} sub="cash to close + rehab + your fee" />
            <Stat label="Buyer cash-on-cash" value={buyerCoC === null ? "—" : pct(buyerCoC)} tone={buyerCoC !== null && buyerCoC > 0 ? "good" : "warn"} sub="annual cash flow ÷ cash in" />
            <Stat label="Buyer ROI — year 1" value={buyerRoi === null ? "—" : pct(buyerRoi)} tone={buyerRoi !== null && buyerRoi > 0 ? "good" : "warn"} sub="cash flow + equity stepped into" />
          </div>
          <div className="mt-2 text-[10px] text-slate-400">Buyer's total cash in is everything they sink in — cash to close + rehab (<b>{usd(Math.max(0, buyerCashIn))}</b>) + your <b>{usd(fee)}</b> fee. Cash-on-cash is the rent return on that full amount; ROI also counts the <b>{usd(buyerEquity)}</b> of equity they step into after your fee.</div>
        </div>
      )}
      <div className={`mt-3 rounded-lg px-3 py-2 text-[11px] ${tone === "good" ? "bg-emerald-50 text-emerald-700" : tone === "bad" ? "bg-rose-50 text-rose-700" : tone === "warn" ? "bg-amber-50 text-amber-800" : "bg-slate-50 text-slate-500"}`}>
        {note}
      </div>
      <div className="mt-2 text-[10px] text-slate-400">Financing value is "soft" — realized over time as lower payments/higher cash flow, not cash in hand like equity. Adjust the rate sliders in Rate Savings below to see it move.</div>
    </div>
  );
}

// ---------- shared: rate-savings explorer ----------
function RateSavings({ loanAmount, rate, setRate, term, setTerm, mkt, setMkt, dealPayment = 0 }) {
  const [origTerm, setOrigTerm] = useState(30);
  const currentYear = new Date().getFullYear();
  const [rateStr, setRateStr] = useState(rate.toFixed(2));            // editable buffer for the rate input
  const [yearStr, setYearStr] = useState(String(currentYear + term)); // editable buffer for the maturity-year input
  const P = loanAmount;
  const effOrig = Math.max(term, origTerm);                 // original term can't be less than years left
  const seasoned = Math.max(0, effOrig - term);             // years the seller has already paid down
  const payDeal = pmt(P, rate, term);                       // financing-only P&I implied by the loan terms
  const payNew = pmt(P, mkt, effOrig);                      // fresh market loan, same balance, full term
  const intSubTo = Math.max(0, payDeal * term * 12 - P);    // interest left to pay on this loan
  const intNew = Math.max(0, payNew * effOrig * 12 - P);    // interest on a brand-new loan
  const intSaved = Math.max(0, intNew - intSubTo);          // total interest the buyer avoids
  const intSameTerm = Math.max(0, pmt(P, mkt, term) * term * 12 - P); // interest on a market-rate loan over the SAME years left
  const rateSaved = Math.max(0, intSameTerm - intSubTo);    // savings purely from the lower rate (same remaining term)
  const seasoningSaved = Math.max(0, intNew - intSameTerm); // savings purely from the loan being seasoned (fewer yrs left)
  const totalSaved = rateSaved + seasoningSaved;            // rate + seasoning; the two pieces always sum to this on screen
  // Fixed payment comparison: use the REAL payment entered on the deal, don't re-derive it.
  const haveRealPmt = dealPayment > 0;
  const tiPortion = haveRealPmt ? Math.max(0, dealPayment - payDeal) : 0;  // taxes/insurance (+ any 2nd-lien) baked into the real payment
  const newPmtFull = payNew + tiPortion;                                   // a new market loan, carrying the same taxes/insurance

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="mb-3 flex items-center gap-2">
        <TrendingDown className="h-4 w-4 text-emerald-500" />
        <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">Rate + seasoning savings — what taking over this loan is worth</h3>
      </div>
      {P > 0 ? (
        <div className="grid gap-5 md:grid-cols-2">
          {/* sliders */}
          <div className="space-y-4">
            {/* type-it inputs: loan rate + maturity year — drive the same values as the sliders */}
            <div className="rounded-xl border border-emerald-100 bg-emerald-50/40 p-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wide text-slate-500">Loan's rate</div>
                  <PlainInput value={rateStr} onChange={(v) => { setRateStr(v); const n = parseFloat(v); if (!isNaN(n)) setRate(n); }} suffix="%" />
                </div>
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wide text-slate-500">Matures (year)</div>
                  <PlainInput value={yearStr} onChange={(v) => { setYearStr(v); const yr = parseInt(v, 10); if (yr > currentYear) setTerm(Math.min(40, yr - currentYear)); }} />
                </div>
              </div>
              <div className="mt-1.5 text-[10px] text-slate-400">Type the loan's rate and the year it pays off — or drag the sliders below. They stay in sync, and the savings update instantly.</div>
            </div>
            <div>
              <div className="flex items-baseline justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Seller's rate — you inherit</span>
                <span className="font-mono text-lg font-bold tabular-nums text-emerald-600">{rate.toFixed(2)}%</span>
              </div>
              <input type="range" min={0} max={12} step={0.125} value={rate} onChange={(e) => { const v = parseFloat(e.target.value); setRate(v); setRateStr(v.toFixed(2)); }} className="mt-1 w-full accent-emerald-600" />
            </div>
            <div>
              <div className="flex items-baseline justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Original loan term</span>
                <span className="font-mono text-lg font-bold tabular-nums text-slate-900">{effOrig} yrs</span>
              </div>
              <input type="range" min={5} max={40} step={1} value={origTerm} onChange={(e) => setOrigTerm(parseInt(e.target.value))} className="mt-1 w-full accent-emerald-600" />
            </div>
            <div>
              <div className="flex items-baseline justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Years left on the loan</span>
                <span className="font-mono text-lg font-bold tabular-nums text-slate-900">{term} yrs</span>
              </div>
              <input type="range" min={1} max={40} step={1} value={term} onChange={(e) => { const v = parseInt(e.target.value); setTerm(v); setYearStr(String(currentYear + v)); }} className="mt-1 w-full accent-emerald-600" />
              <div className="mt-1 text-[11px] text-emerald-700">Seller has already paid <b>{seasoned} {seasoned === 1 ? "yr" : "yrs"}</b>{seasoned > 0 ? " — past the interest-heavy years" : ""}.</div>
            </div>
            <div>
              <div className="flex items-baseline justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">New-loan rate today — compare to</span>
                <span className="font-mono text-sm font-bold tabular-nums text-slate-500">{mkt.toFixed(2)}%</span>
              </div>
              <input type="range" min={0} max={14} step={0.125} value={mkt} onChange={(e) => setMkt(parseFloat(e.target.value))} className="mt-1 w-full accent-slate-400" />
            </div>
            <div className="text-[11px] text-slate-400">Loan balance: <span className="font-mono text-slate-600">{usd(P)}</span> — pulled from this deal.</div>
          </div>
          {/* savings */}
          <div className="space-y-3">
            <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-3">
              <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-700/80">What this loan saves — held to maturity</div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <div className="rounded-lg bg-white/70 px-2.5 py-2">
                  <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Rate savings</div>
                  <div className="font-mono text-lg font-bold tabular-nums text-emerald-700">{usd(rateSaved)}</div>
                  <div className="text-[10px] leading-tight text-slate-400">{rate.toFixed(2)}% vs {mkt.toFixed(2)}%, same {term} yrs left</div>
                </div>
                <div className="rounded-lg bg-white/70 px-2.5 py-2">
                  <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Seasoning savings</div>
                  <div className="font-mono text-lg font-bold tabular-nums text-emerald-700">{usd(seasoningSaved)}</div>
                  <div className="text-[10px] leading-tight text-slate-400">{term} yrs left vs a fresh {effOrig}-yr loan</div>
                </div>
              </div>
              <div className="mt-2 flex items-center justify-between rounded-lg bg-emerald-600 px-3 py-2 text-white">
                <span className="text-[11px] font-bold uppercase tracking-wide">Total interest saved</span>
                <span className="font-mono text-2xl font-extrabold tabular-nums">{usd(totalSaved)}</span>
              </div>
              <div className="mt-1 text-[10px] leading-tight text-slate-400">Rate savings <b>+</b> seasoning savings. Realized in full only if the loan is held to payoff — sell or refinance early and you capture the part up to that point.</div>
            </div>
            {/* side-by-side: take this loan vs new loan */}
            <div className="overflow-hidden rounded-xl border border-slate-200 text-[12px]">
              <div className="grid grid-cols-3 bg-slate-50 font-semibold text-slate-500">
                <div className="px-3 py-1.5"></div>
                <div className="px-2 py-1.5 text-center text-emerald-700">Take this loan</div>
                <div className="px-2 py-1.5 text-center">Get a new loan</div>
              </div>
              {[
                ["Rate", `${rate.toFixed(2)}%`, `${mkt.toFixed(2)}%`],
                ["Years to pay", `${term} left`, `${effOrig} fresh`],
                ...(haveRealPmt ? [["Payment", `${usd(dealPayment)}/mo`, `${usd(newPmtFull)}/mo`]] : []),
                ["Total interest", usd(intSubTo), usd(intNew)],
              ].map((r, i, arr) => (
                <div key={r[0]} className={`grid grid-cols-3 ${i < arr.length - 1 ? "border-b border-slate-100" : ""}`}>
                  <div className="px-3 py-1.5 text-slate-500">{r[0]}</div>
                  <div className="px-2 py-1.5 text-center font-semibold tabular-nums text-emerald-700">{r[1]}</div>
                  <div className="px-2 py-1.5 text-center tabular-nums text-slate-700">{r[2]}</div>
                </div>
              ))}
            </div>
            {haveRealPmt && (
              <div className="text-[10px] text-slate-400">Payment row uses the <b>real payment from this deal</b> — fixed, it won't move with the sliders. The new-loan figure is a fresh-rate loan carrying the same taxes &amp; insurance; set "Years left" to the loan's actual remaining term for the most accurate new-loan number.</div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <Stat label="Monthly payment relief" value={usd(haveRealPmt ? Math.max(0, newPmtFull - dealPayment) : Math.max(0, payNew - payDeal))} tone="good" sub="lighter payment vs a new loan" />
              <Stat label="Paid off sooner" value={seasoned > 0 ? `${seasoned} ${seasoned === 1 ? "yr" : "yrs"}` : "—"} tone={seasoned > 0 ? "good" : "default"} sub="free & clear earlier" />
            </div>
            <div className="rounded-lg bg-emerald-50/60 px-3 py-2 text-[11px] text-emerald-700">
              {seasoned > 0
                ? <>This loan is <b>{seasoned} of {effOrig} yrs</b> in — the seller already paid down the interest-heavy years. A fresh {effOrig}-yr loan at {mkt.toFixed(2)}% restarts that clock, so the buyer saves <b>{usd(rateSaved)}</b> from the lower rate <b>+</b> <b>{usd(seasoningSaved)}</b> from the seasoning = <b>{usd(totalSaved)}</b> in total interest, and owns it free &amp; clear <b>{seasoned} {seasoned === 1 ? "yr" : "yrs"}</b> sooner — if held to payoff.</>
                : <>Set the original term, then drag <b>Years left</b> down to model a seasoned loan and watch the seasoning savings stack on top of the rate savings.</>}
            </div>
          </div>
        </div>
      ) : (
        <div className="rounded-lg bg-slate-50 px-3 py-2 text-[11px] text-slate-500">
          Enter the loan amount in this deal above, and the sliders will show what the low rate saves you over the life of the loan.
        </div>
      )}
    </div>
  );
}


// ---------- SUB-TO ----------
// Two ceilings that keep a creative deal from quietly becoming a bad one. Neither is a published
// formula, they are working guardrails: (1) the cash you bring should come back out of cash flow
// inside about two years, and (2) you should not spend more than half your day-one equity to get in.
// Anything past those is buying equity rather than creating it, and that is a conversation for the
// head of acquisitions, not a call a rep makes alone.
const PAYBACK_GOOD = 18, PAYBACK_LIMIT = 24, EQUITY_SPEND_LIMIT = 0.5;
const CashDiscipline = ({ cashIn, cashFlow, equity }) => {
  if (cashIn <= 0) return null;
  const months = cashFlow > 0 ? cashIn / cashFlow : null;
  const share = equity > 0 ? cashIn / equity : null;
  const paybackTone = months == null ? "bad" : months <= PAYBACK_GOOD ? "good" : months <= PAYBACK_LIMIT ? "warn" : "bad";
  const shareTone = share == null ? "bad" : share <= EQUITY_SPEND_LIMIT ? "good" : share <= 0.75 ? "warn" : "bad";
  const col = { good: "text-emerald-700", warn: "text-amber-700", bad: "text-red-700" };
  const worst = [paybackTone, shareTone].includes("bad") ? "bad" : [paybackTone, shareTone].includes("warn") ? "warn" : "good";
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <SectionTitle>Cash discipline</SectionTitle>
      <div className="mt-1 text-[11px] leading-snug text-slate-500">
        Two checks on the money you bring to the table. Both are house rules, not bank rules.
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-2.5">
          <div className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Payback</div>
          <div className={`mt-0.5 font-mono text-lg font-bold ${col[paybackTone]}`}>
            {months == null ? "never" : `${months.toFixed(1)} mo`}
          </div>
          <div className="mt-0.5 text-[10.5px] leading-snug text-slate-500">
            {months == null
              ? "No positive cash flow, so the cash you bring never comes back out of this property."
              : `${usd(Math.round(cashIn))} in, ${usd(Math.round(cashFlow))}/mo out. Target is under ${PAYBACK_GOOD} months.`}
          </div>
        </div>
        <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-2.5">
          <div className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Cash in vs equity captured</div>
          <div className={`mt-0.5 font-mono text-lg font-bold ${col[shareTone]}`}>
            {share == null ? "no equity" : `${Math.round(share * 100)}%`}
          </div>
          <div className="mt-0.5 text-[10.5px] leading-snug text-slate-500">
            {share == null
              ? "No equity captured, so every dollar in is at risk with nothing underneath it."
              : `Spending ${usd(Math.round(cashIn))} to capture ${usd(Math.round(equity))}. Stay under half.`}
          </div>
        </div>
      </div>
      <div className={`mt-3 rounded-lg px-3 py-2 text-[11.5px] font-semibold leading-snug ${
        worst === "good" ? "bg-emerald-50 text-emerald-800" : worst === "warn" ? "bg-amber-50 text-amber-800" : "bg-red-50 text-red-800"
      }`}>
        {worst === "good"
          ? "Clean entry. The cash you bring comes back reasonably fast and sits on real equity."
          : worst === "warn"
            ? "Workable but tight. Before you commit, try to move the cash down instead of the price up. Ask what they actually need at closing rather than what they want on paper."
            : "Too much cash for what this returns. Do not commit on the call. Get the cash to seller down, or send it to the head of acquisitions."}
      </div>
    </div>
  );
};

function SubToTab(props) {
  const { arv, repairs, underPct, overPct, wholesaleFee, setWholesaleFee, deckCommon, rentDefault, stBal, setStBal, stPiti, setStPiti, stArrears, setStArrears, stCashSeller, setStCashSeller, stClosing, setStClosing, stRent, setStRent, stReservePct, setStReservePct } = props;
  const bal = num(stBal), piti = num(stPiti), arrears = num(stArrears), cashSeller = num(stCashSeller), closing = num(stClosing), rent = num(stRent) || num(rentDefault);
  const reserves = rent * (num(stReservePct) / 100);
  const cashIn = cashSeller + arrears + closing + repairs;
  const closeCash = cashSeller + arrears + closing + num(wholesaleFee);  // buyer's cash at closing: entry + your fee (rehab is paid after close)
  const cashFlow = rent - piti - reserves;
  const equity = arv - (bal + cashSeller + arrears + repairs);
  const coc = (closeCash + repairs) > 0 ? ((cashFlow * 12) / (closeCash + repairs)) * 100 : 0; // cash-on-cash on true cash in: entry + fee + rehab (matches the deck)
  const buyerCoc = (closeCash + repairs) > 0 ? ((cashFlow * 12) / (closeCash + repairs)) * 100 : 0;  // buyer's coc on true total invested (cash to close + rehab)
  // shared rate-savings inputs (feed both Rate Savings + the creative-wholesale value)
  const [rsRate, setRsRate] = useState(4);
  const [rsTerm, setRsTerm] = useState(30);
  const [rsMkt, setRsMkt] = useState(7.5);
  const finValue = pvSavings(bal, rsRate, rsMkt, rsTerm);
  let status = "maybe", headline = "Enter rent & PITI to grade", detail = "";
  if (rent > 0 && piti > 0) {
    if (cashFlow >= 200 && equity > 0) { status = "go"; headline = "STRONG sub-to"; detail = `${usd(cashFlow)}/mo cash flow and ${usd(equity)} captured equity over the loan.`; }
    else if (cashFlow > 0) { status = "maybe"; headline = "WORKS — watch the margin"; detail = `${usd(cashFlow)}/mo after reserves. ${equity > 0 ? usd(equity) + " equity." : "Little/no equity — leaning on rate + cash flow."}`; }
    else { status = "no"; headline = "NEGATIVE — pass or restructure"; detail = `${usd(cashFlow)}/mo after reserves. Lower entry, raise rent, or walk.`; }
  }
  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <SectionTitle>Subject-to inputs</SectionTitle>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Existing loan balance"><MoneyInput value={stBal} onChange={setStBal} /></Field>
            <Field label="PITI (monthly)" hint="inherited payment"><MoneyInput value={stPiti} onChange={setStPiti} /></Field>
            <Field label="Arrears / back pmts"><MoneyInput value={stArrears} onChange={setStArrears} /></Field>
            <Field label="Cash to seller" hint="equity"><MoneyInput value={stCashSeller} onChange={setStCashSeller} /></Field>
            <Field label="Closing costs"><MoneyInput value={stClosing} onChange={setStClosing} /></Field>
            <Field label="Market rent (monthly)" hint={num(rentDefault) > 0 ? "auto-filled — type to override" : ""} info="Carried over from the rent you generate in the Cash / MAO tab's BRRRR panel. Type here to use a different rent for this strategy only."><MoneyInput value={stRent} onChange={setStRent} placeholder={num(rentDefault) > 0 ? String(Math.round(num(rentDefault))) : "Type the rent"} /></Field>
            <Field label="Reserves" hint="% of rent"><PlainInput value={stReservePct} onChange={setStReservePct} suffix="%" /></Field>
          </div>
        </div>
        <div className="space-y-3">
          <Verdict status={status} headline={headline} detail={detail} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Stat label="Monthly cash flow" value={usd(cashFlow)} tone={cashFlow > 0 ? "good" : "bad"} big sub={`rent − PITI − ${usd(reserves)} reserves`} />
            <Stat label="Equity captured" value={usd(equity)} tone={equity > 0 ? "good" : "warn"} big sub={repairs > 0 ? "ARV − loan − entry − rehab" : "ARV − loan − entry"} />
            <Stat label="Total cash to close" value={usd(closeCash)} sub={num(wholesaleFee) > 0 ? "seller + arrears + closing + fee" : "seller + arrears + closing"} />
            <Stat label="Cash-on-cash" value={pct(coc)} tone={coc > 0 ? "good" : "bad"} sub={repairs > 0 ? "annual · on cash in + rehab" : "annual · on cash in"} />
          </div>
        </div>
      </div>
      <CashDiscipline cashIn={closeCash + repairs} cashFlow={cashFlow} equity={equity} />
      <WholesaleCompare arv={arv} repairs={repairs} underPct={underPct} overPct={overPct} wholesaleFee={wholesaleFee} setWholesaleFee={setWholesaleFee}
        dealCost={bal + cashSeller + arrears} costLabel="Sub-to all-in (loan + entry)" financingValue={finValue} buyerCashIn={cashIn} annualCF={cashFlow * 12} />
      <RateSavings loanAmount={bal} rate={rsRate} setRate={setRsRate} term={rsTerm} setTerm={setRsTerm} mkt={rsMkt} setMkt={setRsMkt} dealPayment={piti} />
      <BuyerDeckButton
        common={{ ...deckCommon, contractDefault: closeCash + repairs, fee: 0 }}
        priceLabel="Buyer's total cash in"
        deal={{
          type: "Subject-To",
          loanSavings: computeLoanSavings({ P: bal, rate: rsRate, term: rsTerm, mkt: rsMkt, dealPayment: piti }),
          headline: `Sub-To · ${usd(cashFlow)}/mo cash flow · ${usd(finValue)} financing value`,
          highlights: [
            cashFlow > 0 ? `Potential to make ${usd(cashFlow)}/mo in cash flow once renovated and rented` : null,
            equity > 0 ? `${usd(equity)} in built-in equity below ARV` : null,
            finValue > 0 ? `${usd(finValue)} of value from the assumed below-market loan` : null,
            "Take over the seller's existing financing — no new bank loan or qualifying",
            rent > 0 ? `Rents for about ${usd(rent)}/mo` : null,
          ],
          rows: [
            ["Existing loan balance", usd(bal)],
            ["Inherited payment (PITI)", usd(piti) + "/mo"],
            ["Cash to seller", usd(cashSeller)],
            ["Monthly cash flow", usd(cashFlow)],
            ["Equity captured", usd(equity)],
            ["Financing value (low rate)", usd(finValue)],
          ],
          totalLabel: "Total deal value",
          totalValue: usd(Math.max(0, equity) + finValue),
          verdict: detail,
          ...buildDealExtras({ loanAmt: bal, rate: rsRate, term: rsTerm, arv, equity, cashFlow, cashToClose: closeCash, coc: buyerCoc }),
        }}
      />
      <TabEducation id="subto" />
    </div>
  );
}

// ---------- HYBRID ----------
function HybridTab(props) {
  const { arv, repairs, underPct, overPct, wholesaleFee, setWholesaleFee, deckCommon, rentDefault, hyPrice, setHyPrice, hyDown, setHyDown, hyBal, setHyBal, hyPiti, setHyPiti, hyRate, setHyRate, hyTerm, setHyTerm, hyClosing, setHyClosing, hyRent, setHyRent, hyReservePct, setHyReservePct } = props;
  const price = num(hyPrice), down = num(hyDown), bal = num(hyBal), piti = num(hyPiti), rent = num(hyRent) || num(rentDefault), closing = num(hyClosing);
  const note = Math.max(0, price - bal - down);
  const notePay = pmt(note, num(hyRate), num(hyTerm));
  const totalMonthly = piti + notePay;
  const reserves = rent * (num(hyReservePct) / 100);
  const cashFlow = rent - totalMonthly - reserves;
  const cashIn = down + closing + repairs;
  const closeCash = down + closing + num(wholesaleFee);  // buyer's cash at closing: entry + your fee (rehab is paid after close)
  const equity = arv - price - repairs;
  const coc = (closeCash + repairs) > 0 ? ((cashFlow * 12) / (closeCash + repairs)) * 100 : 0; // cash-on-cash on true cash in: entry + fee + rehab (matches the deck)
  const buyerCoc = (closeCash + repairs) > 0 ? ((cashFlow * 12) / (closeCash + repairs)) * 100 : 0;  // buyer's coc on true total invested (cash to close + rehab)
  const [rsRate, setRsRate] = useState(4);
  const [rsTerm, setRsTerm] = useState(30);
  const [rsMkt, setRsMkt] = useState(7.5);
  const finValue = pvSavings(bal, rsRate, rsMkt, rsTerm);
  let status = "maybe", headline = "Enter price, loan & rent to grade", detail = "";
  if (price > 0 && rent > 0) {
    if (cashFlow >= 200 && equity >= 0) { status = "go"; headline = "STRONG hybrid"; detail = `Sub-to keeps the low-rate ${usd(bal)} loan clean; ${usd(note)} seller note on top. ${usd(cashFlow)}/mo.`; }
    else if (cashFlow > 0) { status = "maybe"; headline = "WORKS — tune the note"; detail = `${usd(cashFlow)}/mo. Push note rate toward 0% or extend term to lift cash flow.`; }
    else { status = "no"; headline = "NEGATIVE — restructure"; detail = `${usd(cashFlow)}/mo. Lower price, bigger sub-to portion, or longer/0% note.`; }
  }
  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <SectionTitle>Hybrid (sub-to + seller note)</SectionTitle>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Purchase price"><MoneyInput value={hyPrice} onChange={setHyPrice} /></Field>
            <Field label="Down payment"><MoneyInput value={hyDown} onChange={setHyDown} /></Field>
            <Field label="Existing loan balance" hint="taken sub-to"><MoneyInput value={hyBal} onChange={setHyBal} /></Field>
            <Field label="Sub-to PITI (monthly)"><MoneyInput value={hyPiti} onChange={setHyPiti} /></Field>
            <Field label="Seller note rate" hint="0% ok"><PlainInput value={hyRate} onChange={setHyRate} suffix="%" /></Field>
            <Field label="Seller note term"><PlainInput value={hyTerm} onChange={setHyTerm} suffix="yrs" /></Field>
            <Field label="Closing costs"><MoneyInput value={hyClosing} onChange={setHyClosing} /></Field>
            <Field label="Market rent (monthly)" hint={num(rentDefault) > 0 ? "auto-filled — type to override" : ""} info="Carried over from the rent you generate in the Cash / MAO tab's BRRRR panel. Type here to use a different rent for this strategy only."><MoneyInput value={hyRent} onChange={setHyRent} placeholder={num(rentDefault) > 0 ? String(Math.round(num(rentDefault))) : "Type the rent"} /></Field>
            <Field label="Reserves" hint="% of rent"><PlainInput value={hyReservePct} onChange={setHyReservePct} suffix="%" /></Field>
          </div>
        </div>
        <div className="space-y-3">
          <Verdict status={status} headline={headline} detail={detail} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Stat label="Monthly cash flow" value={usd(cashFlow)} tone={cashFlow > 0 ? "good" : "bad"} big sub={`rent − ${usd(totalMonthly)} debt − reserves`} />
            <Stat label="Seller note amount" value={usd(note)} sub="price − loan − down" />
            <Stat label="Note payment" value={usd(notePay)} sub={`${num(hyRate)}% / ${num(hyTerm)}yr`} />
            <Stat label="Total monthly debt" value={usd(totalMonthly)} sub="PITI + note" />
            <Stat label="Equity captured" value={usd(equity)} tone={equity >= 0 ? "good" : "warn"} sub={repairs > 0 ? "ARV − price − rehab" : "ARV − price"} />
            <Stat label="Cash-on-cash" value={pct(coc)} tone={coc > 0 ? "good" : "bad"} sub={`${usd(closeCash + repairs)} in`} />
          </div>
        </div>
      </div>
      <CashDiscipline cashIn={closeCash + repairs} cashFlow={cashFlow} equity={equity} />
      <WholesaleCompare arv={arv} repairs={repairs} underPct={underPct} overPct={overPct} wholesaleFee={wholesaleFee} setWholesaleFee={setWholesaleFee}
        dealCost={price} costLabel="Hybrid purchase price" financingValue={finValue} buyerCashIn={cashIn} annualCF={cashFlow * 12} />
      <RateSavings loanAmount={bal} rate={rsRate} setRate={setRsRate} term={rsTerm} setTerm={setRsTerm} mkt={rsMkt} setMkt={setRsMkt} dealPayment={totalMonthly} />
      <BuyerDeckButton
        common={{ ...deckCommon, contractDefault: price }}
        deal={{
          type: "Hybrid",
          loanSavings: computeLoanSavings({ P: bal, rate: rsRate, term: rsTerm, mkt: rsMkt, dealPayment: totalMonthly }),
          headline: `Hybrid · ${usd(cashFlow)}/mo cash flow · ${usd(finValue)} financing value`,
          highlights: [
            cashFlow > 0 ? `Potential to make ${usd(cashFlow)}/mo in cash flow once renovated and rented` : null,
            equity > 0 ? `${usd(equity)} in built-in equity below ARV` : null,
            finValue > 0 ? `${usd(finValue)} of value from the assumed low-rate first loan` : null,
            "Low-rate loan taken subject-to, seller carries the rest — minimal cash in",
            rent > 0 ? `Rents for about ${usd(rent)}/mo` : null,
          ],
          rows: [
            ["Purchase price", usd(price)],
            ["Sub-to loan (low rate)", usd(bal)],
            ["Seller note", usd(note)],
            ["Total monthly debt", usd(totalMonthly)],
            ["Monthly cash flow", usd(cashFlow)],
            ["Equity captured", usd(equity)],
          ],
          totalLabel: "Total deal value",
          totalValue: usd(Math.max(0, equity) + finValue),
          verdict: detail,
          ...buildDealExtras({ loanAmt: bal, rate: rsRate, term: rsTerm, arv, equity, cashFlow, cashToClose: closeCash, coc: buyerCoc }),
        }}
      />
      <TabEducation id="hybrid" />
    </div>
  );
}

// ---------- SELLER FINANCE ----------
function SellerFinanceTab(props) {
  const { arv, repairs, underPct, overPct, wholesaleFee, setWholesaleFee, deckCommon, rentDefault, sfPrice, setSfPrice, sfDown, setSfDown, sfRate, setSfRate, sfAmort, setSfAmort, sfBalloon, setSfBalloon, sfTaxIns, setSfTaxIns, sfRent, setSfRent, sfReservePct, setSfReservePct } = props;
  const price = num(sfPrice), down = num(sfDown), taxIns = num(sfTaxIns), rent = num(sfRent) || num(rentDefault);
  const loan = Math.max(0, price - down);
  const pi = pmt(loan, num(sfRate), num(sfAmort));
  const totalMonthly = pi + taxIns;
  const reserves = rent * (num(sfReservePct) / 100);
  const cashFlow = rent - totalMonthly - reserves;
  const balloonYrs = num(sfBalloon);
  const balloonBal = balloonYrs > 0 ? balanceAt(loan, num(sfRate), num(sfAmort), balloonYrs) : 0;
  const totalInterest = pi * num(sfAmort) * 12 - loan;
  const equity = arv - price - repairs;
  const cashIn = down + repairs;
  const closeCash = down + num(wholesaleFee);  // buyer's cash at closing: entry + your fee (rehab is paid after close)
  const coc = (closeCash + repairs) > 0 ? ((cashFlow * 12) / (closeCash + repairs)) * 100 : 0; // cash-on-cash on true cash in: entry + fee + rehab (matches the deck)
  const buyerCoc = (closeCash + repairs) > 0 ? ((cashFlow * 12) / (closeCash + repairs)) * 100 : 0;  // buyer's coc on true total invested (cash to close + rehab)
  // seller-finance terms ARE the loan terms — seed the shared rate inputs from them
  const [rsRate, setRsRate] = useState(num(sfRate) || 4);
  const [rsTerm, setRsTerm] = useState(num(sfAmort) || 30);
  const [rsMkt, setRsMkt] = useState(7.5);
  const finValue = pvSavings(loan, rsRate, rsMkt, rsTerm);
  let status = "maybe", headline = "Enter price & rent to grade", detail = "";
  if (price > 0 && rent > 0) {
    if (cashFlow >= 200) { status = "go"; headline = "STRONG seller-finance"; detail = `${usd(cashFlow)}/mo at ${num(sfRate)}% over ${num(sfAmort)}yr.${balloonYrs ? " Balloon " + usd(balloonBal) + " due yr " + balloonYrs + "." : " No balloon — clean."}`; }
    else if (cashFlow > 0) { status = "maybe"; headline = "WORKS — push terms"; detail = `${usd(cashFlow)}/mo. Drive rate toward 0%, extend amortization, or kill the balloon.`; }
    else { status = "no"; headline = "NEGATIVE — renegotiate terms"; detail = `${usd(cashFlow)}/mo. Price for their number only if the terms carry the cash flow.`; }
  }
  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <SectionTitle>Seller financing inputs</SectionTitle>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Purchase price"><MoneyInput value={sfPrice} onChange={setSfPrice} /></Field>
            <Field label="Down payment"><MoneyInput value={sfDown} onChange={setSfDown} /></Field>
            <Field label="Interest rate" hint="0% ok"><PlainInput value={sfRate} onChange={setSfRate} suffix="%" /></Field>
            <Field label="Amortization"><PlainInput value={sfAmort} onChange={setSfAmort} suffix="yrs" /></Field>
            <Field label="Balloon" hint="0 = none"><PlainInput value={sfBalloon} onChange={setSfBalloon} suffix="yrs" /></Field>
            <Field label="Taxes + insurance" hint="monthly"><MoneyInput value={sfTaxIns} onChange={setSfTaxIns} /></Field>
            <Field label="Market rent (monthly)" hint={num(rentDefault) > 0 ? "auto-filled — type to override" : ""} info="Carried over from the rent you generate in the Cash / MAO tab's BRRRR panel. Type here to use a different rent for this strategy only."><MoneyInput value={sfRent} onChange={setSfRent} placeholder={num(rentDefault) > 0 ? String(Math.round(num(rentDefault))) : "Type the rent"} /></Field>
            <Field label="Reserves" hint="% of rent"><PlainInput value={sfReservePct} onChange={setSfReservePct} suffix="%" /></Field>
          </div>
        </div>
        <div className="space-y-3">
          <Verdict status={status} headline={headline} detail={detail} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Stat label="Monthly cash flow" value={usd(cashFlow)} tone={cashFlow > 0 ? "good" : "bad"} big sub={`rent − ${usd(totalMonthly)} − reserves`} />
            <Stat label="Principal & interest" value={usd(pi)} big sub={`${usd(loan)} @ ${num(sfRate)}%`} />
            <Stat label="Balloon balance" value={balloonYrs ? usd(balloonBal) : "None"} tone={balloonYrs ? "warn" : "good"} sub={balloonYrs ? `due year ${balloonYrs}` : "fully amortizing"} />
            <Stat label="Total interest" value={usd(Math.max(0, totalInterest))} sub={num(sfRate) === 0 ? "0% — principal only" : "life of loan"} />
            <Stat label="Equity captured" value={usd(equity)} tone={equity >= 0 ? "good" : "warn"} sub={repairs > 0 ? "ARV − price − rehab" : "ARV − price"} />
            <Stat label="Cash-on-cash" value={pct(coc)} tone={coc > 0 ? "good" : "bad"} sub={repairs > 0 ? "down + fee + rehab" : "down + fee"} />
          </div>
        </div>
      </div>
      <WholesaleCompare arv={arv} repairs={repairs} underPct={underPct} overPct={overPct} wholesaleFee={wholesaleFee} setWholesaleFee={setWholesaleFee}
        dealCost={price} costLabel="Seller-finance price" financingValue={finValue} buyerCashIn={cashIn} annualCF={cashFlow * 12} />
      <RateSavings loanAmount={loan} rate={rsRate} setRate={setRsRate} term={rsTerm} setTerm={setRsTerm} mkt={rsMkt} setMkt={setRsMkt} dealPayment={totalMonthly} />
      <BuyerDeckButton
        common={{ ...deckCommon, contractDefault: price }}
        deal={{
          type: "Seller Finance",
          loanSavings: computeLoanSavings({ P: loan, rate: rsRate, term: rsTerm, mkt: rsMkt, dealPayment: totalMonthly }),
          headline: `Seller Finance · ${usd(cashFlow)}/mo cash flow · ${usd(finValue)} financing value`,
          highlights: [
            cashFlow > 0 ? `Potential to make ${usd(cashFlow)}/mo in cash flow once renovated and rented` : null,
            equity > 0 ? `${usd(equity)} in built-in equity below ARV` : null,
            num(sfRate) < 7 ? `${usd(finValue)} of value from a ${num(sfRate)}% seller-financed rate vs the market` : null,
            "Seller-financed — no bank, no qualifying, terms set with the seller",
            rent > 0 ? `Rents for about ${usd(rent)}/mo` : null,
          ],
          rows: [
            ["Purchase price", usd(price)],
            ["Down payment", usd(down)],
            ["Interest rate", `${num(sfRate)}%`],
            ["Monthly P&I", usd(pi)],
            ["Monthly cash flow", usd(cashFlow)],
            ["Equity captured", usd(equity)],
          ],
          totalLabel: "Total deal value",
          totalValue: usd(Math.max(0, equity) + finValue),
          verdict: detail,
          ...buildDealExtras({ loanAmt: loan, rate: rsRate, term: rsTerm, arv, equity, cashFlow, cashToClose: closeCash, coc: buyerCoc }),
        }}
      />
      <TabEducation id="sf" />
    </div>
  );
}

// ---------- NOVATION (your sheet: As-Is × 0.95 × 0.92 − profit = MAO) ----------
function NovationTab(props) {
  const { novAsIs, setNovAsIs, novProfit, setNovProfit, novListFactor, setNovListFactor, novCostFactor, setNovCostFactor } = props;
  const asIs = num(novAsIs);
  const listPrice = asIs * (num(novListFactor) / 100);          // As-Is × 0.95
  const net = listPrice * (1 - num(novCostFactor) / 100);        // − closing + realtor (~8%)
  const mao = net - num(novProfit);                             // − desired novation profit
  let status = "maybe", headline = "Enter the As-Is value to grade", detail = "";
  if (asIs > 0) {
    if (mao > 0) { status = "go"; headline = "Novation MAO ready"; detail = `Offer up to ${usd(mao)} to net your ${usd(num(novProfit))} target.`; }
    else { status = "no"; headline = "Profit target too high for this value"; detail = `Costs + profit exceed the net. Lower the target or reconsider the deal.`; }
  }
  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 flex items-start gap-2">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
        <div className="text-xs text-amber-900">
          Confirm the As-Is value is what the property will <b>actually sell for on the MLS as-is</b> before trusting this number. Runs your sheet's formula: As-Is × {num(novListFactor)}% × (100−{num(novCostFactor)})% − profit.
        </div>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <SectionTitle>Novation inputs</SectionTitle>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2"><Field label="As-Is value (MLS list basis)"><MoneyInput value={novAsIs} onChange={setNovAsIs} placeholder="405000" /></Field></div>
            <Field label="Desired novation profit"><MoneyInput value={novProfit} onChange={setNovProfit} /></Field>
            <div className="hidden sm:block" />
            <Field label="List discount" hint="As-Is × this %"><PlainInput value={novListFactor} onChange={setNovListFactor} suffix="%" /></Field>
            <Field label="Closing + realtor" hint="% off list"><PlainInput value={novCostFactor} onChange={setNovCostFactor} suffix="%" /></Field>
          </div>
        </div>
        <div className="space-y-3">
          <Verdict status={status} headline={headline} detail={detail} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Stat label="List price" value={usd(listPrice)} sub={`As-Is × ${num(novListFactor)}%`} />
            <Stat label="Net after costs" value={usd(net)} sub={`− ${num(novCostFactor)}% closing/realtor`} />
          </div>
          <Stat label="Novation Max Allowable Offer" value={usd(mao)} tone={mao > 0 ? "good" : "bad"} big sub="net − desired profit" />
        </div>
      </div>
      <TabEducation id="nov" />
    </div>
  );
}
